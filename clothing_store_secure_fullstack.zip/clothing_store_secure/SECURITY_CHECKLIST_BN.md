# Security Features & Checklist (বাংলা)

## এই build-এ implement করা সুরক্ষা

- **Admin route separation:** public storefront-এ Admin link নেই। `/admin` unauthenticated অবস্থায় login page-এ redirect করে; Admin APIs authentication ছাড়া 401 দেয়। URL জানা থাকলেও permission ছাড়া dashboard/API পাওয়া যায় না।
- **First Admin setup:** random one-time token terminal-এ দেখায়; setup একবারই করা যায়। Admin তৈরি হলে setup token file মুছে ফেলা হয়। `SETUP_TOKEN` environment থেকে দিলে সেটি log-এ echo করা হয় না।
- **Password handling:** raw password database-এ রাখা হয় না; random saltসহ `scrypt` hash হয়। Setup-এ 14+ character এবং uppercase/lowercase/number/symbol দরকার। Login response generic এবং repeated failed attempts throttle হয়।
- **Server-side sessions:** 256-bit random cookie token; database-এ token-এর SHA-256 hash রাখা হয়। Cookie `HttpOnly`, `SameSite=Strict`, production HTTPS-এ `Secure`; auth change হলে session rotate হয়; expiry check হয়।
- **CSRF protection:** non-GET requests-এ synchronizer CSRF token এবং Origin/Host check।
- **HTTP headers:** CSP, `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, Referrer Policy, Permissions Policy, COOP/CORP এবং production HTTPS-এ HSTS। CSP-এর কারণে inline JavaScript/CSS intentionally ব্যবহার করা হয়নি।
- **Input handling:** SQL parameters, JSON body size limits, field length/range validation, order price/stock server-side calculation, transactional stock reservation, upload MIME/signature/size validation; SVG upload নিষিদ্ধ। Remote image URL-এ HTTPS ছাড়া অন্য scheme গ্রহণ করা হয় না।
- **Rate limiting:** API-level in-process limit, persistent failed-login history, event retention cleanup। In-memory API rate limits restart/multi-instance জুড়ে share হয় না—large production-এর জন্য edge/host-level rate limiting যোগ করতে হবে।
- **IP block/unblock:** admin exact IPv4/IPv6 address block/remove করতে পারে। Manual block storefront এবং order API থামায়; authenticated Admin route খোলা থাকে যাতে ভুল block সরানো যায়। একই IP থেকে নিজেকে block করা ঠেকানো হয়।
- **Customer activity/privacy:** Analytics consent থাকলে page/product view, search query length (actual search phrase নয়), add-to-cart, checkout start, language change এবং order event capture হয়। IP, User-Agent, path, referrer-এর sanitized form দেখা যায়। Keylogging, password capture, payment credential capture নেই।
- **Retention:** activity events 90 দিনের বেশি হলে server startup-এ এবং চলমান অবস্থায় সর্বোচ্চ ঘণ্টায় একবার maintenance চললে মুছে ফেলা হয়। Orders আলাদা policy না দেওয়া পর্যন্ত থাকে; দোকানদারকে business/legal needs অনুযায়ী retention ও deletion process নির্ধারণ করতে হবে।
- **Backups:** JSON export এবং SQLite backup instructions আছে। Export-এ customer information থাকতে পারে; public repo/cloud share-এ upload করা যাবে না।

## এই build যা করে না

- DDoS protection / WAF / CAPTCHA / email OTP / MFA নেই। Hosting/edge controls হিসেবে দরকার হতে পারে।
- Admin account recovery/reset flow নেই; ভুল password হারালে owner-controlled maintenance/recovery দরকার।
- Payment gateway ও courier integration নেই; কোনো customer online payment করতে পারবে না।
- Database field-level encryption-at-rest app নিজে implement করে না; host disk/database encryption এবং access controls প্রয়োজন।
- SQLite একটি local/persistent single-server database; multi-instance cluster বা ephemeral host-এর জন্য নয়।
- Geolocation lookup নেই। IP address দিয়ে নির্দিষ্ট ব্যক্তি বা নির্দিষ্ট ঠিকানা নিশ্চিত করা যায় না। Mobile carrier/shared Wi-Fi/VPN-এর কারণে অনেক customer একই IP ব্যবহার করতে পারে।
- “বিশ্বের সেরা” বা শতভাগ security নিশ্চয়তা দেওয়া যায় না; নিরাপত্তা নির্ভর করে hosting, deployment, update, account protection ও monitoring-এর ওপরও।

## Live করার আগে checklist

- [ ] All routes served over HTTPS; secure cookies verified
- [ ] Admin password unique, password manager-এ রাখা; 2FA/MFA hosting/account-এ enabled
- [ ] Host/database/upload directory access owner-only
- [ ] SQLite DB ও uploads persistent; restart/redeploy-এর পর data survives
- [ ] Automated encrypted backups; restore test সম্পন্ন
- [ ] Proxy IP trust/firewall correct; untrusted `X-Forwarded-For` ignored
- [ ] Rate limiting/WAF on host edge; request-size and abuse monitoring
- [ ] Privacy notice, business contact, delivery/return/refund terms updated
- [ ] Activity retention/deletion procedure documented
- [ ] Customer order data export/backups private
- [ ] Payment provider integrated server-side and sandbox/webhook tested before taking payment
- [ ] Dependency/runtime updates scheduled
- [ ] Automated tests pass on actual deployed build
