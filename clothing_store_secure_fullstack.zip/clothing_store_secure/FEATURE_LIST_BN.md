# ফিচার লিস্ট — Clothing Store Secure Starter

## এখনই লোকাল ডেমোতে কাজ করে

- বাংলা ও English storefront; ভাষা বদলানো যায়।
- নমুনা পোশাক/কম্বো পণ্য; category ও search.
- আলাদা `/admin/login` ও protected `/admin`; storefront-এ Admin link নেই। সরাসরি `/admin` খুললেও login ছাড়া dashboard পাওয়া যাবে না।
- প্রথম Admin তৈরির one-time setup token; শক্তিশালী password policy; scrypt password hash.
- Admin থেকে পণ্য add/edit/delete, বাংলা-ইংরেজি নাম/বিবরণ, category, SKU, price, stock, visibility এবং JPG/PNG/WebP upload বা HTTPS image URL.
- Cart; Bangladesh mobile validation; COD checkout.
- Order details/status, cancel করলে stock ফেরত ও পুনরায় confirm করলে stock পুনরায় reserve.
- Dashboard sales/orders summary, customer order details, low stock, export/backup.
- IP block/unblock (exact IPv4/IPv6), reason, security events এবং failed-login rate limit.
- Activity log: opt-in analytics-এর পরে page view, product view, search query length (search text নয়), add-to-cart, checkout start ও language change; order/security events প্রয়োজনীয় কাজের জন্য।
- Customer-এর নাম/ফোন/জেলা/উপজেলা/ঠিকানা order পরিচালনায় সেভ হয়। IP ও browser User-Agent security/order audit-এর জন্য রাখা হয়। Password, keystroke, payment credential capture করা হয় না।
- Session, CSRF, origin check, secure headers/CSP, body-size limits, parameterized SQL, upload signature/size checks, transaction-ভিত্তিক stock.
- 90 দিনের activity log retention; JSON backup; health check.

## Real online launch-এর আগে যোগ/সেটআপ করতে হবে

- Node-capable hosting-এ server deploy, HTTPS এবং persistent disk.
- backup automation, restore drill, domain (এখনই দরকার নেই), contact/return/refund/privacy policy.
- Production edge/WAF/DDoS/rate limiting এবং monitored logs.
- প্রয়োজন অনুযায়ী MFA, admin recovery, staff roles, product image object storage.
- bKash/Nagad/কার্ড payment API (server-side verification/webhook), courier API/status updates.
- বেশি traffic/multi-instance হলে PostgreSQL ও object storage-এ migration.

## সীমাবদ্ধতা — খোলাখুলি

- এটি production-minded starter, কোনো formal penetration test বা security certification নয়; 100% security বা “বিশ্বের সেরা” নিশ্চয়তা নেই।
- অনলাইনে deployed হয়নি, তাই কোনো public live URL দেওয়া হয়নি। লোকাল সার্ভারে run ও API integration test করা হয়েছে।
- এই execution environment Chromium থেকে localhost খুলতে `ERR_BLOCKED_BY_ADMINISTRATOR` ফিরিয়েছে; তাই browser-ভিত্তিক UI screenshot/visual assertion এখানে সম্পন্ন হয়নি। নিজের PC-তে গাইড অনুযায়ী Chrome দিয়ে পরীক্ষা করো।
- Database SQLite; single persistent server-এর জন্য। Serverless/ephemeral filesystem ও multiple server instance-এর জন্য সরাসরি উপযুক্ত নয়।
- IP block exact address-এ কাজ করে; shared Wi-Fi/carrier/NAT-এ অনেক user একই public IP ভাগ করে নিতে পারে। IP থেকে নির্দিষ্ট ব্যক্তির পরিচয়/বাসার ঠিকানা জানা যায় না। CIDR ranges/IP geography lookup নেই।
- Customer activity analytics ঐচ্ছিক consent চায়; শুধু site খোলার কারণে sensitive keystroke tracking হয় না।
