# QA Report — Secure Clothing Store Starter

QA run date: 2026-10-18

## Automated checks run

Commands run: `node --check server.js`, `node --check public/js/store.js`, `node --check public/js/admin.js`, `node --check public/js/login.js`, HTML ID/inline-handler scan, a live local server smoke test (`/healthz`, `/`, `/api/products`, protected `/admin`), then `npm test`. Final automated result: **2 tests passed, 0 failed** with the main test covering cross-browser guest ordering and IPv6 IP-block normalization.

Results: **2 test suites passed** (end-to-end integration suite plus security helper suite). The end-to-end suite creates its own temporary SQLite database and checks:

1. Storefront HTTP 200, CSP present, and no direct `/admin` hyperlink.
2. `/api/bootstrap` creates a guest session and CSRF token.
3. Unauthenticated `/admin` redirects to `/admin/login`.
4. Admin setup without CSRF is denied; valid one-time token and strong password create Admin.
5. Authenticated Admin page renders; no-cookie Admin API request returns 401.
6. Unsafe `javascript:` image URL is rejected as a validation error (400).
7. Product create and public catalog visibility.
8. Image upload validates signature/size and saves a randomized local path.
9. COD checkout computes price/server-side, creates order, and deducts stock.
10. Cancel restores stock; re-confirm re-reserves stock transactionally.
11. Admin mutation without CSRF is denied.
12. IP block/unblock enforces the stored IP at the request boundary when the configured trusted proxy is simulated; alternate IPv6 spellings canonicalize to the same block.
13. An independent guest browser/session can place a COD order and that order appears in the Admin order list, sharing the same database; stock is reduced server-side.
14. Consent-tagged analytics event and order event are visible to Admin activity API.
15. Store settings update and private JSON backup endpoint.
16. Five failed Admin login attempts are throttled; a sixth receives HTTP 429.
17. Password hash verify/reject, unsafe image URL rejection, IPv4-mapped/IPv6 normalization, and checkout validation.

A first test exposed two issues and they were fixed before the final rerun: `/admin` redirects were followed by Fetch in the test harness (test changed to inspect redirects manually), and expected product validation errors were incorrectly reported as server 500 (now returned as 400 without stack traces). The final rerun passed.

## Browser visual QA limitation

A Playwright-driven Chromium test was attempted against the locally running server. The execution environment's Chromium returned `net::ERR_BLOCKED_BY_ADMINISTRATOR` for localhost navigation, even though `curl` and Node integration tests could reach the server. Therefore **the browser-driven UI screenshot/assertion run could not be completed here**. The project includes no claim that this particular browser test passed. You can validate visually on your own machine after running `node server.js`.

## Important scope limits

This is an actively runnable local full-stack starter, not a formal penetration test or audited production release. Online live sync depends on deploying this Node server to a persistent host with HTTPS and persistent disk. Payment and courier providers remain unintegrated. SQLite/node:sqlite behavior and single-server assumptions should be reviewed before a large or multi-instance production rollout.
