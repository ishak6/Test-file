@echo off
cd /d "%~dp0"
echo Clothing Store Secure Starter
echo -----------------------------
node --version
if errorlevel 1 (
  echo Node.js is missing. Install Node.js 24 LTS from https://nodejs.org/en/download/
  pause
  exit /b 1
)
node server.js
if errorlevel 1 (
  echo The server stopped with an error. Read the message above.
)
pause
