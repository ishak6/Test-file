# Clothing Store — Secure Local Demo ও Full-stack Starter

এটি আগের এক-ফাইল HTML demo-এর বদলে Node.js server + SQLite database-সহ একটি পূর্ণাঙ্গ local full-stack starter। লোকাল সার্ভার চালু থাকলে একই সার্ভারের সঙ্গে যুক্ত একাধিক browser/ফোন একই পণ্য ও অর্ডার দেখতে পারে। ডেটা `data/store.sqlite`-এ এবং upload করা ছবি `public/uploads/`-এ থাকে।

> নিরাপত্তার বিষয়ে সতর্কতা: কোনো অ্যাপকে “বিশ্বের সেরা” বা শতভাগ নিরাপদ বলা যায় না। এই প্রজেক্টে সাধারণ ঝুঁকি কমানোর কয়েকটি স্তর রয়েছে, কিন্তু লাইভ ব্যবসায় নেওয়ার আগে HTTPS, ডেটাবেস/হোস্টিং, ব্যাকআপ, গোপনীয়তা নোটিশ ও পরীক্ষার ব্যবস্থা ঠিক করতে হবে।

## কী কী আছে

- বাংলা / English storefront ও পণ্যের নাম/বিবরণের bilingual field
- শাড়ি, থ্রি-পিস, কম্বো ও অন্যান্য পোশাকের demo catalog
- Admin থেকে product add / edit / delete, image URL বা JPG/PNG/WebP upload, stock ও availability
- Cart, delivery form, server-side price/stock validation এবং Cash on Delivery order
- order management, status change, cancel করলে stock restore, CSV exports ও JSON backup
- storefront-এ Admin link নেই; `/admin` protected login-এর পরেই dashboard দেখায়
- first-run one-time setup token, scrypt password hashing, server-side session token, HttpOnly cookie, SameSite=Strict, CSRF token, login throttling
- security headers, strict Content Security Policy, request body limit, input validation, rate limiting
- IP block / unblock, admin activity log, consent-ভিত্তিক customer journey analytics
- browser/device User-Agent, IP, page path, page/product/cart/order events দেখা; **কী-স্ট্রোক, পাসওয়ার্ড বা প্রতিটি ফর্ম অক্ষর রেকর্ড করা হয় না**
- product photos ও database স্থানীয় ডিস্কে থাকে, restart হলেও থাকে
- automated Node.js integration/security tests (`npm test`)

## Windows-এ লোকাল চালানোর নিয়ম

### ১. Node.js ইনস্টল করো

Node.js-এর **24 LTS** সংস্করণ সুপারিশ করা হচ্ছে: https://nodejs.org/en/download/ । এই প্রজেক্ট Node.js 22.13+ চায়, কারণ built-in `node:sqlite` ব্যবহার করা হয়েছে; Node.js 22-এ এই API এখনও experimental, তাই নতুন 24 LTS ব্যবহার করা ভালো।

ইনস্টল শেষে Windows Command Prompt/PowerShell খুলে চালাও:

```bat
node --version
npm --version
```

`v24...` দেখা গেলে ভালো।

### ২. ZIP Extract করো

ZIP-টিকে `C:\clothing_store_secure`-এর মতো ফোল্ডারে Extract করো। `server.js`, `package.json`, `public`, `tests` একই root ফোল্ডারে থাকতে হবে।

### ৩. সার্ভার চালাও

সবচেয়ে সহজ উপায়: `RUN_WINDOWS.bat`-এ ডাবল-ক্লিক করো। অথবা ফোল্ডারে terminal খুলে চালাও:

```bat
node server.js
```

টার্মিনালে এই ধরনের তথ্য আসবে:

- Storefront: `http://127.0.0.1:3000/`
- Admin: `http://127.0.0.1:3000/admin/login`
- first-run one-time setup token: টার্মিনালে একবারের জন্য দেখানো হবে

টার্মিনাল বন্ধ কোরো না—সার্ভার চালু রাখার জন্য এটি খোলা থাকতে হবে।

### ৪. প্রথম Admin বানাও

1. `http://127.0.0.1:3000/admin/login` খোলো।
2. টার্মিনালে দেখানো one-time setup token বসাও। এই token শুধু প্রথম Admin তৈরির জন্য; তৈরি হলে token file মুছে যায়।
3. Admin email দাও এবং অন্তত 14 অক্ষরের unique password ব্যবহার করো, যাতে uppercase, lowercase, number ও symbol থাকে।
4. `Create Admin` চাপো। এরপর `/admin`-এ dashboard খুলবে। Token, password বা SQLite database অন্যের সঙ্গে শেয়ার কোরো না।

### ৫. কীভাবে পরীক্ষা করবে

- Customer: `http://127.0.0.1:3000/`
- Admin: `http://127.0.0.1:3000/admin` (login ছাড়া dashboard পাওয়া যাবে না)
- Health check: `http://127.0.0.1:3000/healthz`
- Privacy notice: `http://127.0.0.1:3000/privacy`

Admin → Products → Add Product থেকে পণ্যের নাম, বাংলা/ইংরেজি নাম, category, দাম, stock এবং photo URL বা photo upload দাও। তারপর নতুন tab/অন্য browser-এ storefront খুলে দেখো নতুন পণ্যটি একই local server থেকে আসছে কি না। Cart থেকে demo COD order দাও; Admin → Orders-এ সেটি দেখা উচিত।

### ৬. Automated test চালাও

সার্ভার চালু থাকা অবস্থায় একই project folder থেকে আলাদা terminal-এ:

```bat
npm test
```

Test suite নিজস্ব temporary database ব্যবহার করে; তোমার মূল `data/store.sqlite` বদলানোর উদ্দেশ্য নয়। Test পাস করলে `# pass 2` দেখা যাবে।

## ডেটা কোথায় থাকে

- `data/store.sqlite` — product, admin, setting, order, security event, IP block ইত্যাদি
- `public/uploads/` — Admin দিয়ে upload করা ছবি
- `.setup_token` — প্রথম Admin না হওয়া পর্যন্ত তৈরি হওয়া private setup token; Admin তৈরি হলে স্বয়ংক্রিয়ভাবে মুছে যায়

Backup তৈরি করার সময় Admin → Settings → Download JSON Backup ব্যবহার করা যায়। এতে কাস্টমারের নাম, ফোন, ঠিকানা ও activity থাকতে পারে; নিরাপদ জায়গায় রাখো। ডেটাবেস backup-এর জন্য সার্ভার বন্ধ করে `data/store.sqlite`, `data/store.sqlite-wal`, `data/store.sqlite-shm` থাকলে সবগুলো এবং `public/uploads/` কপি করো। একই সময়ে চলমান database ফাইলের অসম্পূর্ণ কপি নেওয়া এড়িয়ে চলো।

## Real website বানানোর আগে

এই একই Node server online-এ চালাতে হলে **Node-capable long-running host, persistent disk, HTTPS reverse proxy এবং private backups** দরকার। শুধু Cloudflare Pages-এ static HTML হিসেবে আপলোড করলে এই backend চলবে না। SQLite database file ও `public/uploads`-কে persistent storage-এ রাখতে হবে; ephemeral filesystem বা বহু server instance-এ সরাসরি deploy কোরো না। বড়/একাধিক instance-এর জন্য PostgreSQL এবং object storage-এ migrate করা উচিত; এই starter-এর default backend SQLite—PostgreSQL migration এখানে অন্তর্ভুক্ত নয়।

সব ফিচারের অবস্থা `FEATURE_LIST_BN.md`-এ আছে। Live deploy-এর আগে `REAL_DEPLOYMENT_BN.md` ও `SECURITY_CHECKLIST_BN.md` পড়ো। bKash/Nagad ও courier API এই build-এ নেই; payment secret কখনো browser-এ রাখা যাবে না।
