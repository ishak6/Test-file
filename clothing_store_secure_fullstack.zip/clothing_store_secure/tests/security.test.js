'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {createServer,hashPassword,verifyPassword,validateImageUrl,validateCheckout,normalizeIp}=require('../server');

function getSetCookie(response){const v=response.headers.get('set-cookie');return v?v.split(';')[0]:'';}

test('secure store end-to-end: setup, auth, CSRF, products, checkout, activity and IP control',async(t)=>{
  const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'clothing-store-test-'));
  const server=createServer({dbPath:path.join(tmp,'test.sqlite'),uploadDir:path.join(tmp,'uploads'),setupTokenPath:path.join(tmp,'setup.token'),setupToken:'test-one-time-token-should-be-secret'});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base=`http://127.0.0.1:${server.address().port}`;
  let cookie='';let csrf='';
  async function req(route,{method='GET',body,headers={}}={}){
    const h={...headers};if(cookie)h.Cookie=cookie;if(body!==undefined){h['Content-Type']='application/json';body=JSON.stringify(body);}if(csrf && !['GET','HEAD'].includes(method))h['X-CSRF-Token']=csrf;
    const r=await fetch(base+route,{method,headers:h,body});const sc=getSetCookie(r);if(sc)cookie=sc;const ct=r.headers.get('content-type')||'';let data;if(ct.includes('application/json'))data=await r.json();else data=await r.text();return {r,data};
  }
  t.after(async()=>{await new Promise(resolve=>server.close(resolve));try{fs.rmSync(tmp,{recursive:true,force:true});}catch{}});

  const home=await req('/');assert.equal(home.r.status,200);assert.match(home.r.headers.get('content-security-policy'),/default-src 'self'/);assert.equal(home.r.headers.get('x-content-type-options'),'nosniff');assert.match(home.r.headers.get('set-cookie')||'',/HttpOnly/);assert.match(home.r.headers.get('set-cookie')||'',/SameSite=Strict/);assert.doesNotMatch(home.data,/href=["']\/admin["']/i,'public storefront must not link to Admin');
  const boot=await req('/api/bootstrap');assert.equal(boot.r.status,200);csrf=boot.data.csrfToken;assert.equal(boot.data.setupRequired,true);assert.equal(typeof csrf,'string');
  const protectedAdmin=await fetch(base+'/admin',{redirect:'manual'});assert.equal(protectedAdmin.status,303);assert.equal(protectedAdmin.headers.get('location'),'/admin/login');const exposedAdminFile=await fetch(base+'/admin.html');assert.equal(exposedAdminFile.status,404,'admin template must not be directly served as a public static file');
  const noCsrf=await fetch(base+'/api/auth/setup',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:JSON.stringify({setupToken:'test-one-time-token-should-be-secret',email:'owner@example.com',password:'StrongStore#2026Password!'})});assert.equal(noCsrf.status,403,'setup without CSRF must be blocked');
  const setup=await req('/api/auth/setup',{method:'POST',body:{setupToken:'test-one-time-token-should-be-secret',email:'owner@example.com',password:'StrongStore#2026Password!'}});assert.equal(setup.r.status,201,JSON.stringify(setup.data));csrf=setup.data.csrfToken;assert.equal(setup.data.user.email,'owner@example.com');
  const adminPage=await req('/admin');assert.equal(adminPage.r.status,200);assert.match(adminPage.data,/CONTROL CENTER/);
  const unauthorizedCookie=await fetch(base+'/api/admin/orders');assert.equal(unauthorizedCookie.status,401,'request without authenticated cookie must not access admin API');
  const badImage=await req('/api/admin/products',{method:'POST',body:{name:'Unsafe image',category:'test',price:100,stock:1,imageUrl:'javascript:alert(1)'}});assert.equal(badImage.r.status,400);assert.equal(badImage.data.error,'INVALID_IMAGE_URL');
  const created=await req('/api/admin/products',{method:'POST',body:{name:'পরীক্ষার শাড়ি <tag>',nameEn:'Test Saree',category:'শাড়ি',categoryEn:'Saree',description:'Test item',descriptionEn:'Test item',price:1200,compareAt:1500,stock:5,imageUrl:'/assets/saree.svg',active:true}});assert.equal(created.r.status,201,JSON.stringify(created.data));const productId=created.data.product.id;assert.equal(created.data.product.stock,5);
  const publicProducts=await req('/api/products');assert.equal(publicProducts.r.status,200);assert.ok(publicProducts.data.products.some(p=>p.id===productId));
  const uploaded=await req('/api/admin/products',{method:'POST',body:{name:'Upload test',nameEn:'Upload test',category:'শাড়ি',categoryEn:'Saree',price:500,stock:1,imageData:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j+XcAAAAASUVORK5CYII=',active:true}});assert.equal(uploaded.r.status,201,JSON.stringify(uploaded.data));assert.match(uploaded.data.product.imageUrl,/^\/uploads\/[a-f0-9]{32}\.png$/);
  const order=await req('/api/orders',{method:'POST',body:{items:[{productId,quantity:2}],customer:{customerName:'Test Customer',phone:'01712345678',district:'Tangail',upazila:'Sadar',address:'House 10, Road 2, Test Area',notes:'Please call'}}});assert.equal(order.r.status,201,JSON.stringify(order.data));assert.equal(order.data.order.subtotal,2400);assert.equal(order.data.order.total,2480);
  const afterOrder=await req('/api/admin/products');assert.equal(afterOrder.data.products.find(p=>p.id===productId).stock,3);
  const orders=await req('/api/admin/orders');assert.ok(orders.data.orders.some(o=>o.orderNumber===order.data.order.orderNumber));const orderId=orders.data.orders.find(o=>o.orderNumber===order.data.order.orderNumber).id;
  const cancel=await req(`/api/admin/orders/${orderId}`,{method:'PATCH',body:{status:'cancelled'}});assert.equal(cancel.r.status,200);const afterCancel=await req('/api/admin/products');assert.equal(afterCancel.data.products.find(p=>p.id===productId).stock,5);
  const reinstate=await req(`/api/admin/orders/${orderId}`,{method:'PATCH',body:{status:'confirmed'}});assert.equal(reinstate.r.status,200);const afterReinstate=await req('/api/admin/products');assert.equal(afterReinstate.data.products.find(p=>p.id===productId).stock,3);
  // Simulate a different customer's browser, with an independent guest session/cookie.
  let guestCookie='';let guestCsrf='';
  async function guestReq(route,{method='GET',body,headers={}}={}){const h={...headers};if(guestCookie)h.Cookie=guestCookie;if(body!==undefined){h['Content-Type']='application/json';body=JSON.stringify(body);}if(guestCsrf&&!['GET','HEAD'].includes(method))h['X-CSRF-Token']=guestCsrf;const r=await fetch(base+route,{method,headers:h,body});const sc=getSetCookie(r);if(sc)guestCookie=sc;const ct=r.headers.get('content-type')||'';const data=ct.includes('application/json')?await r.json():await r.text();return {r,data};}
  const guestBoot=await guestReq('/api/bootstrap');assert.equal(guestBoot.r.status,200);guestCsrf=guestBoot.data.csrfToken;
  const guestOrder=await guestReq('/api/orders',{method:'POST',body:{items:[{productId,quantity:1}],customer:{customerName:'Independent Guest',phone:'01812345678',district:'Tangail',upazila:'Sadar',address:'Guest address, Test Road 3'}}});assert.equal(guestOrder.r.status,201,JSON.stringify(guestOrder.data));
  const guestOrderVisible=await req('/api/admin/orders');assert.ok(guestOrderVisible.data.orders.some(o=>o.orderNumber===guestOrder.data.order.orderNumber),'an order from a separate guest browser must appear in the Admin database');
  const afterGuestOrder=await req('/api/admin/products');assert.equal(afterGuestOrder.data.products.find(p=>p.id===productId).stock,2);
  const missingCsrf=await fetch(base+'/api/admin/products',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:JSON.stringify({name:'No CSRF',category:'x',price:1,stock:1})});assert.equal(missingCsrf.status,403);
  const block=await req('/api/admin/blocked-ips',{method:'POST',body:{ip:'203.0.113.99',reason:'Automated test'}});assert.equal(block.r.status,201,JSON.stringify(block.data));const blockedList=await req('/api/admin/blocked-ips');assert.ok(blockedList.data.blocked.some(x=>x.ip==='203.0.113.99'));
  const oldTrusted=process.env.TRUSTED_PROXY_IPS;process.env.TRUSTED_PROXY_IPS='127.0.0.1';const blockedVisit=await fetch(base+'/',{headers:{'X-Forwarded-For':'203.0.113.99'},redirect:'manual'});assert.equal(blockedVisit.status,403,'blocked IP cannot open storefront when forwarded only by a configured trusted proxy');const ipv6Block=await req('/api/admin/blocked-ips',{method:'POST',body:{ip:'2001:0db8:0:0:0:0:0:1',reason:'IPv6 canonicalization test'}});assert.equal(ipv6Block.r.status,201);const compressedIpv6Visit=await fetch(base+'/',{headers:{'X-Forwarded-For':'2001:db8::1'},redirect:'manual'});assert.equal(compressedIpv6Visit.status,403,'equivalent IPv6 formats must resolve to the same block entry');if(oldTrusted===undefined)delete process.env.TRUSTED_PROXY_IPS;else process.env.TRUSTED_PROXY_IPS=oldTrusted;const unblock=await req(`/api/admin/blocked-ips/${block.data.id}`,{method:'DELETE'});assert.equal(unblock.r.status,200);const unblockIpv6=await req(`/api/admin/blocked-ips/${ipv6Block.data.id}`,{method:'DELETE'});assert.equal(unblockIpv6.r.status,200);
  const track=await req('/api/track',{method:'POST',body:{event:'page_view',consent:'analytics',path:'/shop',detail:{language:'bn',queryLength:7}}});assert.equal(track.r.status,202);assert.equal(track.data.recorded,true);
  const activity=await req('/api/admin/activity');assert.ok(activity.data.events.some(x=>x.event==='page_view'&&x.path==='/shop'));assert.ok(activity.data.events.some(x=>x.event==='order_placed'));
  const saveSettings=await req('/api/admin/settings',{method:'PUT',body:{storeName:'New Shop',logoUrl:'',contact:'01712345678',shippingFee:100}});assert.equal(saveSettings.r.status,200);assert.equal(saveSettings.data.settings.storeName,'New Shop');
  const backup=await req('/api/admin/backup');assert.equal(backup.r.status,200);assert.equal(backup.data.formatVersion,1);
  for(let i=0;i<5;i++){const bad=await req('/api/auth/login',{method:'POST',body:{email:'attacker@example.test',password:'Incorrect#Password2026'}});assert.equal(bad.r.status,401);}const limited=await req('/api/auth/login',{method:'POST',body:{email:'attacker@example.test',password:'Incorrect#Password2026'}});assert.equal(limited.r.status,429,'repeated failed login is throttled');
});

test('security helpers reject weak or unsafe input',()=>{
  const h=hashPassword('Stronger#Password1234');assert.ok(verifyPassword('Stronger#Password1234',h));assert.equal(verifyPassword('wrong',h),false);
  assert.equal(validateImageUrl('javascript:alert(1)'),null);assert.equal(validateImageUrl('https://example.com/image.jpg'),'https://example.com/image.jpg');assert.equal(validateImageUrl('/assets/saree.svg'),'/assets/saree.svg');
  assert.throws(()=>validateCheckout({items:[],customer:{}}));
});
