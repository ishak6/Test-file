'use strict';
/*
 * Clothing Store secure starter.
 * Runtime: Node.js >= 22.13 (uses the built-in node:sqlite module).
 * Local mode binds to 127.0.0.1. Production must use HTTPS behind a properly
 * configured trusted proxy and persistent database/storage.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const { DatabaseSync } = require('node:sqlite');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const UPLOAD_DIR = path.join(PUBLIC_DIR, 'uploads');
const DEFAULT_DB = path.join(ROOT, 'data', 'store.sqlite');
const COOKIE_NAME = process.env.NODE_ENV === 'production' ? '__Host-clothing_session' : 'clothing_session';
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const GUEST_TTL_MS = 24 * 60 * 60 * 1000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX_FAILURES = 5;
const EVENT_RETENTION_DAYS = 90;
const MAX_BODY_BYTES = 8 * 1024 * 1024;
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
const VALID_EVENTS = new Set(['page_view', 'product_view', 'search', 'add_to_cart', 'checkout_started', 'order_placed', 'language_changed']);
const VALID_STATUSES = new Set(['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'returned']);
const PRODUCT_IMG_EXTS = new Set(['jpg', 'png', 'webp']);
const MIME = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.svg':'image/svg+xml; charset=utf-8', '.jpg':'image/jpeg', '.png':'image/png', '.webp':'image/webp', '.txt':'text/plain; charset=utf-8', '.ico':'image/x-icon' };

function nowIso() { return new Date().toISOString(); }
function sha256(value) { return crypto.createHash('sha256').update(String(value)).digest('hex'); }
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const aa = Buffer.from(a); const bb = Buffer.from(b);
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function canonicalIPv6(input) {
  let address = String(input).toLowerCase();
  // Convert an embedded dotted IPv4 tail to the equivalent two hextets.
  if (address.includes('.')) {
    const splitAt = address.lastIndexOf(':');
    const ipv4 = address.slice(splitAt + 1);
    if (net.isIP(ipv4) === 4) {
      const octets = ipv4.split('.').map(Number);
      const hi = ((octets[0] << 8) | octets[1]).toString(16);
      const lo = ((octets[2] << 8) | octets[3]).toString(16);
      address = address.slice(0, splitAt + 1) + hi + ':' + lo;
    }
  }
  const halves = address.split('::');
  const left = halves[0] ? halves[0].split(':') : [];
  const right = halves.length > 1 && halves[1] ? halves[1].split(':') : [];
  const zeros = halves.length > 1 ? 8 - left.length - right.length : 0;
  const groups = halves.length > 1 ? [...left, ...Array(Math.max(0, zeros)).fill('0'), ...right] : address.split(':');
  if (groups.length !== 8) return address;
  const nums = groups.map(g => Number.parseInt(g || '0', 16));
  let bestStart = -1, bestLength = 1;
  for (let i = 0; i < nums.length;) {
    if (nums[i] !== 0) { i++; continue; }
    let j = i; while (j < nums.length && nums[j] === 0) j++;
    if (j - i > bestLength) { bestStart = i; bestLength = j - i; }
    i = j;
  }
  if (bestStart < 0) return nums.map(n => n.toString(16)).join(':');
  const leftPart = nums.slice(0, bestStart).map(n => n.toString(16)).join(':');
  const rightPart = nums.slice(bestStart + bestLength).map(n => n.toString(16)).join(':');
  return `${leftPart}::${rightPart}`;
}
function normIp(ip) {
  let value = String(ip || 'unknown').trim().replace(/^\[|\]$/g, '');
  // Normalize IPv4-mapped IPv6 addresses to the plain IPv4 address.
  if (/^::ffff:(?:\d{1,3}\.){3}\d{1,3}$/i.test(value)) value = value.slice(7);
  if (value === '::1') return '127.0.0.1';
  const family = net.isIP(value);
  if (family === 4) return value.split('.').map(part => String(Number(part))).join('.');
  if (family === 6) { const canonical = canonicalIPv6(value); return canonical === '::1' ? '127.0.0.1' : canonical; }
  return value;
}
function getClientIp(req) {
  const remote = normIp(req.socket.remoteAddress || 'unknown');
  // Never trust X-Forwarded-For from arbitrary clients. Configure only the exact
  // proxy peer IPs in TRUSTED_PROXY_IPS after network-level access is restricted.
  const trusted = String(process.env.TRUSTED_PROXY_IPS || '').split(',').map(x => normIp(x.trim())).filter(Boolean);
  if (trusted.includes(remote)) {
    const candidates = [req.headers['cf-connecting-ip'], String(req.headers['x-forwarded-for'] || '').split(',')[0]];
    for (const c of candidates) if (c && net.isIP(normIp(String(c).trim()))) return normIp(String(c).trim());
  }
  return remote;
}
function parseCookies(header = '') {
  const result = {};
  for (const piece of header.split(';')) {
    const i = piece.indexOf('='); if (i < 0) continue;
    const key = piece.slice(0, i).trim();
    try { result[key] = decodeURIComponent(piece.slice(i + 1).trim()); } catch { /* ignore invalid cookie */ }
  }
  return result;
}
function isLoopback(ip) { return ['127.0.0.1','::1','localhost'].includes(normIp(ip)); }
function ipInCidrNotSupported() { return false; }
function isHttpsRequest(req) { return !!(req.socket.encrypted || (process.env.NODE_ENV === 'production' && process.env.PUBLIC_HTTPS === '1')); }

function initDatabase(dbPath, uploadDir=UPLOAD_DIR) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  fs.mkdirSync(uploadDir, { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL; PRAGMA trusted_schema = OFF; PRAGMA busy_timeout = 5000;');
  db.exec(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_login_at TEXT,
      active INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      token_hash TEXT NOT NULL UNIQUE,
      csrf_token TEXT NOT NULL,
      user_id INTEGER REFERENCES admins(id),
      role TEXT NOT NULL DEFAULT 'guest' CHECK(role IN ('guest','admin')),
      ip TEXT NOT NULL,
      user_agent TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_seen_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      revoked_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
    CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sku TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      name_en TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL,
      category_en TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      description_en TEXT NOT NULL DEFAULT '',
      price INTEGER NOT NULL CHECK(price > 0),
      compare_at INTEGER NOT NULL DEFAULT 0 CHECK(compare_at >= 0),
      stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
      image_url TEXT NOT NULL DEFAULT '',
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_products_active ON products(active, category);
    CREATE TABLE IF NOT EXISTS store_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT NOT NULL UNIQUE,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      district TEXT NOT NULL,
      upazila TEXT NOT NULL,
      address TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      items_json TEXT NOT NULL,
      subtotal INTEGER NOT NULL,
      shipping_fee INTEGER NOT NULL,
      total INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      stock_reserved INTEGER NOT NULL DEFAULT 1,
      ip TEXT NOT NULL,
      user_agent TEXT NOT NULL,
      referrer TEXT NOT NULL DEFAULT '',
      session_id INTEGER,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_orders_phone ON orders(phone);
    CREATE TABLE IF NOT EXISTS activity_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event TEXT NOT NULL,
      session_id INTEGER,
      ip TEXT NOT NULL,
      user_agent TEXT NOT NULL,
      path TEXT NOT NULL DEFAULT '',
      referrer TEXT NOT NULL DEFAULT '',
      product_id INTEGER,
      order_id INTEGER,
      detail TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_events(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_activity_session ON activity_events(session_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_activity_ip ON activity_events(ip, created_at);
    CREATE TABLE IF NOT EXISTS blocked_ips (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ip TEXT NOT NULL UNIQUE,
      reason TEXT NOT NULL DEFAULT '',
      blocked_by INTEGER REFERENCES admins(id),
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS login_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ip TEXT NOT NULL,
      email_hash TEXT NOT NULL,
      success INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_login_attempts ON login_attempts(ip, email_hash, created_at);
  `);
  const setDefault = db.prepare('INSERT OR IGNORE INTO store_settings(key,value,updated_at) VALUES(?,?,?)');
  const defaults = { storeName:'Your Brand', logoUrl:'', contact:'', shippingFee:80, language:'bn' };
  for (const [key,value] of Object.entries(defaults)) setDefault.run(key, JSON.stringify(value), nowIso());
  if (db.prepare('SELECT COUNT(*) AS n FROM products').get().n === 0) {
    const insert = db.prepare(`INSERT INTO products(sku,name,name_en,category,category_en,description,description_en,price,compare_at,stock,image_url,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    const demo = [
      ['SAREE-001','এলিগ্যান্ট সিল্ক শাড়ি','Elegant Silk Saree','শাড়ি','Saree','বিশেষ মুহূর্তের জন্য বাছাই করা সিল্ক লুক।','A curated silk look for special moments.',1850,2250,15,'/assets/saree.svg',1],
      ['THREE-001','বোটানিক্যাল থ্রি-পিস','Botanical Three-Piece','থ্রি-পিস','Three-piece','প্রকৃতি থেকে অনুপ্রাণিত নকশা ও আরামদায়ক স্টাইল।','Nature-inspired pattern and comfortable style.',1650,0,20,'/assets/threepiece.svg',1],
      ['COMBO-001','সিগনেচার কম্বো প্যাক','Signature Combo Pack','কম্বো প্যাক','Combo Pack','একসঙ্গে বেছে নাও, কম্বো অফারে সাশ্রয় করো।','A coordinated fabric bundle at a combo price.',3200,3800,8,'/assets/combo.svg',1],
      ['KURTI-001','এভরিডে কুর্তি','Everyday Kurti','কুর্তি','Kurti','প্রতিদিনের জন্য সহজ, সুন্দর পোশাক।','An easy, polished outfit for everyday wear.',1250,0,12,'/assets/threepiece.svg',1]
    ];
    const now = nowIso(); for (const row of demo) insert.run(...row, now, now);
  }
  const retention = new Date(Date.now() - EVENT_RETENTION_DAYS*86400000).toISOString();
  db.prepare('DELETE FROM activity_events WHERE created_at < ?').run(retention);
  db.prepare('DELETE FROM sessions WHERE expires_at < ? OR revoked_at IS NOT NULL').run(nowIso());
  db.prepare('DELETE FROM login_attempts WHERE created_at < ?').run(new Date(Date.now()-30*86400000).toISOString());
  return db;
}

function settingsObject(db) {
  const rows = db.prepare('SELECT key,value FROM store_settings').all(); const out = {};
  for (const row of rows) { try { out[row.key] = JSON.parse(row.value); } catch { out[row.key] = row.value; } }
  return out;
}
function setting(db, key, fallback) { const row = db.prepare('SELECT value FROM store_settings WHERE key=?').get(key); if (!row) return fallback; try { return JSON.parse(row.value); } catch { return row.value; } }
function setSetting(db, key, value) { db.prepare('INSERT INTO store_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at').run(key, JSON.stringify(value), nowIso()); }
function rowProduct(p) { return { id:p.id, sku:p.sku, name:p.name, nameEn:p.name_en, category:p.category, categoryEn:p.category_en, description:p.description, descriptionEn:p.description_en, price:p.price, compareAt:p.compare_at, stock:p.stock, imageUrl:p.image_url, active:!!p.active, createdAt:p.created_at, updatedAt:p.updated_at }; }
function rowOrder(o) {
  let items=[]; try { items=JSON.parse(o.items_json); } catch { /* corrupted legacy row */ }
  return { id:o.id, orderNumber:o.order_number, customerName:o.customer_name, phone:o.phone, customer:{district:o.district,upazila:o.upazila,address:o.address,notes:o.notes}, items, itemCount:items.reduce((n,x)=>n+(x.quantity||0),0), subtotal:o.subtotal, shippingFee:o.shipping_fee, total:o.total, status:o.status, ip:o.ip, userAgent:o.user_agent, referrer:o.referrer, sessionId:o.session_id, createdAt:o.created_at, updatedAt:o.updated_at };
}
let lastMaintenanceAt = 0;
function runMaintenance(db) {
  const now = Date.now(); if (now-lastMaintenanceAt < 60*60*1000) return; lastMaintenanceAt = now;
  const current = nowIso(); const retention = new Date(now-EVENT_RETENTION_DAYS*86400000).toISOString();
  db.prepare('DELETE FROM activity_events WHERE created_at < ?').run(retention);
  db.prepare('DELETE FROM sessions WHERE expires_at < ? OR revoked_at IS NOT NULL').run(current);
  db.prepare('DELETE FROM login_attempts WHERE created_at < ?').run(new Date(now-30*86400000).toISOString());
}
function logActivity(db, {event, sessionId=null, ip='unknown', userAgent='', pathName='', referrer='', productId=null, orderId=null, detail=''}) {
  db.prepare(`INSERT INTO activity_events(event,session_id,ip,user_agent,path,referrer,product_id,order_id,detail,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(event, sessionId, String(ip).slice(0,64), String(userAgent).slice(0,500), String(pathName).slice(0,500), String(referrer).slice(0,500), productId, orderId, String(detail).slice(0,300), nowIso());
}
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derived = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64*1024*1024 });
  return `scrypt$16384$8$1$${salt.toString('hex')}$${derived.toString('hex')}`;
}
function verifyPassword(password, encoded) {
  try { const [scheme,n,r,p,saltHex,hashHex] = encoded.split('$'); if (scheme!=='scrypt') return false; const salt=Buffer.from(saltHex,'hex'); const expected=Buffer.from(hashHex,'hex'); const actual=crypto.scryptSync(password,salt,expected.length,{N:Number(n),r:Number(r),p:Number(p),maxmem:64*1024*1024}); return actual.length===expected.length&&crypto.timingSafeEqual(actual,expected); } catch { return false; }
}
function createSession(db, ip, ua, user=null) {
  const token = crypto.randomBytes(32).toString('base64url'); const csrf = crypto.randomBytes(24).toString('base64url'); const now=nowIso(); const ttl=user?SESSION_TTL_MS:GUEST_TTL_MS; const expires=new Date(Date.now()+ttl).toISOString();
  const info = db.prepare('INSERT INTO sessions(token_hash,csrf_token,user_id,role,ip,user_agent,created_at,last_seen_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?)').run(sha256(token),csrf,user?.id||null,user?'admin':'guest',ip,String(ua||'').slice(0,500),now,now,expires);
  return { token, csrfToken:csrf, id:Number(info.lastInsertRowid), user:user?{id:user.id,email:user.email,role:'admin'}:null, role:user?'admin':'guest', expiresAt:expires };
}
function revokeSession(db, tokenHash) { if (tokenHash) db.prepare('UPDATE sessions SET revoked_at=? WHERE token_hash=?').run(nowIso(),tokenHash); }
function hasAdmin(db) { return db.prepare('SELECT id FROM admins WHERE active=1 LIMIT 1').get() != null; }
function getSession(db, req, res, ip) {
  if (res._session) return res._session;
  const raw=parseCookies(req.headers.cookie||'')[COOKIE_NAME]; let row=null;
  if (raw && /^[A-Za-z0-9_-]{32,100}$/.test(raw)) row=db.prepare('SELECT s.*,a.email,a.active FROM sessions s LEFT JOIN admins a ON a.id=s.user_id WHERE s.token_hash=?').get(sha256(raw));
  const good = row && !row.revoked_at && row.expires_at>nowIso() && (row.role!=='admin'||(row.active&&row.user_id));
  if (good) {
    if (Date.now()-Date.parse(row.last_seen_at)>60000) db.prepare('UPDATE sessions SET last_seen_at=? WHERE id=?').run(nowIso(),row.id);
    res._session={id:row.id,tokenHash:row.token_hash,csrfToken:row.csrf_token,role:row.role,user:row.role==='admin'?{id:row.user_id,email:row.email,role:'admin'}:null,expiresAt:row.expires_at};
  } else {
    if (row) db.prepare('DELETE FROM sessions WHERE id=?').run(row.id);
    const s=createSession(db,ip,req.headers['user-agent']||''); res._pendingCookie=s.token;
    res._session={id:s.id,tokenHash:sha256(s.token),csrfToken:s.csrfToken,role:'guest',user:null,expiresAt:s.expiresAt};
  }
  return res._session;
}
function setNewCookie(res, token, user) { res._pendingCookie=token; res._cookieTtl=user?SESSION_TTL_MS:GUEST_TTL_MS; }
function cookieString(req, token, maxAge) {
  let parts=[`${COOKIE_NAME}=${encodeURIComponent(token)}`, 'Path=/', 'HttpOnly', 'SameSite=Strict', `Max-Age=${Math.max(0,Math.floor((maxAge||0)/1000))}`];
  if (process.env.NODE_ENV==='production' && isHttpsRequest(req)) parts.push('Secure');
  return parts.join('; ');
}
function securityHeaders(req, pathname) {
  const headers={
    'X-Content-Type-Options':'nosniff', 'X-Frame-Options':'DENY', 'Referrer-Policy':'strict-origin-when-cross-origin',
    'Permissions-Policy':'camera=(), microphone=(), geolocation=(), payment=()',
    'Content-Security-Policy':"default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self'; style-src 'self'; img-src 'self' https: data:; connect-src 'self';",
    'Cross-Origin-Opener-Policy':'same-origin', 'Cross-Origin-Resource-Policy':'same-origin',
    'Cache-Control': pathname.startsWith('/admin') || pathname.startsWith('/api/admin') ? 'no-store' : 'no-cache',
  };
  if (process.env.NODE_ENV==='production' && isHttpsRequest(req)) headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains';
  return headers;
}
function send(req,res,status,body,contentType='application/json; charset=utf-8',extra={}) {
  if (res.writableEnded) return;
  const headers={...securityHeaders(req,new URL(req.url,'http://local').pathname),...extra,'Content-Type':contentType};
  if (res._pendingCookie) { headers['Set-Cookie']=cookieString(req,res._pendingCookie,res._cookieTtl||(hasAdmin(res._db)?GUEST_TTL_MS:GUEST_TTL_MS)); res._pendingCookie=null; }
  const buf=Buffer.isBuffer(body)?body:Buffer.from(String(body));
  headers['Content-Length']=String(buf.length); res.writeHead(status,headers); res.end(buf);
}
function sendJson(req,res,status,obj,extra={}) { send(req,res,status,JSON.stringify(obj), 'application/json; charset=utf-8',extra); }
function sendError(req,res,status,error,detail) { sendJson(req,res,status,{error, ...(detail?{detail}: {})}); }
function redirect(req,res,location) { send(req,res,303,'', 'text/plain; charset=utf-8',{Location:location}); }
function safeReferrer(req) {
  const ref=String(req.headers.referer||''); if (!ref) return '';
  try { const u=new URL(ref); return `${u.origin}${u.pathname}`.slice(0,500); } catch { return ''; }
}
async function readJson(req, maxBytes=MAX_BODY_BYTES) {
  return new Promise((resolve,reject)=>{
    let size=0, chunks=[]; req.on('data',chunk=>{size+=chunk.length;if(size>maxBytes){reject(Object.assign(new Error('BODY_TOO_LARGE'),{status:413}));req.destroy();return;}chunks.push(chunk);});
    req.on('end',()=>{if(!chunks.length){resolve({});return;}try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));}catch{reject(Object.assign(new Error('INVALID_JSON'),{status:400}));}});
    req.on('error',reject);
  });
}
function checkOrigin(req) {
  const origin=req.headers.origin; if (!origin) return true;
  try { const u=new URL(origin); return u.host.toLowerCase()===String(req.headers.host||'').toLowerCase() && ['http:','https:'].includes(u.protocol); } catch { return false; }
}
function checkCsrf(req, session) {
  if (!checkOrigin(req)) return false;
  const supplied=String(req.headers['x-csrf-token']||'');
  return safeEqual(supplied,session.csrfToken);
}
function requireAdmin(req,res,session) {
  if (session?.role!=='admin'||!session.user) { sendError(req,res,401,'UNAUTHENTICATED'); return false; }
  return true;
}
function validateText(value, max, {required=false,min=0}={}) {
  const str=String(value??'').trim(); if (required && str.length<Math.max(1,min)) return null; if (str.length>max || str.length<min) return null; return str;
}
function validateImageUrl(value) {
  const str=String(value||'').trim(); if (!str) return '';
  if (/^\/uploads\/[a-f0-9]{32}\.(?:jpg|png|webp)$/.test(str)) return str;
  if (/^\/assets\/(?:saree|threepiece|combo)\.svg$/.test(str)) return str;
  try { const u=new URL(str); if (u.protocol==='https:' && u.username==='' && u.password==='' && u.hostname.length<255) return u.toString(); } catch {}
  return null;
}
function saveImageData(dataUrl, uploadDir=UPLOAD_DIR) {
  if (typeof dataUrl!=='string' || dataUrl.length>Math.ceil(MAX_UPLOAD_BYTES*1.42)+100) throw new Error('IMAGE_TOO_LARGE');
  const match=dataUrl.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!match) throw new Error('INVALID_IMAGE');
  const ext=match[1]==='jpeg'?'jpg':match[1]; if(!PRODUCT_IMG_EXTS.has(ext)) throw new Error('INVALID_IMAGE');
  const bytes=Buffer.from(match[2],'base64'); if(bytes.length===0||bytes.length>MAX_UPLOAD_BYTES) throw new Error('IMAGE_TOO_LARGE');
  let valid=false;
  if(ext==='jpg') valid=bytes.length>3&&bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff;
  if(ext==='png') valid=bytes.length>8&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if(ext==='webp') valid=bytes.length>12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP';
  if(!valid) throw new Error('INVALID_IMAGE');
  const filename=crypto.randomBytes(16).toString('hex')+'.'+ext; fs.writeFileSync(path.join(uploadDir,filename),bytes,{flag:'wx',mode:0o644}); return '/uploads/'+filename;
}
function productFromInput(db, body, old=null, uploadDir=UPLOAD_DIR) {
  const name=validateText(body.name,120,{required:true,min:2});
  const nameEn=validateText(body.nameEn,120); const category=validateText(body.category,60,{required:true,min:1}); const categoryEn=validateText(body.categoryEn,60);
  const description=validateText(body.description,2000); const descriptionEn=validateText(body.descriptionEn,2000);
  const price=Number(body.price); const compareAt=Number(body.compareAt||0); const stock=Number(body.stock);
  if(name===null||nameEn===null||category===null||categoryEn===null||description===null||descriptionEn===null) throw new Error('INVALID_PRODUCT_TEXT');
  if(!Number.isSafeInteger(price)||price<1||price>10000000||!Number.isSafeInteger(compareAt)||compareAt<0||compareAt>10000000||!Number.isSafeInteger(stock)||stock<0||stock>1000000) throw new Error('INVALID_PRODUCT_NUMBER');
  let imageUrl=old?.image_url||'';
  if(body.imageData) imageUrl=saveImageData(body.imageData,uploadDir);
  else if(typeof body.imageUrl==='string'&&body.imageUrl.trim()) { const valid=validateImageUrl(body.imageUrl); if(valid===null) throw new Error('INVALID_IMAGE_URL'); imageUrl=valid; }
  else if(typeof body.keepImage==='string'&&body.keepImage.trim()) { const valid=validateImageUrl(body.keepImage); if(valid===null) throw new Error('INVALID_IMAGE_URL'); imageUrl=valid; }
  else if(!old) imageUrl='/assets/saree.svg';
  const active=body.active===undefined?(old?!!old.active:true):!!body.active;
  return {name,nameEn,category,categoryEn,description,descriptionEn,price,compareAt,stock,imageUrl,active};
}
function normalizePhone(value) {
  let s=String(value||'').replace(/[\s()-]/g,''); if(s.startsWith('+88'))s=s.slice(1); if(s.startsWith('8801'))s='0'+s.slice(3);
  return /^01[3-9]\d{8}$/.test(s)?s:null;
}
function validateCheckout(body) {
  const customer=body.customer||{};
  const customerName=validateText(customer.customerName,100,{required:true,min:2}); const phone=normalizePhone(customer.phone);
  const district=validateText(customer.district,80,{required:true,min:2}); const upazila=validateText(customer.upazila,80,{required:true,min:2}); const address=validateText(customer.address,500,{required:true,min:6}); const notes=validateText(customer.notes,300);
  if(customerName===null||!phone||district===null||upazila===null||address===null||notes===null) throw new Error('INVALID_CUSTOMER_DETAILS');
  if(!Array.isArray(body.items)||body.items.length<1||body.items.length>20) throw new Error('INVALID_CART');
  const items=[]; const seen=new Set();
  for(const row of body.items){const productId=Number(row.productId),quantity=Number(row.quantity);if(!Number.isSafeInteger(productId)||productId<1||!Number.isSafeInteger(quantity)||quantity<1||quantity>99||seen.has(productId)) throw new Error('INVALID_CART');seen.add(productId);items.push({productId,quantity});}
  return {customer:{customerName,phone,district,upazila,address,notes},items};
}
function makeOrderNumber() { return 'CS-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase(); }
function ipValid(ip) { const val=normIp(ip); return net.isIP(val)!==0 ? val : null; }
const genericRate = new Map();
function rateLimit(ip, scope, max, windowMs) {
  const key=`${ip}:${scope}`;const now=Date.now();let x=genericRate.get(key);if(!x||now-x.start>windowMs)x={start:now,count:0};x.count++;genericRate.set(key,x);
  if(genericRate.size>5000)for(const [k,v] of genericRate)if(now-v.start>windowMs*2)genericRate.delete(k);
  return x.count<=max;
}

function createServer(options={}) {
  const dbPath=options.dbPath||process.env.STORE_DB_PATH||DEFAULT_DB;
  const uploadDir=options.uploadDir||process.env.STORE_UPLOAD_DIR||UPLOAD_DIR;
  const db=initDatabase(dbPath,uploadDir);
  const setupTokenFile=options.setupTokenPath||path.join(ROOT,'.setup_token');
  let configuredSetupToken=options.setupToken||process.env.SETUP_TOKEN||'';
  const setupTokenWasProvided=Boolean(configuredSetupToken);
  function getSetupToken() {
    if(configuredSetupToken)return configuredSetupToken;
    if(fs.existsSync(setupTokenFile))return fs.readFileSync(setupTokenFile,'utf8').trim();
    const token=crypto.randomBytes(24).toString('base64url');fs.writeFileSync(setupTokenFile,token,{mode:0o600,flag:'wx'});configuredSetupToken=token;return token;
  }
  if(!hasAdmin(db)){
    const token=getSetupToken();
    console.log('\n[FIRST-TIME ADMIN SETUP] Open http://127.0.0.1:'+(options.port||process.env.PORT||3000)+'/admin/login.');
    if(setupTokenWasProvided)console.log('Use the SETUP_TOKEN value configured in your environment; configured secrets are not echoed to logs.');
    else console.log('One-time setup token: '+token);
    console.log('Keep the token private. It will be removed after the first Admin is created.\n');
  }
  function recordSecurity(event,ip,ua,detail=''){try{logActivity(db,{event,ip,userAgent:ua,pathName:'/security',detail});}catch{/* security log failures must not expose internals */}}
  function handler(req,res) { void route(req,res).catch(err=>{
      if(res.writableEnded)return;
      const expected = new Set(['INVALID_IMAGE_URL','INVALID_IMAGE','IMAGE_TOO_LARGE','INVALID_PRODUCT_TEXT','INVALID_PRODUCT_NUMBER','INVALID_CUSTOMER_DETAILS','INVALID_CART','ORDER_TOTAL_INVALID','INVALID_EMAIL','INVALID_IP_OR_REASON','INVALID_SETTINGS','INVALID_LOGO_URL','PASSWORD_POLICY: use 14+ characters with upper/lowercase, number and symbol']);
      const status=err.status||(expected.has(err.message)?400:500);
      if(status===500)console.error('[request error]',req.method,req.url,err?.stack||err);
      try{sendJson(req,res,status,{error:status===500?'INTERNAL_SERVER_ERROR':err.message||'REQUEST_ERROR'});}catch{res.destroy();}
    }); }
  async function route(req,res) {
    const url=new URL(req.url,'http://localhost');const p=url.pathname;const method=req.method||'GET';const ip=getClientIp(req);const ua=String(req.headers['user-agent']||'').slice(0,500);
    res._db=db;
    runMaintenance(db);
    // Blocked visitor cannot shop/place orders, but can reach login and protected admin APIs
    // so a verified administrator can remove an accidental block.
    const adminExempt=p.startsWith('/admin')||p.startsWith('/api/admin')||p.startsWith('/api/auth')||p==='/api/bootstrap'||p==='/healthz';
    const blocked=db.prepare('SELECT id,reason FROM blocked_ips WHERE ip=?').get(ip);
    if(blocked&&!adminExempt&&!p.startsWith('/css/')&&!p.startsWith('/js/')&&!p.startsWith('/assets/')) { recordSecurity('blocked_ip_request',ip,ua,`${method} ${p}`); return sendError(req,res,403,'IP_BLOCKED'); }
    if(p.startsWith('/api/')&&method!=='GET'&&method!=='HEAD'){
      if(!rateLimit(ip,`api:${p.split('/').slice(0,3).join('/')}`,p==='/api/track'?240:80,60_000)){recordSecurity('rate_limited',ip,ua,p);return sendError(req,res,429,'RATE_LIMITED');}
    }
    let session=null;
    if(!p.startsWith('/css/')&&!p.startsWith('/js/')&&!p.startsWith('/assets/')&&!p.startsWith('/uploads/')&&p!=='/robots.txt'&&p!=='/healthz'&&p!=='/favicon.ico') session=getSession(db,req,res,ip);
    const csrfNeeded=['POST','PUT','PATCH','DELETE'].includes(method);
    if(csrfNeeded && !checkCsrf(req,session)) return sendError(req,res,403,'CSRF_VALIDATION_FAILED');

    if(method==='GET'&&p==='/healthz')return sendJson(req,res,200,{ok:true,service:'clothing-store',time:nowIso()});
    if(method==='GET'&&p==='/robots.txt')return send(req,res,200,'User-agent: *\nDisallow: /admin\nDisallow: /api/admin\n','text/plain; charset=utf-8');
    if(method==='GET'&&p==='/')return send(req,res,200,fs.readFileSync(path.join(PUBLIC_DIR,'index.html')),'text/html; charset=utf-8');
    if(method==='GET'&&p==='/privacy')return send(req,res,200,fs.readFileSync(path.join(PUBLIC_DIR,'privacy.html')),'text/html; charset=utf-8');
    if(method==='GET'&&p==='/admin/login')return send(req,res,200,fs.readFileSync(path.join(PUBLIC_DIR,'admin-login.html')),'text/html; charset=utf-8');
    if(method==='GET'&&p==='/admin/setup')return redirect(req,res,'/admin/login');
    if(method==='GET'&&p==='/admin') { if(session?.role!=='admin')return redirect(req,res,'/admin/login');return send(req,res,200,fs.readFileSync(path.join(PUBLIC_DIR,'admin.html')),'text/html; charset=utf-8'); }
    if(method==='GET'&&p==='/api/bootstrap')return sendJson(req,res,200,{csrfToken:session.csrfToken,setupRequired:!hasAdmin(db),authenticated:session.role==='admin',user:session.user,settings:settingsObject(db),currentIp:ip});
    if(method==='GET'&&p==='/api/products'){
      const rows=db.prepare('SELECT * FROM products WHERE active=1 ORDER BY id DESC').all().map(rowProduct);
      return sendJson(req,res,200,{products:rows});
    }
    if(method==='GET'&&p==='/api/categories'){
      const rows=db.prepare('SELECT DISTINCT category,category_en FROM products WHERE active=1 ORDER BY category').all();
      const unique=[...new Set(rows.flatMap(r=>[r.category,...(r.category_en?[r.category_en]:[])]))];return sendJson(req,res,200,{categories:unique});
    }
    if(method==='POST'&&p==='/api/track'){
      const body=await readJson(req,32*1024);if(body.consent!=='analytics')return sendJson(req,res,202,{ok:true,recorded:false});
      const event=String(body.event||'');if(!VALID_EVENTS.has(event))return sendError(req,res,400,'INVALID_EVENT');
      const detail=body.detail&&typeof body.detail==='object'?body.detail:{};let productId=Number(detail.productId);if(!Number.isSafeInteger(productId)||productId<1)productId=null;
      const safeDetail=[];if(typeof detail.language==='string')safeDetail.push(`language=${detail.language==='en'?'en':'bn'}`);if(Number.isFinite(+detail.quantity))safeDetail.push(`quantity=${Math.max(0,Math.min(99,+detail.quantity))}`);if(Number.isFinite(+detail.queryLength))safeDetail.push(`queryLength=${Math.max(0,Math.min(100,+detail.queryLength))}`);
      logActivity(db,{event,sessionId:session.id,ip,userAgent:ua,pathName:cleanPath(p,body.path||req.headers['x-page-path']||'/'),referrer:safeReferrer(req),productId,detail:safeDetail.join('; ')});
      return sendJson(req,res,202,{ok:true,recorded:true});
    }
    if(method==='POST'&&p==='/api/orders'){
      const body=await readJson(req,64*1024);const {customer,items}=validateCheckout(body);let result;
      try {
        db.exec('BEGIN IMMEDIATE');let subtotal=0;const finalItems=[];
        for(const row of items){const product=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(row.productId);if(!product||product.stock<row.quantity)throw new Error('OUT_OF_STOCK');finalItems.push({productId:product.id,sku:product.sku,name:product.name,nameEn:product.name_en,unitPrice:product.price,quantity:row.quantity,imageUrl:product.image_url});subtotal+=product.price*row.quantity;if(!Number.isSafeInteger(subtotal)||subtotal>100000000)throw new Error('ORDER_TOTAL_INVALID');}
        for(const it of finalItems){const updated=db.prepare('UPDATE products SET stock=stock-?,updated_at=? WHERE id=? AND stock>=?').run(it.quantity,nowIso(),it.productId,it.quantity);if(updated.changes!==1)throw new Error('OUT_OF_STOCK');}
        const shippingFee=Number(setting(db,'shippingFee',80));const total=subtotal+shippingFee;const orderNumber=makeOrderNumber();const now=nowIso();
        const ins=db.prepare(`INSERT INTO orders(order_number,customer_name,phone,district,upazila,address,notes,items_json,subtotal,shipping_fee,total,status,stock_reserved,ip,user_agent,referrer,session_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
        const ret=ins.run(orderNumber,customer.customerName,customer.phone,customer.district,customer.upazila,customer.address,customer.notes,JSON.stringify(finalItems),subtotal,shippingFee,total,'pending',1,ip,ua,safeReferrer(req),session.id,now,now);
        result={id:Number(ret.lastInsertRowid),orderNumber,subtotal,shippingFee,total,status:'pending',createdAt:now};db.exec('COMMIT');
      } catch(err) {try{db.exec('ROLLBACK');}catch{} if(err.message==='OUT_OF_STOCK')return sendError(req,res,409,'OUT_OF_STOCK');throw err;}
      logActivity(db,{event:'order_placed',sessionId:session.id,ip,userAgent:ua,pathName:'/checkout',referrer:safeReferrer(req),orderId:result.id,detail:`${result.orderNumber}; total=${result.total}`});
      return sendJson(req,res,201,{ok:true,order:result});
    }
    if(method==='POST'&&p==='/api/auth/setup'){
      const body=await readJson(req,32*1024);if(hasAdmin(db))return sendError(req,res,409,'SETUP_ALREADY_COMPLETE');
      const expected=getSetupToken();if(!safeEqual(String(body.setupToken||''),expected)){recordSecurity('setup_failed',ip,ua);return sendError(req,res,403,'SETUP_TOKEN_INVALID');}
      const email=validateText(body.email,200,{required:true,min:5});const password=String(body.password||'');
      if(email===null||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return sendError(req,res,400,'INVALID_EMAIL');
      if(password.length<14||password.length>200||!/[a-z]/.test(password)||!/[A-Z]/.test(password)||!/[0-9]/.test(password)||!/[^A-Za-z0-9]/.test(password))return sendError(req,res,400,'PASSWORD_POLICY: use 14+ characters with upper/lowercase, number and symbol');
      const tokenHash=session.tokenHash;const ins=db.prepare('INSERT INTO admins(email,password_hash,created_at,active) VALUES(?,?,?,1)').run(email.toLowerCase(),hashPassword(password),nowIso());const admin={id:Number(ins.lastInsertRowid),email:email.toLowerCase()};revokeSession(db,tokenHash);const fresh=createSession(db,ip,ua,admin);setNewCookie(res,fresh.token,admin);recordSecurity('setup_complete',ip,ua,`adminId=${admin.id}`);
      try{if(fs.existsSync(setupTokenFile))fs.rmSync(setupTokenFile,{force:true});}catch{}
      return sendJson(req,res,201,{ok:true,csrfToken:fresh.csrfToken,user:admin});
    }
    if(method==='POST'&&p==='/api/auth/login'){
      const body=await readJson(req,32*1024);const email=String(body.email||'').trim().toLowerCase();const emailHash=sha256(email);const since=new Date(Date.now()-LOGIN_WINDOW_MS).toISOString();const recent=db.prepare('SELECT COUNT(*) AS n FROM login_attempts WHERE ip=? AND email_hash=? AND success=0 AND created_at>?').get(ip,emailHash,since).n;const recentIp=db.prepare('SELECT COUNT(*) AS n FROM login_attempts WHERE ip=? AND success=0 AND created_at>?').get(ip,since).n;
      if(recent>=LOGIN_MAX_FAILURES||recentIp>=20){recordSecurity('rate_limited',ip,ua,'admin login');return sendError(req,res,429,'LOGIN_RATE_LIMIT');}
      const admin=db.prepare('SELECT * FROM admins WHERE email=? COLLATE NOCASE AND active=1').get(email);const password=String(body.password||'');
      if(!admin||password.length>200||!verifyPassword(password,admin.password_hash)) {db.prepare('INSERT INTO login_attempts(ip,email_hash,success,created_at) VALUES(?,?,0,?)').run(ip,emailHash,nowIso());recordSecurity('login_failed',ip,ua,`emailHash=${emailHash.slice(0,12)}`);return sendError(req,res,401,'INVALID_CREDENTIALS');}
      db.prepare('INSERT INTO login_attempts(ip,email_hash,success,created_at) VALUES(?,?,1,?)').run(ip,emailHash,nowIso());db.prepare('DELETE FROM login_attempts WHERE ip=? AND email_hash=? AND success=0').run(ip,emailHash);db.prepare('UPDATE admins SET last_login_at=? WHERE id=?').run(nowIso(),admin.id);
      const tokenHash=session.tokenHash;revokeSession(db,tokenHash);const fresh=createSession(db,ip,ua,admin);setNewCookie(res,fresh.token,admin);recordSecurity('login_success',ip,ua,`adminId=${admin.id}`);return sendJson(req,res,200,{ok:true,csrfToken:fresh.csrfToken,user:{id:admin.id,email:admin.email,role:'admin'}});
    }
    if(method==='POST'&&p==='/api/auth/logout'){
      if(!checkCsrf(req,session))return sendError(req,res,403,'CSRF_VALIDATION_FAILED');revokeSession(db,session.tokenHash);const fresh=createSession(db,ip,ua);setNewCookie(res,fresh.token,null);return sendJson(req,res,200,{ok:true});
    }
    // Static files: only fixed public paths / upload filenames are served.
    if(method==='GET'&&p.startsWith('/css/'))return serveStatic(req,res,p,'css');
    if(method==='GET'&&p.startsWith('/js/'))return serveStatic(req,res,p,'js');
    if(method==='GET'&&p.startsWith('/assets/'))return serveStatic(req,res,p,'assets');
    if(method==='GET'&&p.startsWith('/uploads/'))return serveUploaded(req,res,p,uploadDir);

    if(p.startsWith('/api/admin/') && !requireAdmin(req,res,session)) return;
    if(p.startsWith('/api/admin/') && csrfNeeded && !checkCsrf(req,session))return sendError(req,res,403,'CSRF_VALIDATION_FAILED');
    if(method==='GET'&&p==='/api/admin/overview'){
      const productCount=db.prepare('SELECT COUNT(*) n FROM products').get().n;const orderCount=db.prepare('SELECT COUNT(*) n FROM orders').get().n;const pendingCount=db.prepare("SELECT COUNT(*) n FROM orders WHERE status IN ('pending','confirmed','processing')").get().n;const orderValue=db.prepare("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status NOT IN ('cancelled','returned')").get().n;
      const recentOrders=db.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 8').all().map(rowOrder);const recentActivity=db.prepare('SELECT * FROM activity_events ORDER BY created_at DESC LIMIT 8').all().map(rowActivity);
      return sendJson(req,res,200,{productCount,orderCount,pendingCount,orderValue,recentOrders,recentActivity});
    }
    if(method==='GET'&&p==='/api/admin/products')return sendJson(req,res,200,{products:db.prepare('SELECT * FROM products ORDER BY id DESC').all().map(rowProduct)});
    if(method==='POST'&&p==='/api/admin/products'){
      const body=await readJson(req);const product=productFromInput(db,body,null,uploadDir);const now=nowIso();const sku=`SKU-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
      const ret=db.prepare('INSERT INTO products(sku,name,name_en,category,category_en,description,description_en,price,compare_at,stock,image_url,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(sku,product.name,product.nameEn,product.category,product.categoryEn,product.description,product.descriptionEn,product.price,product.compareAt,product.stock,product.imageUrl,product.active?1:0,now,now);
      logActivity(db,{event:'product_created',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`productId=${ret.lastInsertRowid}`});return sendJson(req,res,201,{ok:true,product:rowProduct(db.prepare('SELECT * FROM products WHERE id=?').get(Number(ret.lastInsertRowid)))});
    }
    const productMatch=p.match(/^\/api\/admin\/products\/(\d+)$/);
    if(productMatch){const id=Number(productMatch[1]);const old=db.prepare('SELECT * FROM products WHERE id=?').get(id);if(!old)return sendError(req,res,404,'PRODUCT_NOT_FOUND');
      if(method==='PUT') {const body=await readJson(req);const product=productFromInput(db,body,old,uploadDir);db.prepare('UPDATE products SET name=?,name_en=?,category=?,category_en=?,description=?,description_en=?,price=?,compare_at=?,stock=?,image_url=?,active=?,updated_at=? WHERE id=?').run(product.name,product.nameEn,product.category,product.categoryEn,product.description,product.descriptionEn,product.price,product.compareAt,product.stock,product.imageUrl,product.active?1:0,nowIso(),id);logActivity(db,{event:'product_updated',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`productId=${id}`});return sendJson(req,res,200,{ok:true,product:rowProduct(db.prepare('SELECT * FROM products WHERE id=?').get(id))});}
      if(method==='DELETE'){db.prepare('DELETE FROM products WHERE id=?').run(id);logActivity(db,{event:'product_deleted',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`productId=${id}`});return sendJson(req,res,200,{ok:true});}
    }
    if(method==='GET'&&p==='/api/admin/orders')return sendJson(req,res,200,{orders:db.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 1000').all().map(rowOrder)});
    const orderMatch=p.match(/^\/api\/admin\/orders\/(\d+)$/);
    if(orderMatch&&method==='PATCH'){
      const id=Number(orderMatch[1]);const body=await readJson(req);const status=String(body.status||'');if(!VALID_STATUSES.has(status))return sendError(req,res,400,'INVALID_ORDER_STATUS');
      const old=db.prepare('SELECT * FROM orders WHERE id=?').get(id);if(!old)return sendError(req,res,404,'ORDER_NOT_FOUND');if(status===old.status)return sendJson(req,res,200,{ok:true,order:rowOrder(old)});
      try{db.exec('BEGIN IMMEDIATE');
        const items=JSON.parse(old.items_json);
        if(status==='cancelled'&&old.stock_reserved){for(const it of items)db.prepare('UPDATE products SET stock=stock+?,updated_at=? WHERE id=?').run(it.quantity,nowIso(),it.productId);db.prepare('UPDATE orders SET stock_reserved=0 WHERE id=?').run(id);}
        else if(old.status==='cancelled'&&status!=='cancelled'&&!old.stock_reserved){for(const it of items){const changed=db.prepare('UPDATE products SET stock=stock-?,updated_at=? WHERE id=? AND active=1 AND stock>=?').run(it.quantity,nowIso(),it.productId,it.quantity);if(changed.changes!==1)throw new Error('OUT_OF_STOCK');}db.prepare('UPDATE orders SET stock_reserved=1 WHERE id=?').run(id);}
        db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run(status,nowIso(),id);db.exec('COMMIT');
      }catch(err){try{db.exec('ROLLBACK');}catch{}if(err.message==='OUT_OF_STOCK')return sendError(req,res,409,'OUT_OF_STOCK');throw err;}
      logActivity(db,{event:'order_status_changed',sessionId:session.id,ip,userAgent:ua,pathName:p,orderId:id,detail:`${old.status} -> ${status}`});return sendJson(req,res,200,{ok:true,order:rowOrder(db.prepare('SELECT * FROM orders WHERE id=?').get(id))});
    }
    if(method==='GET'&&p==='/api/admin/activity'){
      const event=url.searchParams.get('event')||'';const ipFilter=url.searchParams.get('ip')||'';const where=[];const params=[];const allowed=new Set([...VALID_EVENTS,'login_success','login_failed','ip_blocked','ip_unblocked','blocked_ip_request','rate_limited','setup_complete','setup_failed','product_created','product_updated','product_deleted','order_status_changed','settings_updated']);
      if(event&&allowed.has(event)){where.push('event=?');params.push(event);}if(ipFilter){where.push('ip LIKE ?');params.push('%'+ipFilter.slice(0,64)+'%');}
      const query=`SELECT * FROM activity_events ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY created_at DESC LIMIT 1000`;const events=db.prepare(query).all(...params).map(rowActivity);const since=new Date(Date.now()-86400000).toISOString();
      const pageViews24h=db.prepare("SELECT COUNT(*) n FROM activity_events WHERE event='page_view' AND created_at>=?").get(since).n;const sessions24h=db.prepare("SELECT COUNT(DISTINCT session_id) n FROM activity_events WHERE created_at>=?").get(since).n;const cartEvents24h=db.prepare("SELECT COUNT(*) n FROM activity_events WHERE event='add_to_cart' AND created_at>=?").get(since).n;const orderEvents24h=db.prepare("SELECT COUNT(*) n FROM activity_events WHERE event='order_placed' AND created_at>=?").get(since).n;
      const securityEvents=db.prepare("SELECT * FROM activity_events WHERE event IN ('login_success','login_failed','ip_blocked','ip_unblocked','blocked_ip_request','rate_limited','setup_complete','setup_failed') ORDER BY created_at DESC LIMIT 40").all().map(rowActivity);
      return sendJson(req,res,200,{events,metrics:{pageViews24h,sessions24h,cartEvents24h,orderEvents24h},securityEvents});
    }
    if(method==='GET'&&p==='/api/admin/blocked-ips')return sendJson(req,res,200,{blocked:db.prepare('SELECT id,ip,reason,created_at,blocked_by FROM blocked_ips ORDER BY created_at DESC').all().map(x=>({id:x.id,ip:x.ip,reason:x.reason,createdAt:x.created_at,blockedBy:x.blocked_by}))});
    if(method==='POST'&&p==='/api/admin/blocked-ips'){
      const body=await readJson(req,16*1024);const address=ipValid(body.ip);const reason=validateText(body.reason,200);if(!address||reason===null)return sendError(req,res,400,'INVALID_IP_OR_REASON');if(address===ip)return sendError(req,res,409,'CANNOT_BLOCK_CURRENT_IP');
      try{const ret=db.prepare('INSERT INTO blocked_ips(ip,reason,blocked_by,created_at) VALUES(?,?,?,?)').run(address,reason,session.user.id,nowIso());logActivity(db,{event:'ip_blocked',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`target=${address}; id=${ret.lastInsertRowid}`});return sendJson(req,res,201,{ok:true,id:Number(ret.lastInsertRowid)});}catch(err){if(String(err.message).includes('UNIQUE'))return sendError(req,res,409,'IP_ALREADY_BLOCKED');throw err;}
    }
    const blockMatch=p.match(/^\/api\/admin\/blocked-ips\/(\d+)$/);if(blockMatch&&method==='DELETE'){
      const id=Number(blockMatch[1]);const row=db.prepare('SELECT * FROM blocked_ips WHERE id=?').get(id);if(!row)return sendError(req,res,404,'BLOCK_NOT_FOUND');db.prepare('DELETE FROM blocked_ips WHERE id=?').run(id);logActivity(db,{event:'ip_unblocked',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`target=${row.ip}`});return sendJson(req,res,200,{ok:true});
    }
    if(method==='GET'&&p==='/api/admin/settings')return sendJson(req,res,200,{settings:settingsObject(db)});
    if(method==='PUT'&&p==='/api/admin/settings'){
      const body=await readJson(req,32*1024);const storeName=validateText(body.storeName,80,{required:true,min:2});const contact=validateText(body.contact,160);const fee=Number(body.shippingFee);if(storeName===null||contact===null||!Number.isSafeInteger(fee)||fee<0||fee>5000)return sendError(req,res,400,'INVALID_SETTINGS');let logoUrl='';if(body.logoUrl){logoUrl=validateImageUrl(body.logoUrl);if(logoUrl===null)return sendError(req,res,400,'INVALID_LOGO_URL');}
      for(const [k,v] of Object.entries({storeName,logoUrl,contact,shippingFee:fee}))setSetting(db,k,v);logActivity(db,{event:'settings_updated',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:'store settings'});return sendJson(req,res,200,{ok:true,settings:settingsObject(db)});
    }
    if(method==='GET'&&p==='/api/admin/backup'){
      return sendJson(req,res,200,{formatVersion:1,exportedAt:nowIso(),note:'Contains customer personal information. Store this file securely.',products:db.prepare('SELECT * FROM products ORDER BY id').all().map(rowProduct),orders:db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all().map(rowOrder),settings:settingsObject(db),activity:db.prepare('SELECT * FROM activity_events ORDER BY created_at DESC LIMIT 5000').all().map(rowActivity),blockedIps:db.prepare('SELECT ip,reason,created_at FROM blocked_ips').all()},{'Content-Disposition':'attachment; filename="clothing-store-backup.json"','Cache-Control':'no-store'});
    }
    return sendError(req,res,404,'NOT_FOUND');
  }
  function cleanPath(fallback, raw) { let pth=String(raw||fallback||'/').split('?')[0].slice(0,500);if(!pth.startsWith('/'))pth='/';return pth.replace(/[\r\n]/g,''); }
  function rowActivity(a) { return {id:a.id,event:a.event,sessionId:a.session_id,sessionKey:a.session_id?`visitor-${a.session_id}`:'guest',customerLabel:a.session_id?`Visitor #${a.session_id}`:'Guest',ip:a.ip,userAgent:a.user_agent,path:a.path,referrer:a.referrer,productId:a.product_id,orderId:a.order_id,detail:a.detail,createdAt:a.created_at}; }
  function serveStatic(req,res,pathname,folder) {
    const rel=pathname.replace(new RegExp('^/'+folder+'/'),'');const allow=folder==='css'?new Set(['styles.css']):folder==='js'?new Set(['store.js','admin.js','login.js']):new Set(['saree.svg','threepiece.svg','combo.svg']);
    if(!allow.has(rel))return sendError(req,res,404,'NOT_FOUND');const full=path.join(PUBLIC_DIR,folder,rel);if(!fs.existsSync(full))return sendError(req,res,404,'NOT_FOUND');return send(req,res,200,fs.readFileSync(full),MIME[path.extname(full)]||'application/octet-stream');
  }
  function serveUploaded(req,res,pathname,uploadDir=UPLOAD_DIR) { const filename=pathname.slice('/uploads/'.length);if(!/^[a-f0-9]{32}\.(jpg|png|webp)$/.test(filename))return sendError(req,res,404,'NOT_FOUND');const full=path.join(uploadDir,filename);if(!fs.existsSync(full))return sendError(req,res,404,'NOT_FOUND');return send(req,res,200,fs.readFileSync(full),MIME[path.extname(full)]||'application/octet-stream',{'Cache-Control':'public, max-age=86400','Content-Disposition':'inline'}); }
  const server=http.createServer((req,res)=>{
    // Attach a request timeout and avoid Node exposing verbose errors to clients.
    req.setTimeout(15000,()=>{if(!res.headersSent)sendError(req,res,408,'REQUEST_TIMEOUT');else res.destroy();});
    handler(req,res);
  });
  server.on('close',()=>{try{db.close();}catch{}});
  server._storeDb=db;
  return server;
}
if(require.main===module){
  const server=createServer();const host=process.env.HOST||'127.0.0.1';const port=Number(process.env.PORT||3000);
  server.listen(port,host,()=>{const addr=server.address();console.log(`Clothing Store listening at http://${host}:${addr.port}`);console.log(`Public storefront: http://127.0.0.1:${addr.port}/`);console.log(`Protected Admin path: http://127.0.0.1:${addr.port}/admin (no public-store link)`);console.log(`Health check: http://127.0.0.1:${addr.port}/healthz`);console.log('SQLite database: '+(process.env.STORE_DB_PATH||DEFAULT_DB));});
  const stop=()=>server.close(()=>process.exit(0));process.on('SIGINT',stop);process.on('SIGTERM',stop);
}
module.exports={createServer,hashPassword,verifyPassword,validateCheckout,validateImageUrl,normalizeIp:normIp};
