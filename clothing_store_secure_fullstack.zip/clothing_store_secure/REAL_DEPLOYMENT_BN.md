# Real / Online Website Deployment Guide (বাংলা)

## Demo আর live production-এর পার্থক্য

**Local full-stack demo:** `node server.js` চালালে storefront, Admin ও server-side SQLite একই app-এর মাধ্যমে কাজ করে। একই server-এ থাকা বিভিন্ন browser-এর product/order একই database-এ থাকবে। Local server বন্ধ থাকলে বাইরের কেউ সাইটে যেতে পারবে না।

**Online website:** একই server internet-এ hosting করতে হবে। ডোমেইন এখন কিনতে হবে না—hosting-এর সাময়িক subdomain ব্যবহার করা যায়। কিন্তু customer-এর প্রকৃত order নেবার আগে HTTPS, persistent storage, database backup, admin account protection, contact/return policy ও privacy notice ঠিক করতে হবে।

## পথ A — নিজের কম্পিউটারে পরীক্ষা (খরচ ০)

1. `README_BN.md` অনুযায়ী Node.js 24 LTS ইনস্টল করো।
2. `node server.js` চালাও।
3. storefront ও Admin আলাদা tab-এ খোলো।
4. Add Product দিয়ে পণ্য যোগ করে অন্য browser-এ একই URL খোলো; cart/guest browser-এর নয়, server product catalog-এর source data দেখে।
5. Test order দিয়ে Admin → Orders-এ যাচাই করো। Test data-কে real customer order ভেবো না।

## পথ B — পরে online deploy

এই code Node.js + local SQLite এবং local filesystem upload ব্যবহার করে। তাই সাধারণ static hosting যথেষ্ট নয়। Host-এ নিচের সব বৈশিষ্ট্য নিশ্চিত করতে হবে:

- Node.js process দীর্ঘসময় চালানোর সুবিধা
- `data/` এবং `public/uploads/`-এর জন্য persistent disk/volume
- HTTPS/TLS পুরো session জুড়ে
- server log-এ secret/token না রাখা; hosting dashboard ও access সীমিত রাখা
- private, tested backup ও restore process
- কোনো autoscaling/multiple instance চালু করার আগে shared database/object storage migration
- trusted reverse proxy ও client IP header সঠিকভাবে configure করা

### Deployment checklist

1. Project files repository-তে দাও, কিন্তু `data/store.sqlite`, `.setup_token`, upload image files, customer backup বা secret কখনো commit কোরো না। `.gitignore` দেওয়া আছে।
2. Host-এ Node.js 24 LTS select করো; start command `node server.js`।
3. Host-provided `PORT` ব্যবহার করো। App-কে `HOST=0.0.0.0` bind করতে হতে পারে; firewall/reverse-proxy দিয়ে direct unencrypted public access বন্ধ রাখো।
4. TLS termination/HTTPS ঠিকভাবে configure হওয়ার পরেই `NODE_ENV=production` এবং `PUBLIC_HTTPS=1` set করো। HTTPS ছাড়া production cookie `__Host-clothing_session` secure হবে না এবং login কাজ না করাটাই নিরাপদ fail-closed আচরণ।
5. App-এর সামনে থাকা proxy-এর IP ও network access যাচাই করে কেবল তখনই `TRUSTED_PROXY_IPS`-এ exact trusted proxy peer IP বসাও। Arbitrary client-এর `X-Forwarded-For` বিশ্বাস কোরো না। App direct internet-এ উন্মুক্ত রেখে trust proxy enable কোরো না। Cloud provider-এর proxy IP ranges বদলাতে পারে; তাদের অফিসিয়াল তালিকা ও firewall নিয়ম maintain করতে হবে।
6. একবার admin setup করো। এরপর one-time token regenerate না করে password নিরাপদে রাখো। Admin dashboard-এর কোনো public link যোগ কোরো না, কিন্তু মনে রাখো গোপন URL authentication-এর বিকল্প নয়।
7. Test order এবং fake customer data দিয়ে deploy verification করো। Test শেষে fake order/customer/activity delete করে database backup নাও।
8. Public launch-এর আগে payment gateway/courier API আলাদা করে integrate ও sandbox-test করো। Payment verification server-side/webhook-এ করতে হবে, frontend redirect দেখে payment confirmed ধরা যাবে না।

## Database / production data note

SQLite একক server ও তুলনামূলক ছোট দোকানের জন্য পরীক্ষামূলকভাবে সরল। কিন্তু serverless/ephemeral filesystem, multi-instance scaling বা বেশি concurrent checkout-এর জন্য এটি যথেষ্ট deployment model নয়। সেই পর্যায়ে PostgreSQL managed database, object storage, migration scripts, server-side role policies এবং backup restoration দরকার। এই starter-এ PostgreSQL backend লেখা নেই; শুধু hosting config বদলালে SQLite থেকে PostgreSQL হয়ে যাবে না।

## Free subdomain note

ফ্রি hosting-এর terms/limits সময়ের সঙ্গে বদলায়। Free host sleep করতে পারে, disk ephemeral হতে পারে বা database pause/erase policy থাকতে পারে। Customer orders নেওয়ার আগে persistent storage ও backup-এর বাস্তব আচরণ পরীক্ষা করো। Free static hosting দিয়ে শুধু design preview করা যায়; full server/database app চালানোর জন্য backend-capable host লাগবে।
