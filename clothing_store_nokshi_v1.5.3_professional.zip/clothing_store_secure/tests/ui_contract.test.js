'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const project=path.join(__dirname,'..');
const root=path.join(project,'public');
const read=p=>fs.readFileSync(path.join(root,p),'utf8');

test('storefront/Admin UI regression contracts: Order Now and direct image uploads',()=>{
  const index=read('index.html'),admin=read('admin.html'),store=read('js/store.js'),adminJs=read('js/admin.js'),styles=read('css/styles.css'),server=fs.readFileSync(path.join(project,'server.js'),'utf8');
  assert.match(store,/data-order-now-card/,'home product cards must render an Order Now action');
  assert.match(store,/beginDirectCheckout\(product\.id\)/,'unvaried product Order Now must enter the direct checkout path');
  assert.match(store,/data-order-now/,'product detail must preserve its Order Now action');
  assert.match(admin,/name="imageFiles" type="file" multiple/,'Admin must allow multi-select product photo upload');
  assert.doesNotMatch(admin,/name="imageUrls"/,'product editor must not require manually entered photo URLs');
  assert.match(admin,/id="logo-file-input"/,'Admin settings must allow local brand logo upload');
  assert.match(adminJs,/\/api\/admin\/uploads\/image/,'Admin uploads selected files to the authenticated binary endpoint');
  assert.match(adminJs,/Content-Type.*type/,'the selected image MIME type is sent to the binary upload endpoint');
  assert.match(adminJs,/URL\.createObjectURL\(file\)/,'product image compression uses a temporary local image URL');
  assert.match(server,/img-src[^;]*\bblob:/,'CSP must permit local Blob URLs used by the image compression flow');
  assert.match(index,/id="checkout-form"/,'storefront must expose the checkout form');
  assert.match(index,/href="#main-content"/,'storefront should expose a keyboard skip link');
  assert.match(index,/hero-editorial-image[^>]+src="\/assets\/hero-saree\.svg"/,'storefront should use the bundled editorial hero art');
  assert.match(server,/hero-saree\.svg/,'hero artwork must be included in the safe static asset allowlist');

  assert.match(styles,/\#hero-button::after\s*\{[^}]*content:\s*['\"]↗['\"]/,'hero call-to-action keeps its arrow after client-side label updates');  assert.match(server,/brand-mark\.svg/,'favicon artwork must be included in the safe static asset allowlist');
  assert.match(store,/addEventListener\('submit',placeOrder\)/,'checkout submission must be wired');
  assert.match(store,/data.error==='CSRF_VALIDATION_FAILED'[\s\S]*?fetch\('\/api\/bootstrap'/,'storefront must refresh rotated CSRF token and safely retry a rejected mutation once');
  const customerJs=read('js/customer.js');
  assert.match(customerJs,/name=\"rememberMe\" type=\"checkbox\"|rememberMe:fd\.get\('rememberMe'\)==='yes'/,'customer login needs persistent-session option');
  assert.match(customerJs,/configureSocialLogin/,'customer account exposes configured social login');
  assert.match(customerJs,/alternatePhone[\s\S]*?postalCode/,'customer profile supports saved delivery details');
  assert.match(index,/Continue with Google/,'Google OAuth login option is visible');
  assert.match(index,/Continue with Facebook/,'Facebook OAuth login option is visible');
  for(const pattern of [
    /addEventListener\('click',openCart\)/,/addEventListener\('click',closeCart\)/,
    /addEventListener\('click',\(\)=>toggleWishlist/,
    /querySelectorAll\('\[data-order-now-card\]'\)/,
    /querySelectorAll\('\[data-detail\]'\)/,/querySelectorAll\('\[data-add\]'\)/,
    /querySelectorAll\('\[data-wishlist\]'\)/,
    /addEventListener\('submit',lookupOrder\)/,/addEventListener\('click',\(\)=>setConsent\('necessary'\)\)/,
    /addEventListener\('click',\(\)=>setConsent\('allow'\)/
  ]) assert.match(store,pattern,`storefront action handler missing: ${pattern}`);
  for(const pattern of [
    /admin-nav-item[^\n]*addEventListener\('click'/,/\[data-open-tab\][^\n]*addEventListener\('click'/,
    /addEventListener\('click',logout\)/,/addEventListener\('click',\(\)=>openProduct\(\)\)/,
    /addEventListener\('submit',saveProduct\)/,/addEventListener\('submit',blockIp\)/,
    /addEventListener\('submit',saveSettings\)/,/addEventListener\('click',exportBackup\)/,
    /querySelectorAll\('\[data-edit-product\]'\)/,/querySelectorAll\('\[data-delete-product\]'\)/,
    /querySelectorAll\('\[data-status-order\]'\)/,/querySelectorAll\('\[data-view-order\]'\)/,
    /querySelectorAll\('\[data-review-toggle\]'\)/,/querySelectorAll\('\[data-unblock\]'\)/,
    /courier-dispatch'\)\.onclick/,
    /courier-refresh'\)\.onclick/
  ]) assert.match(adminJs,pattern,`Admin action handler missing: ${pattern}`);
});

test('static page templates have no duplicate IDs or inline event handlers',()=>{
  for(const file of ['index.html','admin.html','admin-login.html']){
    const html=read(file);
    const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
    const duplicates=ids.filter((id,i)=>ids.indexOf(id)!==i);
    assert.deepEqual([...new Set(duplicates)],[],`${file}: duplicate IDs`);
    assert.doesNotMatch(html,/<[a-z][^>]*\son[a-z]+\s*=/i,`${file}: inline event attributes are not allowed`);
  }
});
