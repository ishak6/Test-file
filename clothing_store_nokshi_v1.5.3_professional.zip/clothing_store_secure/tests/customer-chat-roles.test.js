'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { createServer } = require('../server');

function makeClient(base) {
  let cookie = '';
  let csrf = '';
  return {
    get cookie() { return cookie; },
    get csrf() { return csrf; },
    async request(route, { method = 'GET', body, headers = {} } = {}) {
      const requestHeaders = { ...headers };
      if (cookie) requestHeaders.Cookie = cookie;
      if (body !== undefined && !Buffer.isBuffer(body)) {
        requestHeaders['Content-Type'] = 'application/json';
        body = JSON.stringify(body);
      }
      if (csrf && !['GET', 'HEAD'].includes(method.toUpperCase())) requestHeaders['X-CSRF-Token'] = csrf;
      const response = await fetch(base + route, { method, headers: requestHeaders, body });
      const setCookie = response.headers.get('set-cookie');
      if (setCookie) cookie = setCookie.split(';')[0];
      const contentType = response.headers.get('content-type') || '';
      const data = contentType.includes('application/json') ? await response.json() : await response.text();
      if (data && typeof data === 'object' && data.csrfToken) csrf = data.csrfToken;
      return { response, data };
    }
  };
}

test('customer accounts, offline support chat, live staff replies, page customization and least-privilege roles', async (t) => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'clothing-store-customer-features-'));
  const oldKey = process.env.OPENAI_API_KEY;
  const oldGoogleId = process.env.GOOGLE_CLIENT_ID, oldGoogleSecret = process.env.GOOGLE_CLIENT_SECRET;
  const oldFacebookId = process.env.FACEBOOK_APP_ID, oldFacebookSecret = process.env.FACEBOOK_APP_SECRET, oldOAuthBase = process.env.OAUTH_BASE_URL;
  delete process.env.OPENAI_API_KEY; delete process.env.GOOGLE_CLIENT_ID; delete process.env.GOOGLE_CLIENT_SECRET; delete process.env.FACEBOOK_APP_ID; delete process.env.FACEBOOK_APP_SECRET;
  const server = createServer({
    dbPath: path.join(tmp, 'store.sqlite'),
    uploadDir: path.join(tmp, 'uploads'),
    setupTokenPath: path.join(tmp, 'setup.token'),
    setupToken: 'feature-test-setup-token'
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;
  const owner = makeClient(base);
  const customer = makeClient(base);
  const moderator = makeClient(base);
  const parent = makeClient(base);
  const db = server._storeDb;
  t.after(async () => {
    await new Promise(resolve => server.close(resolve));
    if (oldKey === undefined) delete process.env.OPENAI_API_KEY; else process.env.OPENAI_API_KEY = oldKey;
    for (const [key,value] of [['GOOGLE_CLIENT_ID',oldGoogleId],['GOOGLE_CLIENT_SECRET',oldGoogleSecret],['FACEBOOK_APP_ID',oldFacebookId],['FACEBOOK_APP_SECRET',oldFacebookSecret],['OAUTH_BASE_URL',oldOAuthBase]]) { if(value===undefined)delete process.env[key];else process.env[key]=value; }
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  let r = await owner.request('/api/bootstrap');
  assert.equal(r.response.status, 200);
  const socialStatus=await customer.request('/api/auth/social/status');
  assert.equal(socialStatus.response.status,200);
  assert.equal(socialStatus.data.googleConfigured,false);
  assert.equal(socialStatus.data.facebookConfigured,false);
  // Provider initiation is a real OAuth redirect when credentials exist; no credential means a clear storefront fallback.
  const startWithoutCredentials=await fetch(base+'/auth/google',{redirect:'manual'});
  assert.equal(startWithoutCredentials.status,303);
  assert.match(startWithoutCredentials.headers.get('location')||'',/socialAuth=google_unconfigured/);
  process.env.GOOGLE_CLIENT_ID='test-google-client';process.env.GOOGLE_CLIENT_SECRET='test-google-secret';process.env.OAUTH_BASE_URL=base;
  const startGoogle=await fetch(base+'/auth/google',{redirect:'manual'});
  assert.equal(startGoogle.status,302);
  assert.match(startGoogle.headers.get('location')||'',/accounts\.google\.com/);
  assert.match(decodeURIComponent(startGoogle.headers.get('location')||''),/auth\/google\/callback/);
  assert.match(startGoogle.headers.get('location')||'',/code_challenge_method=S256/,'OAuth login should use PKCE');
  delete process.env.GOOGLE_CLIENT_ID;delete process.env.GOOGLE_CLIENT_SECRET;delete process.env.OAUTH_BASE_URL;
  r = await owner.request('/api/auth/setup', { method: 'POST', body: { setupToken: 'feature-test-setup-token', email: 'owner@brand.test', password: 'ownerpass123' } });
  assert.equal(r.response.status, 201, JSON.stringify(r.data));
  assert.equal(r.data.user.role, 'admin');
  r = await owner.request('/api/admin/staff');
  assert.equal(r.response.status, 200, 'first-time owner must be authenticated with the owner role');

  const customize = await owner.request('/api/admin/settings', {
    method: 'PUT',
    body: {
      storeName: 'Premium Saree House', contact: '01712345678', shippingFee: 90,
      themePrimary: '#563b32', themeAccent: '#c28b52', pageBackground: '#fff9f2',
      fontFamily: 'noto-serif-bengali', textScale: 'large', buttonStyle: 'soft', announcement: 'নতুন কালেকশন', heroTitle: 'ঈদ কালেকশন',
      heroText: 'নতুন নকশার শাড়ি', heroButton: 'এখনই দেখুন', footerText: 'ধন্যবাদ',
      chatWhatsApp: '8801712345678', messengerUrl: 'https://m.me/examplebrand',
      welcomeMessage: 'স্বাগতম', aiChatEnabled: true,
      sectionVisibility: { hero: true, categories: true, shop: true, combos: false, trackOrder: true, features: false },
      customSections: [{ id: 'sale-banner', title: 'Special Sale', body: 'Up to 20 percent off', layout: 'text', imageUrl: '', buttonLabel: 'Shop now', buttonUrl: '/shop', visible: true, backgroundColor: '#f1e5d8', textColor: '#392820', titleSize: 42, bodySize: 18, fontFamily: 'georgia', textAlign: 'center' }]
    }
  });
  assert.equal(customize.response.status, 200, JSON.stringify(customize.data));
  assert.equal(customize.data.settings.storeName, 'Premium Saree House');
  assert.equal(customize.data.settings.sectionVisibility.combos, false);
  assert.equal(customize.data.settings.customSections[0].title, 'Special Sale');
  assert.equal(customize.data.settings.customSections[0].backgroundColor, '#f1e5d8');
  assert.equal(customize.data.settings.customSections[0].titleSize, 42);
  assert.equal(customize.data.settings.customSections[0].textAlign, 'center');
  assert.equal(customize.data.settings.textScale, 'large');
  assert.equal(customize.data.settings.buttonStyle, 'soft');
  const publicCustomize = await customer.request('/api/bootstrap');
  assert.equal(publicCustomize.data.settings.fontFamily, 'noto-serif-bengali');
  const unsafeStyle = await owner.request('/api/admin/settings', { method: 'PUT', body: { storeName: 'Premium Saree House', contact: '01712345678', shippingFee: 90, customSections: [{ title: 'Unsafe', backgroundColor: '#fff;position:fixed' }] } });
  assert.equal(unsafeStyle.response.status, 400, 'invalid section CSS values must be rejected server-side');
  assert.equal(unsafeStyle.data.error, 'INVALID_CUSTOM_SECTION_COLOUR');
  const status = await customer.request('/api/chat/status');
  assert.equal(status.response.status, 200);
  assert.equal(status.data.whatsappNumber, '8801712345678');
  assert.equal(status.data.messengerUrl, 'https://m.me/examplebrand');

  const register = await customer.request('/api/account/register', { method: 'POST', body: { name: 'Test Buyer', phone: '01799999999', email: 'buyer@brand.test', password: 'customerpass123' } });
  assert.equal(register.response.status, 201, JSON.stringify(register.data));
  assert.equal(register.data.authenticated, true);
  assert.equal(register.data.user.name, 'Test Buyer');
  const me = await customer.request('/api/account/me');
  assert.equal(me.response.status, 200);
  assert.equal(me.data.authenticated, true);
  assert.equal(me.data.user.phone, '01799999999');
  const logout = await customer.request('/api/account/logout', { method: 'POST', body: {} });
  assert.equal(logout.response.status, 200, JSON.stringify(logout.data));
  const login = await customer.request('/api/account/login', { method: 'POST', body: { identity: '01799999999', password: 'customerpass123', rememberMe: true } });
  assert.equal(login.response.status, 200, JSON.stringify(login.data));
  assert.equal(login.data.authenticated, true, 'customer login must restore the account after logout');
  assert.match(login.response.headers.get('set-cookie')||'',/Max-Age=25\d{5}/,'remember-me should keep the authenticated cookie for about 30 days');
  const profile = await customer.request('/api/account/profile',{method:'PATCH',body:{name:'Test Buyer Updated',email:'buyer@brand.test',phone:'01799999999',alternatePhone:'01812345678',district:'Tangail',upazila:'Sadar',address:'House 12, Test Road, Ward 2',postalCode:'1900',preferredLanguage:'bn'}});
  assert.equal(profile.response.status,200,JSON.stringify(profile.data));
  assert.equal(profile.data.user.alternatePhone,'01812345678');
  assert.equal(profile.data.user.address,'House 12, Test Road, Ward 2');
  const bootstrapProfile=await customer.request('/api/bootstrap');
  assert.equal(bootstrapProfile.data.customer.district,'Tangail','saved account delivery information must persist across page refresh/bootstrap');
  const otherCustomer=makeClient(base);await otherCustomer.request('/api/bootstrap');const otherRegister=await otherCustomer.request('/api/account/register',{method:'POST',body:{name:'Other Buyer',phone:'01911111111',email:'other@brand.test',password:'otherbuyerpass123'}});assert.equal(otherRegister.response.status,201,JSON.stringify(otherRegister.data));
  // A verified Google email must not silently attach itself to an account created earlier
  // with that email, since local signup currently has no mail-verification flow.
  const nativeFetch=global.fetch;const savedGoogleId=process.env.GOOGLE_CLIENT_ID,savedGoogleSecret=process.env.GOOGLE_CLIENT_SECRET,savedBase=process.env.OAUTH_BASE_URL;
  process.env.GOOGLE_CLIENT_ID='mock-google-client';process.env.GOOGLE_CLIENT_SECRET='mock-google-secret';process.env.OAUTH_BASE_URL=base;
  try{
    const start=await nativeFetch(base+'/auth/google',{redirect:'manual'});assert.equal(start.status,302);
    const authUrl=new URL(start.headers.get('location'));const oauthCookie=(start.headers.get('set-cookie')||'').match(/oauth_state=([^;]+)/)?.[1];assert.ok(oauthCookie);
    let tokenRedirectUri='';global.fetch=async(input,init={})=>{const target=typeof input==='string'?input:String(input?.url||input);if(target==='https://oauth2.googleapis.com/token'){tokenRedirectUri=init.body?.get?.('redirect_uri')||'';return new Response(JSON.stringify({access_token:'mock-access-token'}),{status:200,headers:{'Content-Type':'application/json'}});}if(target==='https://openidconnect.googleapis.com/v1/userinfo')return new Response(JSON.stringify({sub:'mock-buyer-subject',email:'buyer@brand.test',email_verified:true,name:'Verified Buyer'}),{status:200,headers:{'Content-Type':'application/json'}});return nativeFetch(input,init);};
    const callback=await nativeFetch(base+`/auth/google/callback?state=${encodeURIComponent(authUrl.searchParams.get('state'))}&code=mock-code`,{headers:{Cookie:`oauth_state=${oauthCookie}`,'Host':'attacker.example'},redirect:'manual'});assert.equal(callback.status,303);assert.match(callback.headers.get('location')||'',/socialAuth=account_exists/,'OAuth should require the existing account owner to authenticate, rather than linking by email');assert.equal(tokenRedirectUri,`${base}/auth/google/callback`,'the OAuth callback must use the configured origin rather than a user-supplied Host header');assert.equal(db.prepare("SELECT COUNT(*) AS n FROM customer_oauth_identities WHERE provider='google' AND provider_user_id='mock-buyer-subject'").get().n,0);
  }finally{global.fetch=nativeFetch;for(const [key,value] of [['GOOGLE_CLIENT_ID',savedGoogleId],['GOOGLE_CLIENT_SECRET',savedGoogleSecret],['OAUTH_BASE_URL',savedBase]]){if(value===undefined)delete process.env[key];else process.env[key]=value;}}

  const products = await customer.request('/api/products');
  const product = products.data.products.find(p => p.stock > 0);
  assert.ok(product, 'seed catalog should have an in-stock product');
  const orderBody = { items: [{ productId: product.id, quantity: 1 }], customer: { customerName: 'Test Buyer', phone: '01911111111', district: 'Tangail', upazila: 'Sadar', address: 'House 12, Test Road' } };
  // A stale token after authenticated account login must be rejected before mutation; bootstrap can issue the current token and the order then succeeds.
  const staleCsrf = await fetch(base + '/api/orders', { method: 'POST', headers: { Cookie: customer.cookie, 'Content-Type': 'application/json', 'X-CSRF-Token': 'deliberately-stale-token' }, body: JSON.stringify(orderBody) });
  assert.equal(staleCsrf.status, 403, 'stale CSRF token must not permit an order');
  assert.equal((await staleCsrf.json()).error, 'CSRF_VALIDATION_FAILED');
  const refreshedSession = await customer.request('/api/bootstrap');
  assert.equal(refreshedSession.response.status, 200);
  assert.ok(refreshedSession.data.csrfToken, 'bootstrap must provide a refreshable CSRF token after login');
  const order = await customer.request('/api/orders', { method: 'POST', body: orderBody });
  assert.equal(order.response.status, 201, JSON.stringify(order.data));
  const customerOrders = await customer.request('/api/account/orders');
  assert.equal(customerOrders.response.status, 200);
  assert.ok(customerOrders.data.orders.some(o => o.orderNumber === order.data.order.orderNumber), 'customer should see orders placed in the signed-in session');
  const unchangedProfile=await customer.request('/api/account/me');assert.equal(unchangedProfile.data.user.phone,'01799999999','placing an order with a phone owned by another account must not mutate the signed-in account phone');
  const normalizedTrack=await customer.request(`/api/order-status?orderNumber=${encodeURIComponent(order.data.order.orderNumber)}&phone=${encodeURIComponent('+8801911111111')}`);assert.equal(normalizedTrack.response.status,200,'tracking should accept the +880 form of the checkout phone');
  const earlyReview=await customer.request('/api/reviews',{method:'POST',body:{productId:product.id,orderNumber:order.data.order.orderNumber,phone:'01911111111',customerName:'Test Buyer',rating:5,title:'Review',body:'Delivered later, should reject now.'}});assert.equal(earlyReview.response.status,409,'a pending order cannot receive a verified purchase review');

  const token = crypto.randomBytes(32).toString('hex');
  const old = new Date(Date.now() - 4 * 60_000).toISOString();
  db.prepare("UPDATE sessions SET last_seen_at=? WHERE role IN ('admin','moderator','parent')").run(old);
  const chatStart = await customer.request('/api/chat/session', { method: 'POST', body: { clientToken: token, name: 'Test Buyer', phone: '01799999999' } });
  assert.equal(chatStart.response.status, 200, JSON.stringify(chatStart.data));
  const chatMessage = await customer.request('/api/chat/messages', { method: 'POST', headers: { 'X-Chat-Token': token }, body: { clientToken: token, message: 'ডেলিভারি চার্জ কত?' } });
  assert.equal(chatMessage.response.status, 201, JSON.stringify(chatMessage.data));
  assert.equal(chatMessage.data.staffOnline, false, 'offline staff should activate automatic support reply');
  assert.ok(chatMessage.data.messages.some(m => m.senderRole === 'ai' && /ডেলিভারি চার্জ/.test(m.body)), 'fallback assistant should answer common delivery questions without an API key');
  const humanHandoff=await customer.request('/api/chat/messages',{method:'POST',headers:{'X-Chat-Token':token},body:{clientToken:token,message:'I want to talk to a human about my order'}});assert.equal(humanHandoff.response.status,201);const handoffReply=humanHandoff.data.messages.filter(m=>m.senderRole==='ai').at(-1);assert.ok(handoffReply&&/মানুষের সহায়তা/.test(handoffReply.body),'human-agent requests should take priority over the order FAQ intent');

  db.prepare("UPDATE sessions SET last_seen_at=? WHERE role='admin'").run(new Date().toISOString());
  const chatThreads = await owner.request('/api/admin/chat/threads');
  assert.equal(chatThreads.response.status, 200, JSON.stringify(chatThreads.data));
  const thread = chatThreads.data.threads.find(x => x.phone === '01799999999');
  assert.ok(thread, 'chat from customer should appear in the Admin inbox');
  const staffReply = await owner.request(`/api/admin/chat/threads/${thread.id}`, { method: 'POST', body: { message: 'ধন্যবাদ, আমরা সাহায্য করছি।' } });
  assert.equal(staffReply.response.status, 201, JSON.stringify(staffReply.data));
  const customerMessages = await customer.request('/api/chat/messages', { headers: { 'X-Chat-Token': token } });
  assert.ok(customerMessages.data.messages.some(m => m.senderRole === 'admin' && m.body.includes('সাহায্য করছি')), 'customer widget must receive replies posted from Admin');

  const modCreated = await owner.request('/api/admin/staff', { method: 'POST', body: { email: 'moderator@brand.test', password: 'moderatorpass123', role: 'moderator', permissions: ['chat'] } });
  assert.equal(modCreated.response.status, 201, JSON.stringify(modCreated.data));
  const parentCreated = await owner.request('/api/admin/staff', { method: 'POST', body: { email: 'parent@brand.test', password: 'parentpass123', role: 'parent', permissions: ['customers'] } });
  assert.equal(parentCreated.response.status, 201, JSON.stringify(parentCreated.data));
  const ordersOnly = makeClient(base);const ordersOnlyCreated=await owner.request('/api/admin/staff',{method:'POST',body:{email:'orders@brand.test',password:'orderspass123',role:'moderator',permissions:['orders']}});assert.equal(ordersOnlyCreated.response.status,201);await ordersOnly.request('/api/bootstrap');const ordersOnlyLogin=await ordersOnly.request('/api/auth/login',{method:'POST',body:{email:'orders@brand.test',password:'orderspass123'}});assert.equal(ordersOnlyLogin.response.status,200);

  const modBoot = await moderator.request('/api/bootstrap');
  assert.equal(modBoot.data.authenticated, false, 'staff account must log in before accessing Admin');
  const modLogin = await moderator.request('/api/auth/login', { method: 'POST', body: { email: 'moderator@brand.test', password: 'moderatorpass123' } });
  assert.equal(modLogin.response.status, 200, JSON.stringify(modLogin.data));
  assert.equal(modLogin.data.user.role, 'moderator');
  assert.deepEqual(modLogin.data.user.permissions, ['chat']);
  assert.equal((await moderator.request('/api/admin/chat/threads')).response.status, 200, 'moderator with chat permission should access chat');
  assert.equal((await moderator.request('/api/admin/products')).response.status, 403, 'moderator without product permission must be denied server-side');
  assert.equal((await moderator.request('/api/admin/settings')).response.status, 403, 'moderator without customization permission must be denied server-side');
  assert.equal((await moderator.request('/api/admin/backup')).response.status,403,'backup must not be exposed to a non-owner moderator');
  const customModerator=makeClient(base);const customModeratorCreated=await owner.request('/api/admin/staff',{method:'POST',body:{email:'custom@brand.test',password:'custompass123',role:'moderator',permissions:['customization']}});assert.equal(customModeratorCreated.response.status,201,JSON.stringify(customModeratorCreated.data));await customModerator.request('/api/bootstrap');const customLogin=await customModerator.request('/api/auth/login',{method:'POST',body:{email:'custom@brand.test',password:'custompass123'}});assert.equal(customLogin.response.status,200);assert.equal((await customModerator.request('/api/admin/backup')).response.status,403,'customization permission must not grant backup access to all customer records');
  const productModerator=makeClient(base);const productModeratorCreated=await owner.request('/api/admin/staff',{method:'POST',body:{email:'products@brand.test',password:'productpass123',role:'moderator',permissions:['products']}});assert.equal(productModeratorCreated.response.status,201,JSON.stringify(productModeratorCreated.data));await productModerator.request('/api/bootstrap');const productLogin=await productModerator.request('/api/auth/login',{method:'POST',body:{email:'products@brand.test',password:'productpass123'}});assert.equal(productLogin.response.status,200);const onePixelPng=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j+XcAAAAASUVORK5CYII=','base64');const uploadByProductModerator=await productModerator.request('/api/admin/uploads/image',{method:'POST',headers:{'Content-Type':'image/png'},body:onePixelPng});assert.equal(uploadByProductModerator.response.status,201,'a products moderator should be allowed to upload product photos');

  const parentBoot = await parent.request('/api/bootstrap');
  assert.equal(parentBoot.response.status, 200);
  const parentLogin = await parent.request('/api/auth/login', { method: 'POST', body: { email: 'parent@brand.test', password: 'parentpass123' } });
  assert.equal(parentLogin.response.status, 200, JSON.stringify(parentLogin.data));
  assert.equal(parentLogin.data.user.role, 'parent');
  assert.equal((await parent.request('/api/admin/customers')).response.status, 200, 'parent role can only access the explicit customer permission');
  assert.equal((await parent.request('/api/admin/orders')).response.status, 403, 'parent cannot browse orders without orders permission');
  assert.equal((await moderator.request('/api/admin/staff')).response.status, 403, 'moderator cannot manage staff');
  db.prepare("UPDATE sessions SET last_seen_at=? WHERE role IN ('admin','moderator','parent')").run(new Date(Date.now()-4*60_000).toISOString());db.prepare("UPDATE sessions SET last_seen_at=? WHERE user_id=(SELECT id FROM admins WHERE email='orders@brand.test')").run(new Date().toISOString());const onlineCheck=await customer.request('/api/chat/status');assert.equal(onlineCheck.data.staffOnline,false,'orders-only moderator must not count as online chat staff');

  const activity = await owner.request('/api/admin/activity');
  assert.ok(activity.data.events.some(e => e.event === 'customer_registered'));
  assert.ok(activity.data.events.some(e => e.event === 'chat_message'));
  assert.ok(activity.data.events.some(e => e.event === 'order_placed' && e.customerLabel.includes('Test Buyer')), 'activity should show actual account/customer names when known');

  // A disabled AI assistant should leave the message queued for a human without adding an automatic response.
  const noAi = await owner.request('/api/admin/settings', { method: 'PUT', body: { storeName: 'Premium Saree House', contact: '', shippingFee: 90, aiChatEnabled: false } });
  assert.equal(noAi.response.status, 200);
  const token2 = crypto.randomBytes(32).toString('hex');
  db.prepare("UPDATE sessions SET last_seen_at=? WHERE role IN ('admin','moderator','parent')").run(old);
  await customer.request('/api/chat/session', { method: 'POST', body: { clientToken: token2, name: 'Test Buyer', phone: '01799999999' } });
  const pending = await customer.request('/api/chat/messages', { method: 'POST', headers: { 'X-Chat-Token': token2 }, body: { clientToken: token2, message: 'একজন মানুষের সঙ্গে কথা বলতে চাই' } });
  assert.equal(pending.response.status, 201);
  assert.equal(pending.data.messages.filter(m => m.senderRole === 'ai').length, 0, 'disabled assistant must not generate a fallback reply');

  assert.equal((await customer.request('/js/customer.js')).response.status, 200);
  assert.equal((await customer.request('/js/chat.js')).response.status, 200);
});
