# QA Report — Premium Clothing Store v1.5.3

পরীক্ষার তারিখ: 2026-10-20

## v1.5.3 release checks

- `node --check server.js`, সব `public/js/*.js` এবং `tests/*.js` — PASS।
- `npm test` — 6 top-level automated tests passed, 0 failed।
- নতুন hero art `/assets/hero-saree.svg`, favicon `/assets/brand-mark.svg` ও existing product SVG assets-এর server allowlist/MIME/response body automated regression test — PASS।
- Existing integration checks retain coverage for owner-only backup, moderator scope, checkout phone/profile separation, invalid/missing variants, `+880` tracking, delivered-only reviews, return stock restoration, null cart, CSRF handling, settings/image upload, OAuth account-conflict protection and proxy CIDR handling।
- `GET /healthz`, `/`, `/api/products`, `/assets/hero-saree.svg`, `/assets/brand-mark.svg` এবং `/admin/login` fresh local server-এ smoke-tested — PASS।
- Browser-driven real click-through visual QA: **not completed**. The managed Chromium environment blocked both localhost and file navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`; PNG previews are static layout previews generated from the actual templates/CSS plus sample catalogue data, not live browser interaction evidence.

## Remaining live/prod checks

- Google/Facebook provider credentials ও actual provider consent/callback flow পরীক্ষা করা হয়নি।
- Steadfast live shipment booking/status-এর জন্য merchant credentials দরকার; live courier action পরীক্ষা করা হয়নি।
- Full email verification ও forgot-password reset flow-এর জন্য email provider + expiring tokens এখনও দরকার।
- Public launch-এর আগে merchant domain-এ Chrome/mobile real-device check, HTTPS, persistent hosting, backup restore drill, and policy/contact details যাচাই করতে হবে।

---


## Automated checks

- `node --check server.js` — PASS
- `node --check public/js/store.js` — PASS
- `node --check` — PASS for every JavaScript file in the project (`server.js`, storefront/Admin/login scripts and test files)
- `npm test` — 6 top-level test cases passed, 0 failed
- Multi-photo product update: gallery array and primary photo persistence verified; mixed existing + HTTPS + uploaded photos test passed
- Product gallery image limit: 11 photos rejected with HTTP 400; maximum 10 enforced
- Homepage product cards and Product Details contain `Order Now`; variant selection is retained in direct checkout. Admin product uploader supports up to 10 local JPG/PNG/WebP files per product; logo is uploadable from Admin Settings with no URL entry.
- Image upload root cause fix: CSP now permits browser-local `blob:` images required by the product-photo compression step; regression test checks that rule.
- Isolated live-server smoke test: `/healthz`, `/`, `/api/products`, `/admin/login` all HTTP 200; response CSP includes the local-image `blob:` source
- HTML scan: `index.html`, `admin.html`, `admin-login.html`-এ duplicate ID নেই এবং inline event handler নেই

Integration/security test-এর মধ্যে আছে admin setup/auth, CSRF, protected Admin, unsafe image rejection, product add, color/size persistence, unsupported variant reject (400), COD checkout/stock transaction, customer order lookup, manual courier shipment save/public tracking metadata, verified-purchase review submit/admin moderation/public approved review, IP block/unblock, activity, settings, backup এবং login throttling।

## Courier integration status

- Manual courier records: automated test passed.
- Customer order tracking endpoint returns courier provider, tracking/consignment ID, status, tracking URL and last update, while omitting customer identity/address.
- Steadfast create-order and status refresh are implemented server-side, but live provider booking/status was **not tested** because merchant credentials are not available in this QA run. Add `STEADFAST_API_KEY` and `STEADFAST_SECRET_KEY` privately in `.env` to enable it.
- Pathao/RedX/Paperfly/Sundarban can be recorded manually with tracking ID and tracking URL. Their live API booking/status sync is not implemented in this version.

## Browser visual QA limitation

HTML/JS syntax and structural scans passed, but full browser screenshot/interactions could not be validated in this environment; Chromium was prevented from opening localhost by the environment browser policy. Do not interpret this as a formal penetration test or production certification. Run the website in Chrome locally and verify the product modal, variants, review forms, admin shipment form and mobile layout before public launch.

## Security and deployment limits

- Existing SQLite installations are upgraded with additive migrations for product options, `images_json` gallery storage and new tables; still back up `data/store.sqlite` before replacing files.
- `.env` is ignored by Git; never commit courier API keys.
- Live status uses a bounded server-side Steadfast request when a customer checks an order and falls back to last saved status if provider/network is unavailable. Other providers are manual-only.
- This build is not deployed online. Public launch still requires Node-capable hosting, HTTPS, persistent disk, backups/restore verification, provider credentials, privacy/returns terms and actual production verification.
- No payment gateway integration is included. COD only.


## v1.4.1 password-policy retest
- Admin setup rejects passwords shorter than 8 characters.
- Admin setup accepts an 8-character password without requiring uppercase/lowercase/symbol combinations.
- `node --check server.js`, `node --check public/js/login.js`, and `npm test` passed after this change.


## v1.4.2 gallery and Order Now regression checks
- `node --check server.js`, `node --check public/js/store.js`, `node --check public/js/admin.js` — PASS.
- `npm test` — PASS (3 suites, 0 failed), including multi-photo persistence with an uploaded image, primary-photo compatibility and >10-image rejection.
- Static HTML scan — no duplicate IDs or inline event handlers.
- Full browser interaction/screenshot test could not run because the managed headless browser denied localhost access; manual Chrome verification is still recommended.


## v1.4.3 direct-order/upload regression checks
- `node --check server.js`, `public/js/store.js`, `public/js/admin.js`, `public/js/login.js`, `tests/security.test.js` — PASS.
- `npm test` — 5 test cases PASS, 0 failures.
- Direct raw-file image upload endpoint: pass; uploaded image served from local `/uploads/`; missing CSRF rejected; unused upload delete checked.
- Admin settings: uploaded logo path persists successfully.
- Same product ordered with two distinct color/size selections: pass; order contains both variants.
- Static HTML/JS contract scan: no duplicate IDs or inline event handlers; homepage and detail-page Order Now handlers, checkout submit wiring, multi-photo file input, logo upload, and binary upload content type are asserted by regression tests. Other dynamic controls were code-inspected and underlying API flows were integration-tested where covered.
- Browser interaction test was attempted, but this environment’s managed Chromium blocks navigation to localhost with `ERR_BLOCKED_BY_ADMINISTRATOR`; as a result, end-to-end UI clicks could not be honestly marked as browser-tested here. Node integration/API tests passed, but a final local Chrome pass is still recommended before going live.


## v1.5.0 customer, live-chat, staff roles and customization regression
- Customer register/login/profile/order history — automated integration coverage.
- Offline AI/FAQ response and staff reply round-trip — automated integration coverage.
- Admin/moderator/parent least-privilege enforcement — unauthorized endpoints return 403 in automated tests.
- Activity logs reflect customer registration, chat messages, order events and customer labels when linked data exists.
- Global design controls and per-custom-section colour, alignment, font and size validation — automated API tests.
- JavaScript syntax checks, duplicate HTML ID scan, static route smoke checks and full `npm test` run performed before release.
- Browser-driven click-by-click visual QA was not available in the current execution environment; do not describe it as completed.


## v1.5.1 customer checkout/session/social login checks
- `node --check` on server, all storefront/Admin scripts and test scripts — PASS.
- `npm test` — 6 top-level tests PASS, 0 failed; includes customer register/logout/login, 30-day remember cookie Max-Age, extended profile save/read after bootstrap, login then customer order, OAuth status/unconfigured redirect and configured Google authorization redirect construction.
- CSRF retry UI contract verified by static regression test: on `CSRF_VALIDATION_FAILED`, the storefront fetches `/api/bootstrap` and retries a non-GET request at most once. Server integration suite validates order submission immediately after customer login.
- Static HTML audit confirms no duplicate IDs and no inline handlers in storefront/Admin/login pages.
- OAuth provider callback was not externally completed because client credentials are not provided; actual Google/Facebook consent and provider-account verification must be tested after configuring credentials/redirect URIs.
- Browser visual/real-click QA is not available in this environment; Node integration tests and local server smoke checks are not a substitute for a Chrome test on the merchant's actual domain.


## v1.5.2 Bug Review regression checks (2026-10-19)

- `node --check` passed on JavaScript source files.
- `npm test`: all 6 bundled Node test cases passed, including regression checks for owner-only backup, product moderator image uploads, account-phone preservation during checkout, `+880` phone tracking, review eligibility, returned-stock restoration, chat-role availability, OAuth account pre-hijacking and CIDR proxy handling.
- Browser visual/click testing against real Google/Facebook credentials was not run. Google OAuth account-conflict handling was tested with mocked provider responses.
