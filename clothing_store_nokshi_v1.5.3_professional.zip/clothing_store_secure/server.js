'use strict';
/*
 * Clothing Store secure starter.
 * Runtime: Node.js >= 22.13 (uses the built-in node:sqlite module).
 * Local mode binds to 127.0.0.1. Production must use HTTPS behind a properly
 * configured trusted proxy and persistent database/storage.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const net = require('node:net');
const { DatabaseSync } = require('node:sqlite');

// Load simple KEY=value entries from a private .env file without adding a dependency.
// Existing process/host environment variables always take precedence.
(function loadLocalEnv(){
  try { const file=fs.readFileSync(path.join(__dirname,'.env'),'utf8'); for (const line of file.split(/\r?\n/)) { const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/); if(!m||m[1].startsWith('#')||Object.prototype.hasOwnProperty.call(process.env,m[1]))continue; let value=m[2]; if((value.startsWith('"')&&value.endsWith('"'))||(value.startsWith("'")&&value.endsWith("'")))value=value.slice(1,-1); process.env[m[1]]=value; } } catch {}
})();

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const UPLOAD_DIR = path.join(PUBLIC_DIR, 'uploads');
const DEFAULT_DB = path.join(ROOT, 'data', 'store.sqlite');
const COOKIE_NAME = process.env.NODE_ENV === 'production' ? '__Host-clothing_session' : 'clothing_session';
const SESSION_TTL_MS = 12 * 60 * 60 * 1000;
const CUSTOMER_REMEMBER_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const GUEST_TTL_MS = 24 * 60 * 60 * 1000;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_MAX_FAILURES = 5;
const EVENT_RETENTION_DAYS = 90;
const MAX_BODY_BYTES = 8 * 1024 * 1024;
const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
const STAFF_ROLES = new Set(['admin','moderator','parent']);
const STAFF_PERMISSIONS = new Set(['dashboard','products','orders','reviews','activity','security','customization','chat','customers','staff']);
const VALID_EVENTS = new Set(['page_view', 'product_view', 'search', 'add_to_cart', 'checkout_started', 'order_placed', 'language_changed']);
const VALID_STATUSES = new Set(['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'returned']);
const VALID_SHIPMENT_STATUSES = new Set(['booked','pending_pickup','picked_up','in_transit','out_for_delivery','delivered','returned','cancelled','pending','in_review','hold','delivered_approval_pending','partial_delivered_approval_pending','partial_delivered','cancelled_approval_pending','unknown','unknown_approval_pending']);
const PRODUCT_IMG_EXTS = new Set(['jpg', 'png', 'webp']);
const MIME = { '.html':'text/html; charset=utf-8', '.css':'text/css; charset=utf-8', '.js':'text/javascript; charset=utf-8', '.svg':'image/svg+xml; charset=utf-8', '.jpg':'image/jpeg', '.png':'image/png', '.webp':'image/webp', '.txt':'text/plain; charset=utf-8', '.ico':'image/x-icon' };

function nowIso() { return new Date().toISOString(); }
function sha256(value) { return crypto.createHash('sha256').update(String(value)).digest('hex'); }
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string') return false;
  const aa = Buffer.from(a); const bb = Buffer.from(b);
  return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}
function canonicalIPv6(input) {
  let address = String(input).toLowerCase();
  // Convert an embedded dotted IPv4 tail to the equivalent two hextets.
  if (address.includes('.')) {
    const splitAt = address.lastIndexOf(':');
    const ipv4 = address.slice(splitAt + 1);
    if (net.isIP(ipv4) === 4) {
      const octets = ipv4.split('.').map(Number);
      const hi = ((octets[0] << 8) | octets[1]).toString(16);
      const lo = ((octets[2] << 8) | octets[3]).toString(16);
      address = address.slice(0, splitAt + 1) + hi + ':' + lo;
    }
  }
  const halves = address.split('::');
  const left = halves[0] ? halves[0].split(':') : [];
  const right = halves.length > 1 && halves[1] ? halves[1].split(':') : [];
  const zeros = halves.length > 1 ? 8 - left.length - right.length : 0;
  const groups = halves.length > 1 ? [...left, ...Array(Math.max(0, zeros)).fill('0'), ...right] : address.split(':');
  if (groups.length !== 8) return address;
  const nums = groups.map(g => Number.parseInt(g || '0', 16));
  let bestStart = -1, bestLength = 1;
  for (let i = 0; i < nums.length;) {
    if (nums[i] !== 0) { i++; continue; }
    let j = i; while (j < nums.length && nums[j] === 0) j++;
    if (j - i > bestLength) { bestStart = i; bestLength = j - i; }
    i = j;
  }
  if (bestStart < 0) return nums.map(n => n.toString(16)).join(':');
  const leftPart = nums.slice(0, bestStart).map(n => n.toString(16)).join(':');
  const rightPart = nums.slice(bestStart + bestLength).map(n => n.toString(16)).join(':');
  return `${leftPart}::${rightPart}`;
}
function normIp(ip) {
  let value = String(ip || 'unknown').trim().replace(/^\[|\]$/g, '');
  // Normalize IPv4-mapped IPv6 addresses to the plain IPv4 address.
  if (/^::ffff:(?:\d{1,3}\.){3}\d{1,3}$/i.test(value)) value = value.slice(7);
  if (value === '::1') return '127.0.0.1';
  const family = net.isIP(value);
  if (family === 4) return value.split('.').map(part => String(Number(part))).join('.');
  if (family === 6) { const canonical = canonicalIPv6(value); return canonical === '::1' ? '127.0.0.1' : canonical; }
  return value;
}
function ipAsBigInt(value) {
  const address = normIp(value); const family = net.isIP(address);
  if (family === 4) return { family, bits: 32, value: address.split('.').reduce((n, part) => (n << 8n) | BigInt(Number(part)), 0n) };
  if (family !== 6) return null;
  const halves = address.split('::');
  const left = halves[0] ? halves[0].split(':') : [];
  const right = halves.length > 1 && halves[1] ? halves[1].split(':') : [];
  const groups = halves.length > 1 ? [...left, ...Array(Math.max(0, 8-left.length-right.length)).fill('0'), ...right] : address.split(':');
  if (groups.length !== 8 || groups.some(g => !/^[0-9a-f]{1,4}$/i.test(g))) return null;
  return { family, bits: 128, value: groups.reduce((n, group) => (n << 16n) | BigInt(parseInt(group,16)), 0n) };
}
function ipMatchesCidr(ip, entry) {
  const value = String(entry || '').trim(); if (!value) return false;
  const [networkText, prefixText, extra] = value.split('/'); if (extra !== undefined) return false;
  const address = normIp(networkText); const network = ipAsBigInt(address); const target = ipAsBigInt(ip);
  if (!network || !target || network.family !== target.family) return false;
  if (prefixText === undefined) return network.value === target.value;
  if (!/^\d{1,3}$/.test(prefixText)) return false;
  const prefix = Number(prefixText); if (prefix < 0 || prefix > network.bits) return false;
  const shift = BigInt(network.bits - prefix);
  return (network.value >> shift) === (target.value >> shift);
}
function getClientIp(req) {
  const remote = normIp(req.socket.remoteAddress || 'unknown');
  // Forwarded client IPs are trusted only when the direct peer matches a
  // specifically configured trusted proxy IP or CIDR range.
  const trusted = String(process.env.TRUSTED_PROXY_IPS || '').split(',').map(x => x.trim()).filter(Boolean);
  const isTrusted = value => trusted.some(entry => ipMatchesCidr(value, entry));
  if (isTrusted(remote)) {
    const cf = String(req.headers['cf-connecting-ip'] || '').trim();
    if (cf && net.isIP(normIp(cf)) && cf.split(',').length === 1) return normIp(cf);
    const chain = String(req.headers['x-forwarded-for'] || '').split(',').map(x => normIp(x.trim())).filter(x => net.isIP(x));
    // Walk from the closest hop outwards, skipping trusted proxy hops. This
    // avoids blindly accepting the leftmost value supplied by a client.
    for (let i = chain.length - 1; i >= 0; i--) if (!isTrusted(chain[i])) return chain[i];
  }
  return remote;
}
function parseCookies(header = '') {
  const result = {};
  for (const piece of header.split(';')) {
    const i = piece.indexOf('='); if (i < 0) continue;
    const key = piece.slice(0, i).trim();
    try { result[key] = decodeURIComponent(piece.slice(i + 1).trim()); } catch { /* ignore invalid cookie */ }
  }
  return result;
}
function isLoopback(ip) { return ['127.0.0.1','::1','localhost'].includes(normIp(ip)); }
function ipInCidrNotSupported() { return false; }
function isHttpsRequest(req) { return !!(req.socket.encrypted || (process.env.NODE_ENV === 'production' && process.env.PUBLIC_HTTPS === '1')); }
function resolveOAuthBase(req) {
  const configured=String(process.env.OAUTH_BASE_URL||'').trim();
  const candidate=configured||(process.env.NODE_ENV==='production'?'':`http://127.0.0.1:${Number(process.env.PORT)||3000}`);
  try { const parsed=new URL(candidate); if(!['http:','https:'].includes(parsed.protocol)||parsed.username||parsed.password||parsed.search||parsed.hash||parsed.pathname!=='/'||(process.env.NODE_ENV==='production'&&parsed.protocol!=='https:'))return '';return parsed.origin; } catch { return ''; }
}

function initDatabase(dbPath, uploadDir=UPLOAD_DIR) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  fs.mkdirSync(uploadDir, { recursive: true });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA synchronous = FULL; PRAGMA trusted_schema = OFF; PRAGMA busy_timeout = 5000;');
  db.exec(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_login_at TEXT,
      active INTEGER NOT NULL DEFAULT 1,
      role TEXT NOT NULL DEFAULT 'admin',
      permissions_json TEXT NOT NULL DEFAULT '[]',
      created_by INTEGER REFERENCES admins(id)
    );
    CREATE TABLE IF NOT EXISTS customer_accounts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      full_name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      email TEXT UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      last_login_at TEXT,
      alternate_phone TEXT NOT NULL DEFAULT '',
      district TEXT NOT NULL DEFAULT '',
      upazila TEXT NOT NULL DEFAULT '',
      address TEXT NOT NULL DEFAULT '',
      postal_code TEXT NOT NULL DEFAULT '',
      preferred_language TEXT NOT NULL DEFAULT 'bn'
    );
    CREATE INDEX IF NOT EXISTS idx_customers_created ON customer_accounts(created_at DESC);
    CREATE TABLE IF NOT EXISTS oauth_states (
      state_hash TEXT PRIMARY KEY, provider TEXT NOT NULL CHECK(provider IN ('google','facebook')),
      code_verifier TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, expires_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_oauth_states_expiry ON oauth_states(expires_at);
    CREATE TABLE IF NOT EXISTS customer_oauth_identities (
      id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL CHECK(provider IN ('google','facebook')),
      provider_user_id TEXT NOT NULL, customer_account_id INTEGER NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
      email TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, UNIQUE(provider,provider_user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_oauth_identity_customer ON customer_oauth_identities(customer_account_id);
    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      token_hash TEXT NOT NULL UNIQUE,
      csrf_token TEXT NOT NULL,
      user_id INTEGER REFERENCES admins(id),
      role TEXT NOT NULL DEFAULT 'guest' CHECK(role IN ('guest','admin','moderator','parent','customer')),
      customer_id INTEGER REFERENCES customer_accounts(id),
      ip TEXT NOT NULL,
      user_agent TEXT NOT NULL,
      created_at TEXT NOT NULL,
      last_seen_at TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      revoked_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_sessions_token ON sessions(token_hash);
    CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sku TEXT NOT NULL UNIQUE,
      name TEXT NOT NULL,
      name_en TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL,
      category_en TEXT NOT NULL DEFAULT '',
      description TEXT NOT NULL DEFAULT '',
      description_en TEXT NOT NULL DEFAULT '',
      price INTEGER NOT NULL CHECK(price > 0),
      compare_at INTEGER NOT NULL DEFAULT 0 CHECK(compare_at >= 0),
      stock INTEGER NOT NULL DEFAULT 0 CHECK(stock >= 0),
      image_url TEXT NOT NULL DEFAULT '',
      images_json TEXT NOT NULL DEFAULT '[]',
      colors_json TEXT NOT NULL DEFAULT '[]',
      sizes_json TEXT NOT NULL DEFAULT '[]',
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_products_active ON products(active, category);
    CREATE TABLE IF NOT EXISTS store_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_number TEXT NOT NULL UNIQUE,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      district TEXT NOT NULL,
      upazila TEXT NOT NULL,
      address TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      items_json TEXT NOT NULL,
      subtotal INTEGER NOT NULL,
      shipping_fee INTEGER NOT NULL,
      total INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      stock_reserved INTEGER NOT NULL DEFAULT 1,
      ip TEXT NOT NULL,
      user_agent TEXT NOT NULL,
      referrer TEXT NOT NULL DEFAULT '',
      session_id INTEGER,
      customer_account_id INTEGER REFERENCES customer_accounts(id),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
    CREATE INDEX IF NOT EXISTS idx_orders_phone ON orders(phone);
    CREATE TABLE IF NOT EXISTS activity_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      event TEXT NOT NULL,
      session_id INTEGER,
      ip TEXT NOT NULL,
      user_agent TEXT NOT NULL,
      path TEXT NOT NULL DEFAULT '',
      referrer TEXT NOT NULL DEFAULT '',
      product_id INTEGER,
      order_id INTEGER,
      detail TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_activity_created ON activity_events(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_activity_session ON activity_events(session_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_activity_ip ON activity_events(ip, created_at);
    CREATE TABLE IF NOT EXISTS blocked_ips (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ip TEXT NOT NULL UNIQUE,
      reason TEXT NOT NULL DEFAULT '',
      blocked_by INTEGER REFERENCES admins(id),
      created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS login_attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      ip TEXT NOT NULL,
      email_hash TEXT NOT NULL,
      success INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_login_attempts ON login_attempts(ip, email_hash, created_at);
    CREATE TABLE IF NOT EXISTS courier_shipments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id) ON DELETE CASCADE,
      provider TEXT NOT NULL DEFAULT 'manual',
      tracking_number TEXT NOT NULL DEFAULT '',
      consignment_id TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'pending_pickup',
      tracking_url TEXT NOT NULL DEFAULT '',
      note TEXT NOT NULL DEFAULT '',
      raw_status TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS chat_threads (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      client_token_hash TEXT NOT NULL UNIQUE,
      customer_id INTEGER REFERENCES customer_accounts(id),
      guest_name TEXT NOT NULL DEFAULT 'Guest customer',
      guest_phone TEXT NOT NULL DEFAULT '',
      status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','waiting','resolved')),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      last_message_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_chat_threads_recent ON chat_threads(last_message_at DESC);
    CREATE TABLE IF NOT EXISTS chat_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      thread_id INTEGER NOT NULL REFERENCES chat_threads(id) ON DELETE CASCADE,
      sender_role TEXT NOT NULL CHECK(sender_role IN ('customer','admin','ai')),
      sender_id INTEGER,
      body TEXT NOT NULL,
      created_at TEXT NOT NULL,
      read_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_chat_messages_thread ON chat_messages(thread_id, id);
    CREATE TABLE IF NOT EXISTS product_reviews (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
      order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
      customer_name TEXT NOT NULL,
      rating INTEGER NOT NULL CHECK(rating BETWEEN 1 AND 5),
      title TEXT NOT NULL DEFAULT '',
      body TEXT NOT NULL,
      approved INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL,
      UNIQUE(product_id, order_id)
    );
    CREATE INDEX IF NOT EXISTS idx_reviews_product ON product_reviews(product_id, approved, created_at DESC);
  `);
  // Safe additive migrations for existing SQLite installs.
  const adminColumns = new Set(db.prepare('PRAGMA table_info(admins)').all().map(c => c.name));
  if (!adminColumns.has('role')) db.exec("ALTER TABLE admins ADD COLUMN role TEXT NOT NULL DEFAULT 'admin'");
  if (!adminColumns.has('permissions_json')) db.exec("ALTER TABLE admins ADD COLUMN permissions_json TEXT NOT NULL DEFAULT '[]'");
  if (!adminColumns.has('created_by')) db.exec('ALTER TABLE admins ADD COLUMN created_by INTEGER REFERENCES admins(id)');
  const sessionSql = String(db.prepare("SELECT sql FROM sqlite_master WHERE type='table' AND name='sessions'").get()?.sql || '');
  if (!sessionSql.includes("'customer'") || !sessionSql.includes("'moderator'")) {
    db.exec(`DROP INDEX IF EXISTS idx_sessions_token; DROP INDEX IF EXISTS idx_sessions_expiry;
      ALTER TABLE sessions RENAME TO sessions_legacy;
      CREATE TABLE sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT, token_hash TEXT NOT NULL UNIQUE, csrf_token TEXT NOT NULL,
        user_id INTEGER REFERENCES admins(id), customer_id INTEGER REFERENCES customer_accounts(id),
        role TEXT NOT NULL DEFAULT 'guest' CHECK(role IN ('guest','admin','moderator','parent','customer')),
        ip TEXT NOT NULL, user_agent TEXT NOT NULL, created_at TEXT NOT NULL, last_seen_at TEXT NOT NULL,
        expires_at TEXT NOT NULL, revoked_at TEXT
      );
      INSERT INTO sessions(id,token_hash,csrf_token,user_id,customer_id,role,ip,user_agent,created_at,last_seen_at,expires_at,revoked_at)
      SELECT id,token_hash,csrf_token,user_id,NULL,role,ip,user_agent,created_at,last_seen_at,expires_at,revoked_at FROM sessions_legacy;
      DROP TABLE sessions_legacy;
      CREATE INDEX idx_sessions_token ON sessions(token_hash);
      CREATE INDEX idx_sessions_expiry ON sessions(expires_at);`);
  }
  const oauthStateColumns = new Set(db.prepare('PRAGMA table_info(oauth_states)').all().map(c => c.name));
  if (!oauthStateColumns.has('code_verifier')) db.exec("ALTER TABLE oauth_states ADD COLUMN code_verifier TEXT NOT NULL DEFAULT ''");
  const customerColumns = new Set(db.prepare('PRAGMA table_info(customer_accounts)').all().map(c => c.name));
  const customerMigrations = {
    alternate_phone: "TEXT NOT NULL DEFAULT ''", district: "TEXT NOT NULL DEFAULT ''", upazila: "TEXT NOT NULL DEFAULT ''",
    address: "TEXT NOT NULL DEFAULT ''", postal_code: "TEXT NOT NULL DEFAULT ''", preferred_language: "TEXT NOT NULL DEFAULT 'bn'"
  };
  for (const [column, sqlType] of Object.entries(customerMigrations)) if (!customerColumns.has(column)) db.exec(`ALTER TABLE customer_accounts ADD COLUMN ${column} ${sqlType}`);
  db.exec(`CREATE TABLE IF NOT EXISTS oauth_states (state_hash TEXT PRIMARY KEY, provider TEXT NOT NULL CHECK(provider IN ('google','facebook')), code_verifier TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, expires_at TEXT NOT NULL);
    CREATE INDEX IF NOT EXISTS idx_oauth_states_expiry ON oauth_states(expires_at);
    CREATE TABLE IF NOT EXISTS customer_oauth_identities (id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT NOT NULL CHECK(provider IN ('google','facebook')), provider_user_id TEXT NOT NULL, customer_account_id INTEGER NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE, email TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, UNIQUE(provider,provider_user_id));
    CREATE INDEX IF NOT EXISTS idx_oauth_identity_customer ON customer_oauth_identities(customer_account_id);`);
  const orderColumns = new Set(db.prepare('PRAGMA table_info(orders)').all().map(c => c.name));
  if (!orderColumns.has('customer_account_id')) db.exec('ALTER TABLE orders ADD COLUMN customer_account_id INTEGER REFERENCES customer_accounts(id)');
  const productColumns = new Set(db.prepare('PRAGMA table_info(products)').all().map(c => c.name));
  if (!productColumns.has('images_json')) db.exec("ALTER TABLE products ADD COLUMN images_json TEXT NOT NULL DEFAULT '[]'");
  if (!productColumns.has('colors_json')) db.exec("ALTER TABLE products ADD COLUMN colors_json TEXT NOT NULL DEFAULT '[]'");
  if (!productColumns.has('sizes_json')) db.exec("ALTER TABLE products ADD COLUMN sizes_json TEXT NOT NULL DEFAULT '[]'");
  const setDefault = db.prepare('INSERT OR IGNORE INTO store_settings(key,value,updated_at) VALUES(?,?,?)');
  const defaults = { storeName:'Nokshi Atelier', logoUrl:'', contact:'', shippingFee:80, language:'bn', themePrimary:'#49352d', themeAccent:'#bd8b60', pageBackground:'#fffaf6', fontFamily:'system', textScale:'normal', buttonStyle:'rounded', announcement:'নতুন কালেকশন এসেছে · সারা বাংলাদেশে ডেলিভারি', heroTitle:'ঐতিহ্যের ছোঁয়ায় তোমার নিজস্ব স্টাইল', heroText:'শাড়ি, থ্রি-পিস ও বাছাই করা কালেকশন—প্রতিটি বিশেষ মুহূর্তের জন্য।', heroButton:'কালেকশন দেখুন', footerText:'তোমার প্রতিদিনের স্টাইলে একটু বিশেষ ছোঁয়া।', chatWhatsApp:'', messengerUrl:'', welcomeMessage:'স্বাগতম! কীভাবে সাহায্য করতে পারি?', aiChatEnabled:true, sectionVisibility:{hero:true,categories:true,shop:true,combos:true,trackOrder:true,features:true}, customSections:[] };
  for (const [key,value] of Object.entries(defaults)) setDefault.run(key, JSON.stringify(value), nowIso());
  if (db.prepare('SELECT COUNT(*) AS n FROM products').get().n === 0) {
    const insert = db.prepare(`INSERT INTO products(sku,name,name_en,category,category_en,description,description_en,price,compare_at,stock,image_url,colors_json,sizes_json,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
    const demo = [
      ['SAREE-001','এলিগ্যান্ট সিল্ক শাড়ি','Elegant Silk Saree','শাড়ি','Saree','বিশেষ মুহূর্তের জন্য বাছাই করা সিল্ক লুক।','A curated silk look for special moments.',1850,2250,15,'/assets/saree.svg',1],
      ['THREE-001','বোটানিক্যাল থ্রি-পিস','Botanical Three-Piece','থ্রি-পিস','Three-piece','প্রকৃতি থেকে অনুপ্রাণিত নকশা ও আরামদায়ক স্টাইল।','Nature-inspired pattern and comfortable style.',1650,0,20,'/assets/threepiece.svg',1],
      ['COMBO-001','সিগনেচার কম্বো প্যাক','Signature Combo Pack','কম্বো প্যাক','Combo Pack','একসঙ্গে বেছে নাও, কম্বো অফারে সাশ্রয় করো।','A coordinated fabric bundle at a combo price.',3200,3800,8,'/assets/combo.svg',1],
      ['KURTI-001','এভরিডে কুর্তি','Everyday Kurti','কুর্তি','Kurti','প্রতিদিনের জন্য সহজ, সুন্দর পোশাক।','An easy, polished outfit for everyday wear.',1250,0,12,'/assets/threepiece.svg',1]
    ];
    const now = nowIso(); for (const row of demo) insert.run(...row.slice(0,11), '[]', '[]', row[11], now, now);
  }
  const retention = new Date(Date.now() - EVENT_RETENTION_DAYS*86400000).toISOString();
  db.prepare('DELETE FROM activity_events WHERE created_at < ?').run(retention);
  db.prepare('DELETE FROM sessions WHERE expires_at < ? OR revoked_at IS NOT NULL').run(nowIso());
  db.prepare('DELETE FROM login_attempts WHERE created_at < ?').run(new Date(Date.now()-30*86400000).toISOString());
  return db;
}

function settingsObject(db) {
  const rows = db.prepare('SELECT key,value FROM store_settings').all(); const out = {};
  for (const row of rows) { try { out[row.key] = JSON.parse(row.value); } catch { out[row.key] = row.value; } }
  return out;
}
function setting(db, key, fallback) { const row = db.prepare('SELECT value FROM store_settings WHERE key=?').get(key); if (!row) return fallback; try { return JSON.parse(row.value); } catch { return row.value; } }
function setSetting(db, key, value) { db.prepare('INSERT INTO store_settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at').run(key, JSON.stringify(value), nowIso()); }
function uploadedFilenames(value) {
  const urls=Array.isArray(value)?value:[value];const names=[];
  for(const url of urls){const match=String(url||'').match(/^\/uploads\/([a-f0-9]{32}\.(?:jpg|png|webp))$/);if(match)names.push(match[1]);}
  return names;
}
function deleteUnusedUploadedFiles(db, uploadDir, candidates) {
  const unique=[...new Set(candidates.filter(name=>/^[a-f0-9]{32}\.(?:jpg|png|webp)$/.test(name||'')))];
  if(!unique.length)return;
  const productRows=db.prepare('SELECT image_url,images_json FROM products').all();
  const settings=settingsObject(db);const settingsRefs=[settings.logoUrl,...(Array.isArray(settings.customSections)?settings.customSections.map(x=>x?.imageUrl):[])];
  for(const filename of unique){const url='/uploads/'+filename;
    const productUse=productRows.some(row=>row.image_url===url||safeJsonArray(row.images_json).includes(url));
    const settingUse=settingsRefs.includes(url);
    const orderUse=Boolean(db.prepare('SELECT 1 FROM orders WHERE items_json LIKE ? LIMIT 1').get(`%${url}%`));
    if(!productUse&&!settingUse&&!orderUse)try{fs.rmSync(path.join(uploadDir,filename),{force:true});}catch{}
  }
}
function safeJsonArray(value) { try { const a=JSON.parse(value||'[]'); return Array.isArray(a)?a:[]; } catch { return []; } }
function rowProduct(p) { const images=safeJsonArray(p.images_json); if(!images.length&&p.image_url)images.push(p.image_url); return { id:p.id, sku:p.sku, name:p.name, nameEn:p.name_en, category:p.category, categoryEn:p.category_en, description:p.description, descriptionEn:p.description_en, price:p.price, compareAt:p.compare_at, stock:p.stock, imageUrl:images[0]||p.image_url||'', imageUrls:images, colors:safeJsonArray(p.colors_json), sizes:safeJsonArray(p.sizes_json), active:!!p.active, createdAt:p.created_at, updatedAt:p.updated_at }; }
function rowShipment(row) { return row ? { provider:row.provider, trackingNumber:row.tracking_number, consignmentId:row.consignment_id, status:row.status, trackingUrl:row.tracking_url, note:row.note, rawStatus:row.raw_status, createdAt:row.created_at, updatedAt:row.updated_at } : null; }
function rowOrder(o) {
  let items=[]; try { items=JSON.parse(o.items_json); } catch { /* corrupted legacy row */ }
  const shipment=o.id?null:null; return { id:o.id, orderNumber:o.order_number, customerName:o.customer_name, phone:o.phone, customer:{district:o.district,upazila:o.upazila,address:o.address,notes:o.notes}, items, itemCount:items.reduce((n,x)=>n+(x.quantity||0),0), subtotal:o.subtotal, shippingFee:o.shipping_fee, total:o.total, status:o.status, ip:o.ip, userAgent:o.user_agent, referrer:o.referrer, sessionId:o.session_id, createdAt:o.created_at, updatedAt:o.updated_at };
}
let lastMaintenanceAt = 0;
function runMaintenance(db) {
  const now = Date.now(); if (now-lastMaintenanceAt < 60*60*1000) return; lastMaintenanceAt = now;
  const current = nowIso(); const retention = new Date(now-EVENT_RETENTION_DAYS*86400000).toISOString();
  db.prepare('DELETE FROM activity_events WHERE created_at < ?').run(retention);
  db.prepare('DELETE FROM sessions WHERE expires_at < ? OR revoked_at IS NOT NULL').run(current);
  db.prepare('DELETE FROM login_attempts WHERE created_at < ?').run(new Date(now-30*86400000).toISOString());
  db.prepare('DELETE FROM oauth_states WHERE expires_at < ?').run(current);
}
function logActivity(db, {event, sessionId=null, ip='unknown', userAgent='', pathName='', referrer='', productId=null, orderId=null, detail=''}) {
  db.prepare(`INSERT INTO activity_events(event,session_id,ip,user_agent,path,referrer,product_id,order_id,detail,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)`).run(event, sessionId, String(ip).slice(0,64), String(userAgent).slice(0,500), String(pathName).slice(0,500), String(referrer).slice(0,500), productId, orderId, String(detail).slice(0,300), nowIso());
}
function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derived = crypto.scryptSync(password, salt, 64, { N: 16384, r: 8, p: 1, maxmem: 64*1024*1024 });
  return `scrypt$16384$8$1$${salt.toString('hex')}$${derived.toString('hex')}`;
}
function verifyPassword(password, encoded) {
  try { const [scheme,n,r,p,saltHex,hashHex] = encoded.split('$'); if (scheme!=='scrypt') return false; const salt=Buffer.from(saltHex,'hex'); const expected=Buffer.from(hashHex,'hex'); const actual=crypto.scryptSync(password,salt,expected.length,{N:Number(n),r:Number(r),p:Number(p),maxmem:64*1024*1024}); return actual.length===expected.length&&crypto.timingSafeEqual(actual,expected); } catch { return false; }
}
let dummyPasswordHash='';
function performDummyPasswordCheck(password) {
  if(!dummyPasswordHash)dummyPasswordHash=hashPassword(crypto.randomBytes(32).toString('hex'));
  if(String(password||'').length<=200)verifyPassword(String(password||''),dummyPasswordHash);
}
function createSession(db, ip, ua, user=null) {
  const token = crypto.randomBytes(32).toString('base64url'); const csrf = crypto.randomBytes(24).toString('base64url');
  const now=nowIso(); const isCustomer=user?.role==='customer'; const role=user?.role||(user?'admin':'guest');
  const ttl=user?(user.rememberMe?CUSTOMER_REMEMBER_TTL_MS:SESSION_TTL_MS):GUEST_TTL_MS; const expires=new Date(Date.now()+ttl).toISOString();
  const info = db.prepare('INSERT INTO sessions(token_hash,csrf_token,user_id,customer_id,role,ip,user_agent,created_at,last_seen_at,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?)')
    .run(sha256(token),csrf,user&&!isCustomer?user.id:null,isCustomer?user.id:null,role,ip,String(ua||'').slice(0,500),now,now,expires);
  const publicUser=user?{id:user.id,email:user.email||'',phone:user.phone||'',name:user.fullName||user.name||'',role:user.role||'admin',permissions:Array.isArray(user.permissions)?user.permissions:[]}:null;
  return { token, csrfToken:csrf, id:Number(info.lastInsertRowid), user:publicUser, role, expiresAt:expires };
}
function revokeSession(db, tokenHash) { if (tokenHash) db.prepare('UPDATE sessions SET revoked_at=? WHERE token_hash=?').run(nowIso(),tokenHash); }
function hasAdmin(db) { return db.prepare('SELECT id FROM admins WHERE active=1 LIMIT 1').get() != null; }
function getSession(db, req, res, ip) {
  if (res._session) return res._session;
  const raw=parseCookies(req.headers.cookie||'')[COOKIE_NAME]; let row=null;
  if (raw && /^[A-Za-z0-9_-]{32,100}$/.test(raw)) row=db.prepare(`SELECT s.*,a.email,a.active AS admin_active,a.role AS admin_role,a.permissions_json,
      c.full_name AS customer_name,c.phone AS customer_phone,c.email AS customer_email,c.active AS customer_active
      FROM sessions s LEFT JOIN admins a ON a.id=s.user_id LEFT JOIN customer_accounts c ON c.id=s.customer_id WHERE s.token_hash=?`).get(sha256(raw));
  const isStaff=row&&STAFF_ROLES.has(row.role);
  const good = row && !row.revoked_at && row.expires_at>nowIso() &&
    (isStaff ? !!(row.admin_active&&row.user_id&&row.admin_role===row.role) : row.role==='customer' ? !!(row.customer_active&&row.customer_id) : row.role==='guest');
  if (good) {
    if (Date.now()-Date.parse(row.last_seen_at)>15000) db.prepare('UPDATE sessions SET last_seen_at=? WHERE id=?').run(nowIso(),row.id);
    let user=null;
    if(isStaff){let permissions=[];try{permissions=JSON.parse(row.permissions_json||'[]')}catch{}user={id:row.user_id,email:row.email,role:row.admin_role,permissions:Array.isArray(permissions)?permissions:[]};}
    else if(row.role==='customer')user={id:row.customer_id,email:row.customer_email||'',phone:row.customer_phone,name:row.customer_name,fullName:row.customer_name,role:'customer',permissions:[]};
    res._session={id:row.id,tokenHash:row.token_hash,csrfToken:row.csrf_token,role:row.role,user,customerId:row.customer_id||null,expiresAt:row.expires_at};
  } else {
    if (row) db.prepare('DELETE FROM sessions WHERE id=?').run(row.id);
    const s=createSession(db,ip,req.headers['user-agent']||''); res._pendingCookie=s.token;
    res._session={id:s.id,tokenHash:sha256(s.token),csrfToken:s.csrfToken,role:'guest',user:null,customerId:null,expiresAt:s.expiresAt};
  }
  return res._session;
}
function setNewCookie(res, token, user, ttlOverride=null) { res._pendingCookie=token; res._cookieTtl=Number.isFinite(ttlOverride)?ttlOverride:(user?SESSION_TTL_MS:GUEST_TTL_MS); }
function cookieString(req, token, maxAge) {
  let parts=[`${COOKIE_NAME}=${encodeURIComponent(token)}`, 'Path=/', 'HttpOnly', 'SameSite=Strict', `Max-Age=${Math.max(0,Math.floor((maxAge||0)/1000))}`];
  if (process.env.NODE_ENV==='production' && isHttpsRequest(req)) parts.push('Secure');
  return parts.join('; ');
}
function securityHeaders(req, pathname) {
  const headers={
    'X-Content-Type-Options':'nosniff', 'X-Frame-Options':'DENY', 'Referrer-Policy':'strict-origin-when-cross-origin',
    'Permissions-Policy':'camera=(), microphone=(), geolocation=(), payment=()',
    'Content-Security-Policy':"default-src 'self'; base-uri 'self'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src 'self'; style-src 'self'; img-src 'self' https: data: blob:; connect-src 'self';",
    'Cross-Origin-Opener-Policy':'same-origin', 'Cross-Origin-Resource-Policy':'same-origin',
    'Cache-Control': pathname.startsWith('/admin') || pathname.startsWith('/api/admin') ? 'no-store' : 'no-cache',
  };
  if (process.env.NODE_ENV==='production' && isHttpsRequest(req)) headers['Strict-Transport-Security']='max-age=31536000; includeSubDomains';
  return headers;
}
function send(req,res,status,body,contentType='application/json; charset=utf-8',extra={}) {
  if (res.writableEnded) return;
  const headers={...securityHeaders(req,new URL(req.url,'http://local').pathname),...extra,'Content-Type':contentType};
  if (res._pendingCookie) {
    const sessionCookie = cookieString(req,res._pendingCookie,res._cookieTtl||(hasAdmin(res._db)?GUEST_TTL_MS:GUEST_TTL_MS));
    if (headers['Set-Cookie']) headers['Set-Cookie'] = [...(Array.isArray(headers['Set-Cookie'])?headers['Set-Cookie']:[headers['Set-Cookie']]), sessionCookie];
    else headers['Set-Cookie'] = sessionCookie;
    res._pendingCookie=null;
  }
  const buf=Buffer.isBuffer(body)?body:Buffer.from(String(body));
  headers['Content-Length']=String(buf.length); res.writeHead(status,headers); res.end(buf);
}
function sendJson(req,res,status,obj,extra={}) { send(req,res,status,JSON.stringify(obj), 'application/json; charset=utf-8',extra); }
function sendError(req,res,status,error,detail) { sendJson(req,res,status,{error, ...(detail?{detail}: {})}); }
function redirect(req,res,location) { send(req,res,303,'', 'text/plain; charset=utf-8',{Location:location}); }
function safeReferrer(req) {
  const ref=String(req.headers.referer||''); if (!ref) return '';
  try { const u=new URL(ref); return `${u.origin}${u.pathname}`.slice(0,500); } catch { return ''; }
}
async function readJson(req, maxBytes=MAX_BODY_BYTES) {
  return new Promise((resolve,reject)=>{
    let size=0, chunks=[]; req.on('data',chunk=>{size+=chunk.length;if(size>maxBytes){reject(Object.assign(new Error('BODY_TOO_LARGE'),{status:413}));req.destroy();return;}chunks.push(chunk);});
    req.on('end',()=>{if(!chunks.length){resolve({});return;}try{resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));}catch{reject(Object.assign(new Error('INVALID_JSON'),{status:400}));}});
    req.on('error',reject);
  });
}
async function readBuffer(req, maxBytes=MAX_UPLOAD_BYTES) {
  return new Promise((resolve,reject)=>{
    let size=0, chunks=[], tooLarge=false, settled=false;
    req.on('data',chunk=>{if(tooLarge)return;size+=chunk.length;if(size>maxBytes){tooLarge=true;chunks=[];return;}chunks.push(chunk);});
    req.on('end',()=>{if(settled)return;settled=true;if(tooLarge)return reject(Object.assign(new Error('IMAGE_TOO_LARGE'),{status:413}));resolve(Buffer.concat(chunks));});
    req.on('error',err=>{if(!settled){settled=true;reject(err);}});
  });
}
function checkOrigin(req) {
  const origin=req.headers.origin; if (!origin) return true;
  try { const u=new URL(origin); return u.host.toLowerCase()===String(req.headers.host||'').toLowerCase() && ['http:','https:'].includes(u.protocol); } catch { return false; }
}
function checkCsrf(req, session) {
  if (!session || typeof session.csrfToken !== 'string' || !checkOrigin(req)) return false;
  const supplied=String(req.headers['x-csrf-token']||'');
  return safeEqual(supplied,session.csrfToken);
}
function requireAdmin(req,res,session) {
  if (!session || !STAFF_ROLES.has(session.role) || !session.user) { sendError(req,res,401,'UNAUTHENTICATED'); return false; }
  return true;
}
function hasPermission(session, permission) {
  if (session?.user?.role === 'admin') return true;
  return Array.isArray(session?.user?.permissions) && session.user.permissions.includes(permission);
}
function requirePermission(req,res,session,permission) {
  if (hasPermission(session,permission)) return true;
  sendError(req,res,403,'PERMISSION_DENIED',`Missing permission: ${permission}`); return false;
}
function isOwner(session) { return session?.user?.role==='admin'; }
function adminRoutePermission(pathname, method) {
  if (pathname.startsWith('/api/admin/staff')) return 'staff';
  if (pathname.startsWith('/api/admin/chat')) return 'chat';
  if (pathname.startsWith('/api/admin/customers')) return 'customers';
  if (pathname.startsWith('/api/admin/activity')) return 'activity';
  if (pathname.startsWith('/api/admin/blocked-ips')) return 'security';
  if (pathname.startsWith('/api/admin/settings')) return 'customization';
  if (pathname==='/api/admin/uploads/image' || /^\/api\/admin\/uploads\/image\//.test(pathname)) return 'products';
  if (pathname.startsWith('/api/admin/reviews')) return 'reviews';
  if (pathname.startsWith('/api/admin/products')) return 'products';
  if (pathname.startsWith('/api/admin/orders')) return 'orders';
  if (pathname==='/api/admin/overview' || pathname==='/api/admin/backup') return pathname==='/api/admin/backup'?'staff':'dashboard';
  return 'dashboard';
}
function validateText(value, max, {required=false,min=0}={}) {
  const str=String(value??'').trim(); if (required && str.length<Math.max(1,min)) return null; if (str.length>max || str.length<min) return null; return str;
}
function validateImageUrl(value) {
  const str=String(value||'').trim(); if (!str) return '';
  if (/^\/uploads\/[a-f0-9]{32}\.(?:jpg|png|webp)$/.test(str)) return str;
  if (/^\/assets\/(?:saree|threepiece|combo)\.svg$/.test(str)) return str;
  try { const u=new URL(str); if (u.protocol==='https:' && u.username==='' && u.password==='' && u.hostname.length<255) return u.toString(); } catch {}
  return null;
}
function saveImageBuffer(bytes, contentType, uploadDir=UPLOAD_DIR) {
  if(!Buffer.isBuffer(bytes)||bytes.length===0||bytes.length>MAX_UPLOAD_BYTES)throw new Error('IMAGE_TOO_LARGE');
  const type=String(contentType||'').split(';')[0].trim().toLowerCase();
  let ext='';
  if(type==='image/jpeg'&&bytes.length>3&&bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff)ext='jpg';
  else if(type==='image/png'&&bytes.length>8&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])))ext='png';
  else if(type==='image/webp'&&bytes.length>12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP')ext='webp';
  else throw new Error('INVALID_IMAGE');
  const filename=crypto.randomBytes(16).toString('hex')+'.'+ext;
  fs.writeFileSync(path.join(uploadDir,filename),bytes,{flag:'wx',mode:0o644});
  return '/uploads/'+filename;
}
function saveImageData(dataUrl, uploadDir=UPLOAD_DIR) {
  if (typeof dataUrl!=='string' || dataUrl.length>Math.ceil(MAX_UPLOAD_BYTES*1.42)+100) throw new Error('IMAGE_TOO_LARGE');
  const match=dataUrl.match(/^data:image\/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!match) throw new Error('INVALID_IMAGE');
  const ext=match[1]==='jpeg'?'jpg':match[1]; if(!PRODUCT_IMG_EXTS.has(ext)) throw new Error('INVALID_IMAGE');
  const bytes=Buffer.from(match[2],'base64'); if(bytes.length===0||bytes.length>MAX_UPLOAD_BYTES) throw new Error('IMAGE_TOO_LARGE');
  let valid=false;
  if(ext==='jpg') valid=bytes.length>3&&bytes[0]===0xff&&bytes[1]===0xd8&&bytes[2]===0xff;
  if(ext==='png') valid=bytes.length>8&&bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]));
  if(ext==='webp') valid=bytes.length>12&&bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP';
  if(!valid) throw new Error('INVALID_IMAGE');
  const filename=crypto.randomBytes(16).toString('hex')+'.'+ext; fs.writeFileSync(path.join(uploadDir,filename),bytes,{flag:'wx',mode:0o644}); return '/uploads/'+filename;
}
function productFromInput(db, body, old=null, uploadDir=UPLOAD_DIR) {
  const name=validateText(body.name,120,{required:true,min:2});
  const nameEn=validateText(body.nameEn,120); const category=validateText(body.category,60,{required:true,min:1}); const categoryEn=validateText(body.categoryEn,60);
  const description=validateText(body.description,2000); const descriptionEn=validateText(body.descriptionEn,2000);
  const price=Number(body.price); const compareAt=Number(body.compareAt||0); const stock=Number(body.stock);
  if(name===null||nameEn===null||category===null||categoryEn===null||description===null||descriptionEn===null) throw new Error('INVALID_PRODUCT_TEXT');
  if(!Number.isSafeInteger(price)||price<1||price>10000000||!Number.isSafeInteger(compareAt)||compareAt<0||compareAt>10000000||!Number.isSafeInteger(stock)||stock<0||stock>1000000) throw new Error('INVALID_PRODUCT_NUMBER');
  const cleanList=(value,maxItems,maxLen)=>{ if(value===undefined)return null; if(!Array.isArray(value))throw new Error('INVALID_PRODUCT_OPTIONS'); const out=[...new Set(value.map(v=>String(v).trim()).filter(Boolean))]; if(out.length>maxItems||out.some(v=>v.length>maxLen))throw new Error('INVALID_PRODUCT_OPTIONS'); return out; };
  const colors=cleanList(body.colors,20,40) ?? safeJsonArray(old?.colors_json); const sizes=cleanList(body.sizes,20,40) ?? safeJsonArray(old?.sizes_json);
  const hasGalleryInput=Array.isArray(body.keepImages)||Array.isArray(body.imageUrls)||Array.isArray(body.imageDataList)||Boolean(body.imageData)||Boolean(body.imageUrl)||Boolean(body.keepImage);
  if((Array.isArray(body.keepImages)?body.keepImages.length:0)+(Array.isArray(body.imageUrls)?body.imageUrls.length:0)+(Array.isArray(body.imageDataList)?body.imageDataList.length:0)>10)throw new Error('TOO_MANY_PRODUCT_IMAGES');
  let imageUrls=[];
  if(Array.isArray(body.keepImages)) {
    for(const item of body.keepImages) { const valid=validateImageUrl(item); if(!valid)throw new Error('INVALID_IMAGE_URL'); imageUrls.push(valid); }
  } else if(old) {
    imageUrls=safeJsonArray(old.images_json); if(!imageUrls.length&&old.image_url)imageUrls=[old.image_url];
  }
  // Legacy single-image clients remain supported.
  if(body.imageData && !Array.isArray(body.imageDataList)) {
    imageUrls=[saveImageData(body.imageData,uploadDir)];
  } else if(typeof body.imageUrl==='string'&&body.imageUrl.trim()&&!Array.isArray(body.imageUrls)) {
    const valid=validateImageUrl(body.imageUrl); if(valid===null) throw new Error('INVALID_IMAGE_URL'); imageUrls.push(valid);
  } else if(typeof body.keepImage==='string'&&body.keepImage.trim()&&!Array.isArray(body.keepImages)) {
    const valid=validateImageUrl(body.keepImage); if(valid===null) throw new Error('INVALID_IMAGE_URL'); imageUrls.push(valid);
  }
  if(Array.isArray(body.imageUrls)) {
    if(body.imageUrls.length>10)throw new Error('TOO_MANY_PRODUCT_IMAGES');
    for(const item of body.imageUrls) { const valid=validateImageUrl(item); if(valid===null)throw new Error('INVALID_IMAGE_URL'); if(valid)imageUrls.push(valid); }
  }
  if(Array.isArray(body.imageDataList)) {
    if(body.imageDataList.length>10)throw new Error('TOO_MANY_PRODUCT_IMAGES');
    for(const data of body.imageDataList) imageUrls.push(saveImageData(data,uploadDir));
  }
  imageUrls=[...new Set(imageUrls)];
  if(!imageUrls.length&&!hasGalleryInput) imageUrls=old?(safeJsonArray(old.images_json).length?safeJsonArray(old.images_json):(old.image_url?[old.image_url]:[])):[];
  if(!imageUrls.length) imageUrls=['/assets/saree.svg'];
  if(imageUrls.length>10)throw new Error('TOO_MANY_PRODUCT_IMAGES');
  const imageUrl=imageUrls[0]||'/assets/saree.svg';
  const active=body.active===undefined?(old?!!old.active:true):!!body.active;
  return {name,nameEn,category,categoryEn,description,descriptionEn,price,compareAt,stock,imageUrl,imageUrls,active,colors,sizes};
}
function normalizePhone(value) {
  let s=String(value||'').replace(/[\s()-]/g,''); if(s.startsWith('+88'))s=s.slice(1); if(s.startsWith('8801'))s='0'+s.slice(3);
  return /^01[3-9]\d{8}$/.test(s)?s:null;
}
function validateCheckout(body) {
  if(!body||typeof body!=='object'||Array.isArray(body))throw new Error('INVALID_CART');
  const customer=body.customer&&typeof body.customer==='object'&&!Array.isArray(body.customer)?body.customer:{};
  const customerName=validateText(customer.customerName,100,{required:true,min:2}); const phone=normalizePhone(customer.phone);
  const district=validateText(customer.district,80,{required:true,min:2}); const upazila=validateText(customer.upazila,80,{required:true,min:2}); const address=validateText(customer.address,500,{required:true,min:6}); const notes=validateText(customer.notes,300);
  if(customerName===null||!phone||district===null||upazila===null||address===null||notes===null) throw new Error('INVALID_CUSTOMER_DETAILS');
  if(!Array.isArray(body.items)||body.items.length<1||body.items.length>20) throw new Error('INVALID_CART');
  const items=[]; const seen=new Set();
  for(const row of body.items){if(!row||typeof row!=='object'||Array.isArray(row))throw new Error('INVALID_CART');const productId=Number(row.productId),quantity=Number(row.quantity);if(!Number.isSafeInteger(productId)||productId<1||!Number.isSafeInteger(quantity)||quantity<1||quantity>99) throw new Error('INVALID_CART');const color=validateText(row.color||'',40),size=validateText(row.size||'',40);if(color===null||size===null)throw new Error('INVALID_CART');const itemKey=`${productId}\u0000${color}\u0000${size}`;if(seen.has(itemKey))throw new Error('INVALID_CART');seen.add(itemKey);items.push({productId,quantity,color,size});}
  return {customer:{customerName,phone,district,upazila,address,notes},items};
}
function makeOrderNumber() { return 'CS-'+Date.now().toString(36).toUpperCase()+'-'+crypto.randomBytes(3).toString('hex').toUpperCase(); }
function ipValid(ip) { const val=normIp(ip); return net.isIP(val)!==0 ? val : null; }
const genericRate = new Map();
function rateLimit(ip, scope, max, windowMs) {
  const key=`${ip}:${scope}`;const now=Date.now();let x=genericRate.get(key);if(!x||now-x.start>windowMs)x={start:now,count:0};x.count++;genericRate.set(key,x);
  if(genericRate.size>5000)for(const [k,v] of genericRate)if(now-v.start>windowMs*2)genericRate.delete(k);
  return x.count<=max;
}
function staffOnline(db) {
  const since=new Date(Date.now()-3*60_000).toISOString();
  const online=db.prepare("SELECT DISTINCT a.role,a.permissions_json FROM sessions s JOIN admins a ON a.id=s.user_id WHERE s.role IN ('admin','moderator','parent') AND a.active=1 AND s.revoked_at IS NULL AND s.expires_at>? AND s.last_seen_at>=?").all(nowIso(),since);
  return online.some(row=>row.role==='admin'||safeJsonArray(row.permissions_json).includes('chat'));
}
function rowChatMessage(m) { return {id:m.id,senderRole:m.sender_role,senderId:m.sender_id||null,body:m.body,createdAt:m.created_at,readAt:m.read_at||null}; }
function chatMessages(db, threadId, {markRead=false}={}) {
  if(markRead)db.prepare("UPDATE chat_messages SET read_at=? WHERE thread_id=? AND sender_role='customer' AND read_at IS NULL").run(nowIso(),threadId);
  return db.prepare('SELECT id,sender_role,sender_id,body,created_at,read_at FROM chat_messages WHERE thread_id=? ORDER BY id DESC LIMIT 100').all(threadId).reverse().map(rowChatMessage);
}
function offlineAssistantReply(message, db) {
  const text=String(message||'').toLowerCase(); const fee=Number(setting(db,'shippingFee',80)); const brand=String(setting(db,'storeName','আমাদের স্টোর'));
  if(/human|real person|live agent|customer support|talk to (a )?(human|person|agent)|speak to (a )?(human|person|agent)|মানুষের সাথে|মানুষের সঙ্গে|মানুষের সাথে কথা|মানুষের সঙ্গে কথা|কর্মকর্তার সাথে|কর্মকর্তার সঙ্গে|কাস্টমার সার্ভিস|সাপোর্ট টিম/.test(text))return 'আপনাকে একজন মানুষের সহায়তার সঙ্গে যুক্ত করার অনুরোধটি নোট করা হয়েছে। সাপোর্ট টিম অনলাইনে থাকলে এখানে উত্তর দেবেন; না থাকলে মেসেজটি রেখে দিন।';
  if(/delivery|ডেলিভারি|কুরিয়ার|courier|shipping|চার্জ/.test(text))return `আমাদের ${brand}-এ সারা বাংলাদেশে ডেলিভারি হয়। বর্তমানে বেস ডেলিভারি চার্জ ৳${fee}। দূরবর্তী এলাকার চার্জ অর্ডারের সময় নিশ্চিত করা হতে পারে।`;
  if(/order|অর্ডার|কিনতে|কিনব|buy|purchase/.test(text))return 'অর্ডার করতে পছন্দের পণ্য খুলে রং/সাইজ বেছে “Order Now” চাপুন, তারপর নাম, মোবাইল ও ঠিকানা দিয়ে অর্ডার নিশ্চিত করুন।';
  if(/track|tracking|status|কোথায়|স্ট্যাটাস|অবস্থা|পার্সেল/.test(text))return 'অর্ডারের অবস্থা জানতে ওয়েবসাইটের “অর্ডারের অবস্থা জানুন” অংশে অর্ডার নম্বর ও অর্ডারে দেওয়া মোবাইল নম্বর দিন।';
  if(/price|cost|dam|দাম|মূল্য|কত টাকা/.test(text))return 'প্রতিটি পণ্যের বর্তমান দাম প্রোডাক্ট কার্ড ও বিস্তারিত পেজে দেখানো আছে। নির্দিষ্ট পণ্যের নাম লিখলে সেটি খুঁজে নিতে সাহায্য করতে পারি।';
  if(/color|colour|size|রং|সাইজ|মাপ/.test(text))return 'প্রোডাক্টের বিস্তারিত পেজে যে রং ও সাইজগুলো দেখানো আছে, সেগুলো থেকেই বেছে নিতে পারবেন। কোনো অপশন না থাকলে তা ওই পণ্যে নেই।';
  if(/return|refund|exchange|ফেরত|বদল|রিফান্ড/.test(text))return 'রিটার্ন বা এক্সচেঞ্জ বিষয়ে অর্ডার নম্বর ও সমস্যাটি লিখে রাখুন। কোনো Admin/Moderator অনলাইনে এলে কথোপকথনে উত্তর দিতে পারবেন।';
  if(/human|agent|admin|moderator|মানুষ|কর্মী|কথা বলতে চাই/.test(text))return 'এই মুহূর্তে কোনো Admin বা Moderator অনলাইনে নেই। আপনার বার্তাটি রেখে দিলাম; তারা অনলাইনে এলে চ্যাট থেকে উত্তর দিতে পারবেন।';
  return 'আমি স্টোরের স্বয়ংক্রিয় সহকারী। অর্ডার, ডেলিভারি, দাম, রং বা সাইজ সম্পর্কে প্রশ্ন করতে পারেন। এই মুহূর্তে কোনো Admin/Moderator অনলাইনে নেই; প্রয়োজন হলে বার্তা রেখে যান।';
}
async function generateChatAssistantReply(message, db) {
  const key=String(process.env.OPENAI_API_KEY||'').trim();
  if(!key)return offlineAssistantReply(message,db);
  const brand=String(setting(db,'storeName','Nokshi Atelier'));const fee=Number(setting(db,'shippingFee',80));
  try {
    const response=await fetch('https://api.openai.com/v1/chat/completions',{method:'POST',headers:{'Authorization':`Bearer ${key}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL||'gpt-4.1-mini',temperature:0.3,max_tokens:220,messages:[{role:'system',content:`You are the customer support assistant for ${brand}, a clothing store in Bangladesh. Reply in the language used by the customer, concisely. Known base delivery fee: BDT ${fee}. Never claim a shipment is live-booked or provide an order-specific private status. Direct order-status questions to the site's order tracking form requiring order number and phone. Never ask for passwords, full card numbers, OTPs, or sensitive credentials. You may answer general product/order/delivery FAQs, and for uncertain policies invite the customer to leave a message for staff.`},{role:'user',content:String(message).slice(0,2000)}]}),signal:AbortSignal.timeout(7000)});
    if(!response.ok)return offlineAssistantReply(message,db);const data=await response.json();const answer=String(data.choices?.[0]?.message?.content||'').trim();return answer.slice(0,1800)||offlineAssistantReply(message,db);
  } catch { return offlineAssistantReply(message,db); }
}
function validChatToken(value) { return typeof value==='string' && /^[A-Za-z0-9_-]{32,100}$/.test(value); }
function getOrCreateChatThread(db, token, session, name='', phone='') {
  if(!validChatToken(token))throw new Error('INVALID_CHAT_TOKEN');
  const hash=sha256(token);let thread=db.prepare('SELECT * FROM chat_threads WHERE client_token_hash=?').get(hash);
  if(!thread){
    const customerId=session?.role==='customer'&&session.user?session.user.id:null;
    const customer=customerId?db.prepare('SELECT full_name,phone FROM customer_accounts WHERE id=?').get(customerId):null;
    const guestName=validateText(name,100,{required:false,min:0})||customer?.full_name||'Guest customer';
    const guestPhone=normalizePhone(phone)||customer?.phone||'';const now=nowIso();
    try{const info=db.prepare('INSERT INTO chat_threads(client_token_hash,customer_id,guest_name,guest_phone,status,created_at,updated_at,last_message_at) VALUES(?,?,?,?,?,?,?,?)').run(hash,customerId,guestName,guestPhone,'open',now,now,now);thread=db.prepare('SELECT * FROM chat_threads WHERE id=?').get(Number(info.lastInsertRowid));}
    catch(err){if(String(err.message).includes('UNIQUE'))thread=db.prepare('SELECT * FROM chat_threads WHERE client_token_hash=?').get(hash);else throw err;}
  } else if(session?.role==='customer'&&session.user&&!thread.customer_id){db.prepare('UPDATE chat_threads SET customer_id=?,guest_name=?,guest_phone=?,updated_at=? WHERE id=?').run(session.user.id,session.user.name,session.user.phone,nowIso(),thread.id);thread=db.prepare('SELECT * FROM chat_threads WHERE id=?').get(thread.id);}
  return thread;
}

function createServer(options={}) {
  const dbPath=options.dbPath||process.env.STORE_DB_PATH||DEFAULT_DB;
  const uploadDir=options.uploadDir||process.env.STORE_UPLOAD_DIR||UPLOAD_DIR;
  const db=initDatabase(dbPath,uploadDir);
  const setupTokenFile=options.setupTokenPath||path.join(ROOT,'.setup_token');
  let configuredSetupToken=options.setupToken||process.env.SETUP_TOKEN||'';
  const setupTokenWasProvided=Boolean(configuredSetupToken);
  function getSetupToken() {
    if(configuredSetupToken)return configuredSetupToken;
    if(fs.existsSync(setupTokenFile))return fs.readFileSync(setupTokenFile,'utf8').trim();
    const token=crypto.randomBytes(24).toString('base64url');fs.writeFileSync(setupTokenFile,token,{mode:0o600,flag:'wx'});configuredSetupToken=token;return token;
  }
  if(!hasAdmin(db)){
    const token=getSetupToken();
    console.log('\n[FIRST-TIME ADMIN SETUP] Open http://127.0.0.1:'+(options.port||process.env.PORT||3000)+'/admin/login.');
    if(setupTokenWasProvided)console.log('Use the SETUP_TOKEN value configured in your environment; configured secrets are not echoed to logs.');
    else console.log('One-time setup token: '+token);
    console.log('Keep the token private. It will be removed after the first Admin is created.\n');
  }
  function recordSecurity(event,ip,ua,detail=''){try{logActivity(db,{event,ip,userAgent:ua,pathName:'/security',detail});}catch{/* security log failures must not expose internals */}}
  function handler(req,res) { void route(req,res).catch(err=>{
      if(res.writableEnded)return;
      const expected = new Set(['INVALID_IMAGE_URL','INVALID_IMAGE','IMAGE_TOO_LARGE','IMAGE_IN_USE','IMAGE_NOT_FOUND','INVALID_PRODUCT_TEXT','INVALID_PRODUCT_NUMBER','INVALID_CUSTOMER_DETAILS','INVALID_CART','INVALID_PRODUCT_VARIANT','INVALID_PRODUCT_OPTIONS','TOO_MANY_PRODUCT_IMAGES','ORDER_TOTAL_INVALID','INVALID_EMAIL','INVALID_IP_OR_REASON','INVALID_SETTINGS','INVALID_LOGO_URL','PASSWORD_POLICY: use at least 8 characters']);
      const status=err.status||(expected.has(err.message)?400:500);
      if(status===500)console.error('[request error]',req.method,req.url,err?.stack||err);
      try{sendJson(req,res,status,{error:status===500?'INTERNAL_SERVER_ERROR':err.message||'REQUEST_ERROR'});}catch{res.destroy();}
    }); }
  async function route(req,res) {
    const url=new URL(req.url,'http://localhost');const p=url.pathname;const method=req.method||'GET';const ip=getClientIp(req);const ua=String(req.headers['user-agent']||'').slice(0,500);
    res._db=db;
    runMaintenance(db);
    // Blocked visitor cannot shop/place orders, but can reach login and protected admin APIs
    // so a verified administrator can remove an accidental block.
    const adminExempt=p.startsWith('/admin')||p.startsWith('/api/admin')||p.startsWith('/api/auth')||p==='/api/bootstrap'||p==='/healthz';
    const blocked=db.prepare('SELECT id,reason FROM blocked_ips WHERE ip=?').get(ip);
    if(blocked&&!adminExempt&&!p.startsWith('/css/')&&!p.startsWith('/js/')&&!p.startsWith('/assets/')) { recordSecurity('blocked_ip_request',ip,ua,`${method} ${p}`); return sendError(req,res,403,'IP_BLOCKED'); }
    if(p.startsWith('/api/')&&method!=='GET'&&method!=='HEAD'){
      if(!rateLimit(ip,`api:${p.split('/').slice(0,3).join('/')}`,p==='/api/track'?240:80,60_000)){recordSecurity('rate_limited',ip,ua,p);return sendError(req,res,429,'RATE_LIMITED');}
    }
    let session=null;
    if(!p.startsWith('/css/')&&!p.startsWith('/js/')&&!p.startsWith('/assets/')&&!p.startsWith('/uploads/')&&p!=='/robots.txt'&&p!=='/healthz'&&p!=='/favicon.ico'&&p!=='/api/chat/status') session=getSession(db,req,res,ip);
    const csrfNeeded=['POST','PUT','PATCH','DELETE'].includes(method);
    if(csrfNeeded && !checkCsrf(req,session)) return sendError(req,res,403,'CSRF_VALIDATION_FAILED');

    if(method==='GET'&&p==='/api/auth/social/status'){
      return sendJson(req,res,200,{googleConfigured:Boolean(process.env.GOOGLE_CLIENT_ID&&process.env.GOOGLE_CLIENT_SECRET),facebookConfigured:Boolean(process.env.FACEBOOK_APP_ID&&process.env.FACEBOOK_APP_SECRET)});
    }
    const oauthStart=p.match(/^\/auth\/(google|facebook)$/);
    if(method==='GET'&&oauthStart){
      const provider=oauthStart[1];
      const clientId=provider==='google'?process.env.GOOGLE_CLIENT_ID:process.env.FACEBOOK_APP_ID;
      const clientSecret=provider==='google'?process.env.GOOGLE_CLIENT_SECRET:process.env.FACEBOOK_APP_SECRET;
      const base=resolveOAuthBase(req);
      if(!clientId||!clientSecret||!base)return redirect(req,res,`/?socialAuth=${provider}_unconfigured`);
      const stateValue=crypto.randomBytes(32).toString('base64url');const codeVerifier=crypto.randomBytes(48).toString('base64url');const codeChallenge=crypto.createHash('sha256').update(codeVerifier).digest('base64url');const now=nowIso();const expiry=new Date(Date.now()+10*60_000).toISOString();
      db.prepare('DELETE FROM oauth_states WHERE expires_at<=?').run(now);db.prepare('INSERT INTO oauth_states(state_hash,provider,code_verifier,created_at,expires_at) VALUES(?,?,?,?,?)').run(sha256(stateValue),provider,codeVerifier,now,expiry);
      const callback=`${base}/auth/${provider}/callback`;const authUrl=provider==='google'?new URL('https://accounts.google.com/o/oauth2/v2/auth'):new URL(`https://www.facebook.com/${process.env.FACEBOOK_GRAPH_VERSION||'v26.0'}/dialog/oauth`);
      authUrl.searchParams.set('client_id',clientId);authUrl.searchParams.set('redirect_uri',callback);authUrl.searchParams.set('response_type','code');authUrl.searchParams.set('state',stateValue);authUrl.searchParams.set('scope',provider==='google'?'openid email profile':'email,public_profile');authUrl.searchParams.set('code_challenge',codeChallenge);authUrl.searchParams.set('code_challenge_method','S256');
      if(provider==='google')authUrl.searchParams.set('prompt','select_account');
      const secure=isHttpsRequest(req)?'; Secure':'';const stateCookie=`oauth_state=${encodeURIComponent(stateValue)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=600${secure}`;
      return send(req,res,302,'','text/plain; charset=utf-8',{Location:authUrl.toString(),'Cache-Control':'no-store','Set-Cookie':stateCookie});
    }
    const oauthCallback=p.match(/^\/auth\/(google|facebook)\/callback$/);
    if(method==='GET'&&oauthCallback){
      const provider=oauthCallback[1],params=url.searchParams,stateValue=String(params.get('state')||''),cookieState=parseCookies(req.headers.cookie||'').oauth_state||'';
      const clearState=`oauth_state=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0${isHttpsRequest(req)?'; Secure':''}`;
      const fail=(reason='error')=>send(req,res,303,'','text/plain; charset=utf-8',{Location:`/?socialAuth=${encodeURIComponent(reason)}`,'Cache-Control':'no-store','Set-Cookie':clearState});
      if(params.get('error')||!stateValue||!cookieState||!safeEqual(stateValue,cookieState))return fail();
      const stateRow=db.prepare('SELECT * FROM oauth_states WHERE state_hash=? AND provider=? AND expires_at>?').get(sha256(stateValue),provider,nowIso());
      db.prepare('DELETE FROM oauth_states WHERE state_hash=?').run(sha256(stateValue));
      if(!stateRow||!params.get('code'))return fail();
      const base=resolveOAuthBase(req);if(!base)return fail(`${provider}_unconfigured`);const callback=`${base}/auth/${provider}/callback`;
      const clientId=provider==='google'?process.env.GOOGLE_CLIENT_ID:process.env.FACEBOOK_APP_ID;const clientSecret=provider==='google'?process.env.GOOGLE_CLIENT_SECRET:process.env.FACEBOOK_APP_SECRET;
      if(!clientId||!clientSecret)return fail();
      try{
        let accessToken='',profile={};
        if(provider==='google'){
          const tokenResponse=await fetch('https://oauth2.googleapis.com/token',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},body:new URLSearchParams({code:String(params.get('code')),client_id:clientId,client_secret:clientSecret,redirect_uri:callback,grant_type:'authorization_code',code_verifier:stateRow.code_verifier}),signal:AbortSignal.timeout(8000)});
          const tokenData=await tokenResponse.json();if(!tokenResponse.ok||!tokenData.access_token)throw new Error('OAUTH_TOKEN_FAILED');accessToken=tokenData.access_token;
          const userResponse=await fetch('https://openidconnect.googleapis.com/v1/userinfo',{headers:{Authorization:`Bearer ${accessToken}`,'Accept':'application/json'},signal:AbortSignal.timeout(8000)});profile=await userResponse.json();if(!userResponse.ok||!profile.sub||!profile.email||profile.email_verified!==true)throw new Error('OAUTH_PROFILE_FAILED');
          profile.providerUserId=String(profile.sub);profile.providerEmail=String(profile.email).trim().toLowerCase();profile.providerName=String(profile.name||profile.given_name||profile.email).slice(0,100);
        } else {
          const version=process.env.FACEBOOK_GRAPH_VERSION||'v26.0';const tokenUrl=new URL(`https://graph.facebook.com/${version}/oauth/access_token`);tokenUrl.searchParams.set('client_id',clientId);tokenUrl.searchParams.set('client_secret',clientSecret);tokenUrl.searchParams.set('redirect_uri',callback);tokenUrl.searchParams.set('code',String(params.get('code')));tokenUrl.searchParams.set('code_verifier',stateRow.code_verifier);
          const tokenResponse=await fetch(tokenUrl,{headers:{Accept:'application/json'},signal:AbortSignal.timeout(8000)});const tokenData=await tokenResponse.json();if(!tokenResponse.ok||!tokenData.access_token)throw new Error('OAUTH_TOKEN_FAILED');accessToken=tokenData.access_token;
          const profileUrl=new URL(`https://graph.facebook.com/${version}/me`);profileUrl.searchParams.set('fields','id,name,email');
          const userResponse=await fetch(profileUrl,{headers:{Accept:'application/json',Authorization:`Bearer ${accessToken}`},signal:AbortSignal.timeout(8000)});profile=await userResponse.json();if(!userResponse.ok||!profile.id||!profile.email)throw new Error('OAUTH_PROFILE_FAILED');
          profile.providerUserId=String(profile.id);profile.providerEmail=String(profile.email).trim().toLowerCase();profile.providerName=String(profile.name||profile.email).slice(0,100);
        }
        if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(profile.providerEmail)||profile.providerUserId.length>255)throw new Error('OAUTH_PROFILE_FAILED');
        const linkedIdentity=db.prepare('SELECT customer_account_id FROM customer_oauth_identities WHERE provider=? AND provider_user_id=?').get(provider,profile.providerUserId);
        let customerId=linkedIdentity?.customer_account_id||null;
        let customer=customerId?db.prepare('SELECT * FROM customer_accounts WHERE id=? AND active=1').get(customerId):null;
        if(linkedIdentity&&!customer)throw new Error('OAUTH_ACCOUNT_INACTIVE');
        if(!linkedIdentity){
          const emailOwner=db.prepare('SELECT id FROM customer_accounts WHERE email=? COLLATE NOCASE AND active=1').get(profile.providerEmail);
          // Do not silently link a Google/Facebook identity to a local or other-provider
          // account. That pattern allowed account pre-hijacking when an email was unverified.
          if(emailOwner)return fail('account_exists');
        }
        if(!customer){
          const placeholderPhone=`SOCIAL-${provider.toUpperCase()}-${profile.providerUserId}`.slice(0,240);const randomPassword=crypto.randomBytes(48).toString('base64url');
          const insert=db.prepare("INSERT INTO customer_accounts(full_name,phone,email,password_hash,active,created_at) VALUES(?,?,?,?,1,?)").run(profile.providerName,placeholderPhone,profile.providerEmail,hashPassword(randomPassword),nowIso());customerId=Number(insert.lastInsertRowid);customer=db.prepare('SELECT * FROM customer_accounts WHERE id=?').get(customerId);
        } else customerId=customer.id;
        if(!customer||!customer.active)throw new Error('OAUTH_ACCOUNT_INACTIVE');
        db.prepare('INSERT OR IGNORE INTO customer_oauth_identities(provider,provider_user_id,customer_account_id,email,created_at) VALUES(?,?,?,?,?)').run(provider,profile.providerUserId,customer.id,profile.providerEmail,nowIso());
        db.prepare('UPDATE customer_accounts SET last_login_at=? WHERE id=?').run(nowIso(),customer.id);
        revokeSession(db,session.tokenHash);const fresh=createSession(db,ip,ua,{id:customer.id,role:'customer',fullName:customer.full_name,phone:customer.phone,email:customer.email||''});setNewCookie(res,fresh.token,{role:'customer'},Date.parse(fresh.expiresAt)-Date.now());
        logActivity(db,{event:'customer_login',sessionId:fresh.id,ip,userAgent:ua,pathName:'/account',detail:`customer login via ${provider}`});
        return send(req,res,303,'','text/plain; charset=utf-8',{Location:'/?socialAuth=success','Cache-Control':'no-store','Set-Cookie':clearState});
      }catch(err){console.error(`[oauth:${provider}]`,String(err?.message||err));return fail();}
    }
    if(method==='GET'&&p==='/healthz')return sendJson(req,res,200,{ok:true,service:'clothing-store',time:nowIso()});
    if(method==='GET'&&p==='/robots.txt')return send(req,res,200,'User-agent: *\nDisallow: /admin\nDisallow: /api/admin\n','text/plain; charset=utf-8');
    if(method==='GET'&&p==='/')return send(req,res,200,fs.readFileSync(path.join(PUBLIC_DIR,'index.html')),'text/html; charset=utf-8');
    if(method==='GET'&&p==='/privacy')return send(req,res,200,fs.readFileSync(path.join(PUBLIC_DIR,'privacy.html')),'text/html; charset=utf-8');
    if(method==='GET'&&p==='/admin/login')return send(req,res,200,fs.readFileSync(path.join(PUBLIC_DIR,'admin-login.html')),'text/html; charset=utf-8');
    if(method==='GET'&&p==='/admin/setup')return redirect(req,res,'/admin/login');
    if(method==='GET'&&p==='/admin') { if(!STAFF_ROLES.has(session?.role))return redirect(req,res,'/admin/login');return send(req,res,200,fs.readFileSync(path.join(PUBLIC_DIR,'admin.html')),'text/html; charset=utf-8'); }
    if(method==='GET'&&p==='/api/bootstrap'){
      let customer=null;
      if(session.role==='customer'&&session.customerId){const c=db.prepare('SELECT id,full_name,phone,email,created_at,alternate_phone,district,upazila,address,postal_code,preferred_language FROM customer_accounts WHERE id=? AND active=1').get(session.customerId);if(c)customer={id:c.id,name:c.full_name,phone:String(c.phone||'').startsWith('SOCIAL-')?'':c.phone,email:c.email||'',alternatePhone:c.alternate_phone||'',district:c.district||'',upazila:c.upazila||'',address:c.address||'',postalCode:c.postal_code||'',preferredLanguage:c.preferred_language||'bn',createdAt:c.created_at};}
      return sendJson(req,res,200,{csrfToken:session.csrfToken,setupRequired:!hasAdmin(db),authenticated:STAFF_ROLES.has(session.role),user:STAFF_ROLES.has(session.role)?session.user:null,customer,settings:settingsObject(db),currentIp:ip});
    }
    if(method==='GET'&&p==='/api/order-status'){
      if(!rateLimit(ip,'order-status-lookup',8,15*60_000)){recordSecurity('rate_limited',ip,ua,'order status lookup');return sendError(req,res,429,'LOOKUP_RATE_LIMITED');}
      const orderNumber=String(url.searchParams.get('orderNumber')||'').trim().toUpperCase();
      const phone=normalizePhone(url.searchParams.get('phone'));
      if(!/^CS-[A-Z0-9]+-[A-F0-9]{6}$/.test(orderNumber)||!phone)return sendError(req,res,404,'ORDER_NOT_FOUND');
      const order=db.prepare('SELECT id,order_number,phone,status,total,created_at,updated_at,items_json FROM orders WHERE order_number=? COLLATE NOCASE').get(orderNumber);
      const storedPhone=normalizePhone(order?.phone);
      if(!order||storedPhone!==phone)return sendError(req,res,404,'ORDER_NOT_FOUND');
      let itemCount=0;try{itemCount=JSON.parse(order.items_json||'[]').reduce((n,item)=>n+Math.max(0,Number(item.quantity)||0),0);}catch{}
      let shipmentRow=db.prepare('SELECT * FROM courier_shipments WHERE order_id=(SELECT id FROM orders WHERE order_number=? COLLATE NOCASE)').get(order.order_number);
      // For Steadfast shipments, attempt a bounded server-side refresh during a customer lookup.
      // If provider credentials/network are unavailable, keep the last known status instead of fabricating one.
      if(shipmentRow?.provider==='steadfast'&&(process.env.STEADFAST_API_KEY&&process.env.STEADFAST_SECRET_KEY)&&(shipmentRow.consignment_id||shipmentRow.tracking_number)){
        try{const trackingId=encodeURIComponent(shipmentRow.consignment_id||shipmentRow.tracking_number);const live=await fetch(`https://portal.packzy.com/api/v1/status_by_cid/${trackingId}`,{headers:{'Api-Key':process.env.STEADFAST_API_KEY,'Secret-Key':process.env.STEADFAST_SECRET_KEY,'Accept':'application/json'},signal:AbortSignal.timeout(5000)});if(live.ok){const payload=await live.json();const raw=String(payload.delivery_status||payload.status||'unknown').slice(0,80);const stamp=nowIso();db.prepare('UPDATE courier_shipments SET status=?,raw_status=?,updated_at=? WHERE order_id=?').run(raw,JSON.stringify(payload).slice(0,2000),stamp,order.id);const mapped=raw==='delivered'?'delivered':raw==='pending'?'shipped':null;if(mapped&&!['cancelled','returned'].includes(order.status))db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run(mapped,stamp,order.id);shipmentRow=db.prepare('SELECT * FROM courier_shipments WHERE order_id=?').get(order.id);}}catch{/* fallback to last known provider status */}
      }
      const shipment=rowShipment(shipmentRow);const latestOrder=db.prepare('SELECT status,updated_at FROM orders WHERE id=?').get(order.id);return sendJson(req,res,200,{orderNumber:order.order_number,status:latestOrder.status,total:order.total,createdAt:order.created_at,updatedAt:latestOrder.updated_at,itemCount,shipment:shipment?{provider:shipment.provider,trackingNumber:shipment.trackingNumber,consignmentId:shipment.consignmentId,status:shipment.status,trackingUrl:shipment.trackingUrl,updatedAt:shipment.updatedAt}:null});
    }
    if(method==='GET'&&p==='/api/products'){
      const rows=db.prepare('SELECT p.*, COALESCE((SELECT AVG(r.rating) FROM product_reviews r WHERE r.product_id=p.id AND r.approved=1),0) AS rating_avg, (SELECT COUNT(*) FROM product_reviews r WHERE r.product_id=p.id AND r.approved=1) AS review_count FROM products p WHERE p.active=1 ORDER BY p.id DESC').all().map(row=>({...rowProduct(row),rating:Number(row.rating_avg||0),reviewCount:Number(row.review_count||0)}));
      return sendJson(req,res,200,{products:rows});
    }
    if(method==='GET'&&p==='/api/categories'){
      const rows=db.prepare('SELECT DISTINCT category,category_en FROM products WHERE active=1 ORDER BY category').all();
      const unique=[...new Set(rows.flatMap(r=>[r.category,...(r.category_en?[r.category_en]:[])]))];return sendJson(req,res,200,{categories:unique});
    }
    if(method==='POST'&&p==='/api/track'){
      const body=await readJson(req,32*1024);if(body.consent!=='analytics')return sendJson(req,res,202,{ok:true,recorded:false});
      const event=String(body.event||'');if(!VALID_EVENTS.has(event))return sendError(req,res,400,'INVALID_EVENT');
      const detail=body.detail&&typeof body.detail==='object'?body.detail:{};let productId=Number(detail.productId);if(!Number.isSafeInteger(productId)||productId<1)productId=null;
      const safeDetail=[];if(typeof detail.language==='string')safeDetail.push(`language=${detail.language==='en'?'en':'bn'}`);if(Number.isFinite(+detail.quantity))safeDetail.push(`quantity=${Math.max(0,Math.min(99,+detail.quantity))}`);if(Number.isFinite(+detail.queryLength))safeDetail.push(`queryLength=${Math.max(0,Math.min(100,+detail.queryLength))}`);
      logActivity(db,{event,sessionId:session.id,ip,userAgent:ua,pathName:cleanPath(p,body.path||req.headers['x-page-path']||'/'),referrer:safeReferrer(req),productId,detail:safeDetail.join('; ')});
      return sendJson(req,res,202,{ok:true,recorded:true});
    }
    if(method==='GET'&&p==='/api/chat/status'){
      const cfg=settingsObject(db);return sendJson(req,res,200,{staffOnline:staffOnline(db),whatsappNumber:cfg.chatWhatsApp||'',messengerUrl:cfg.messengerUrl||'',welcomeMessage:cfg.welcomeMessage||'How can we help?',aiEnabled:cfg.aiChatEnabled!==false,aiProviderConfigured:Boolean(process.env.OPENAI_API_KEY)});
    }
    if(method==='POST'&&p==='/api/chat/session'){
      const body=await readJson(req,16*1024);if(!rateLimit(ip,'chat-start',12,60*60_000))return sendError(req,res,429,'CHAT_RATE_LIMITED');let thread;
      try{thread=getOrCreateChatThread(db,String(body.clientToken||''),session,String(body.name||''),String(body.phone||''));}catch(err){return sendError(req,res,400,err.message==='INVALID_CHAT_TOKEN'?'INVALID_CHAT_TOKEN':'INVALID_CHAT_SESSION');}
      return sendJson(req,res,200,{threadId:thread.id,status:thread.status,messages:chatMessages(db,thread.id),staffOnline:staffOnline(db),welcomeMessage:setting(db,'welcomeMessage','স্বাগতম! কীভাবে সাহায্য করতে পারি?')});
    }
    if(method==='GET'&&p==='/api/chat/messages'){
      const token=String(req.headers['x-chat-token']||'');if(!validChatToken(token))return sendError(req,res,400,'INVALID_CHAT_TOKEN');const thread=db.prepare('SELECT * FROM chat_threads WHERE client_token_hash=?').get(sha256(token));if(!thread)return sendError(req,res,404,'CHAT_THREAD_NOT_FOUND');
      return sendJson(req,res,200,{threadId:thread.id,status:thread.status,messages:chatMessages(db,thread.id),staffOnline:staffOnline(db),links:{whatsappNumber:setting(db,'chatWhatsApp',''),messengerUrl:setting(db,'messengerUrl','')}});
    }
    if(method==='POST'&&p==='/api/chat/messages'){
      if(!rateLimit(ip,'chat-message',50,10*60_000))return sendError(req,res,429,'CHAT_RATE_LIMITED');const body=await readJson(req,16*1024);const token=String(body.clientToken||'');const message=validateText(body.message,2000,{required:true,min:1});if(!validChatToken(token)||message===null)return sendError(req,res,400,'INVALID_CHAT_MESSAGE');
      let thread;try{thread=getOrCreateChatThread(db,token,session,String(body.name||''),String(body.phone||''));}catch{return sendError(req,res,400,'INVALID_CHAT_SESSION');}
      if(thread.status==='resolved')db.prepare("UPDATE chat_threads SET status='open' WHERE id=?").run(thread.id);
      db.prepare("INSERT INTO chat_messages(thread_id,sender_role,sender_id,body,created_at) VALUES(?,'customer',?,?,?)").run(thread.id,session.role==='customer'?session.user?.id||null:null,message,nowIso());
      const online=staffOnline(db);const now=nowIso();
      if(online){db.prepare("UPDATE chat_threads SET status='waiting',updated_at=?,last_message_at=? WHERE id=?").run(now,now,thread.id);}
      else {
        if(setting(db,'aiChatEnabled',true)!==false){const reply=await generateChatAssistantReply(message,db);db.prepare("INSERT INTO chat_messages(thread_id,sender_role,sender_id,body,created_at) VALUES(?,'ai',NULL,?,?)").run(thread.id,reply,nowIso());db.prepare("UPDATE chat_threads SET status='open',updated_at=?,last_message_at=? WHERE id=?").run(nowIso(),nowIso(),thread.id);}else{db.prepare("UPDATE chat_threads SET status='waiting',updated_at=?,last_message_at=? WHERE id=?").run(nowIso(),nowIso(),thread.id);}
      }
      logActivity(db,{event:'chat_message',sessionId:session.id,ip,userAgent:ua,pathName:'/chat',detail:online?'customer message; staff online':(process.env.OPENAI_API_KEY?'offline AI reply':'offline assistant reply')});
      return sendJson(req,res,201,{ok:true,staffOnline:online,messages:chatMessages(db,thread.id)});
    }
    if(method==='GET'&&p==='/api/account/me'){
      if(session.role!=='customer'||!session.user)return sendJson(req,res,200,{authenticated:false});
      const customer=db.prepare('SELECT id,full_name,phone,email,created_at,last_login_at,alternate_phone,district,upazila,address,postal_code,preferred_language FROM customer_accounts WHERE id=? AND active=1').get(session.user.id);
      if(!customer)return sendJson(req,res,200,{authenticated:false});
      const phone=String(customer.phone||'').startsWith('SOCIAL-')?'':customer.phone;
      return sendJson(req,res,200,{authenticated:true,user:{id:customer.id,name:customer.full_name,phone,email:customer.email||'',alternatePhone:customer.alternate_phone||'',district:customer.district||'',upazila:customer.upazila||'',address:customer.address||'',postalCode:customer.postal_code||'',preferredLanguage:customer.preferred_language||'bn',createdAt:customer.created_at,lastLoginAt:customer.last_login_at||''}});
    }
    if(method==='GET'&&p==='/api/reviews'){
      const productId=Number(url.searchParams.get('productId')); if(!Number.isSafeInteger(productId)||productId<1)return sendError(req,res,400,'INVALID_PRODUCT');
      const rows=db.prepare('SELECT customer_name,rating,title,body,created_at FROM product_reviews WHERE product_id=? AND approved=1 ORDER BY created_at DESC LIMIT 50').all(productId);
      return sendJson(req,res,200,{reviews:rows.map(r=>({customerName:r.customer_name,rating:r.rating,title:r.title,body:r.body,createdAt:r.created_at}))});
    }
    if(method==='POST'&&p==='/api/reviews'){
      if(!rateLimit(ip,'review-submit',6,60*60_000))return sendError(req,res,429,'REVIEW_RATE_LIMITED');
      const body=await readJson(req,16*1024); const productId=Number(body.productId),rating=Number(body.rating);
      const orderNumber=String(body.orderNumber||'').trim().toUpperCase(),phone=normalizePhone(body.phone);
      const customerName=validateText(body.customerName,80,{required:true,min:2}),title=validateText(body.title||'',100),reviewBody=validateText(body.body,1000,{required:true,min:10});
      if(!Number.isSafeInteger(productId)||productId<1||!Number.isInteger(rating)||rating<1||rating>5||!phone||customerName===null||title===null||reviewBody===null||!/^CS-[A-Z0-9]+-[A-F0-9]{6}$/.test(orderNumber))return sendError(req,res,400,'INVALID_REVIEW');
      const order=db.prepare('SELECT id,phone,items_json,status FROM orders WHERE order_number=? COLLATE NOCASE').get(orderNumber);
      if(!order||normalizePhone(order.phone)!==phone)return sendError(req,res,404,'ORDER_NOT_FOUND');
      if(order.status!=='delivered')return sendError(req,res,409,'REVIEW_REQUIRES_DELIVERED_ORDER');
      let items=[];try{items=JSON.parse(order.items_json)}catch{} if(!Array.isArray(items)||!items.some(i=>Number(i?.productId)===productId))return sendError(req,res,403,'PRODUCT_NOT_IN_ORDER');
      try{db.prepare('INSERT INTO product_reviews(product_id,order_id,customer_name,rating,title,body,approved,created_at) VALUES(?,?,?,?,?,?,0,?)').run(productId,order.id,customerName,rating,title,reviewBody,nowIso());}catch(err){if(String(err.message).includes('UNIQUE'))return sendError(req,res,409,'REVIEW_ALREADY_EXISTS');throw err;}
      logActivity(db,{event:'review_submitted',sessionId:session.id,ip,userAgent:ua,pathName:p,orderId:order.id,productId,detail:'review pending moderation'});
      return sendJson(req,res,201,{ok:true,message:'REVIEW_PENDING_MODERATION'});
    }
    if(method==='POST'&&p==='/api/account/register'){
      if(!rateLimit(ip,'customer-register',6,60*60_000))return sendError(req,res,429,'REGISTER_RATE_LIMIT');
      const body=await readJson(req,32*1024);const name=validateText(body.name,100,{required:true,min:2});const phone=normalizePhone(body.phone);const email=String(body.email||'').trim().toLowerCase();const password=String(body.password||'');
      const district=validateText(body.district||'',80),upazila=validateText(body.upazila||'',80),address=validateText(body.address||'',500),postalCode=validateText(body.postalCode||'',20),alternatePhone=body.alternatePhone?normalizePhone(body.alternatePhone):'';
      if(name===null||!phone||email.length>200||(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))||password.length<8||password.length>200||[district,upazila,address,postalCode].some(v=>v===null)||(body.alternatePhone&&!alternatePhone))return sendError(req,res,400,'INVALID_REGISTRATION');
      let result;try{const ins=db.prepare('INSERT INTO customer_accounts(full_name,phone,email,password_hash,active,created_at,alternate_phone,district,upazila,address,postal_code,preferred_language) VALUES(?,?,?,?,1,?,?,?,?,?,?,?)').run(name,phone,email||null,hashPassword(password),nowIso(),alternatePhone||'',district,upazila,address,postalCode,body.preferredLanguage==='en'?'en':'bn');result={id:Number(ins.lastInsertRowid),name,phone,email,alternatePhone:alternatePhone||'',district,upazila,address,postalCode,preferredLanguage:body.preferredLanguage==='en'?'en':'bn'};}catch(err){if(String(err.message).includes('UNIQUE'))return sendError(req,res,409,'ACCOUNT_ALREADY_EXISTS');throw err;}
      revokeSession(db,session.tokenHash);const fresh=createSession(db,ip,ua,{id:result.id,role:'customer',fullName:result.name,phone:result.phone,email:result.email,rememberMe:Boolean(body.rememberMe)});setNewCookie(res,fresh.token,{role:'customer'},Date.parse(fresh.expiresAt)-Date.now());logActivity(db,{event:'customer_registered',sessionId:fresh.id,ip,userAgent:ua,pathName:'/account',detail:'customer account registered'});
      return sendJson(req,res,201,{ok:true,csrfToken:fresh.csrfToken,authenticated:true,user:result});
    }
    if(method==='POST'&&p==='/api/account/login'){
      const body=await readJson(req,32*1024);const identity=String(body.identity||'').trim();const rememberMe=body.rememberMe===true;const idHash=sha256(identity.toLowerCase());if(!rateLimit(ip,'customer-login',10,15*60_000))return sendError(req,res,429,'LOGIN_RATE_LIMIT');
      const since=new Date(Date.now()-LOGIN_WINDOW_MS).toISOString();const attempts=db.prepare('SELECT COUNT(*) n FROM login_attempts WHERE ip=? AND email_hash=? AND success=0 AND created_at>?').get(ip,idHash,since).n;
      if(attempts>=LOGIN_MAX_FAILURES)return sendError(req,res,429,'LOGIN_RATE_LIMIT');
      const phone=normalizePhone(identity);const email=identity.toLowerCase();const customer=db.prepare('SELECT * FROM customer_accounts WHERE active=1 AND (phone=? OR email=? COLLATE NOCASE)').get(phone||'__invalid_phone__',email);
      const password=String(body.password||'');if(!customer)performDummyPasswordCheck(password);if(!customer||password.length>200||!verifyPassword(password,customer.password_hash)){
        db.prepare('INSERT INTO login_attempts(ip,email_hash,success,created_at) VALUES(?,?,0,?)').run(ip,idHash,nowIso());return sendError(req,res,401,'INVALID_CREDENTIALS');
      }
      db.prepare('INSERT INTO login_attempts(ip,email_hash,success,created_at) VALUES(?,?,1,?)').run(ip,idHash,nowIso());db.prepare('DELETE FROM login_attempts WHERE ip=? AND email_hash=? AND success=0').run(ip,idHash);db.prepare('UPDATE customer_accounts SET last_login_at=? WHERE id=?').run(nowIso(),customer.id);
      revokeSession(db,session.tokenHash);const fresh=createSession(db,ip,ua,{id:customer.id,role:'customer',fullName:customer.full_name,phone:customer.phone,email:customer.email||'',rememberMe});setNewCookie(res,fresh.token,{role:'customer'},Date.parse(fresh.expiresAt)-Date.now());logActivity(db,{event:'customer_login',sessionId:fresh.id,ip,userAgent:ua,pathName:'/account',detail:rememberMe?'customer login; remembered session':'customer login'});
      return sendJson(req,res,200,{ok:true,csrfToken:fresh.csrfToken,authenticated:true,user:{id:customer.id,name:customer.full_name,phone:String(customer.phone||'').startsWith('SOCIAL-')?'':customer.phone,email:customer.email||'',alternatePhone:customer.alternate_phone||'',district:customer.district||'',upazila:customer.upazila||'',address:customer.address||'',postalCode:customer.postal_code||'',preferredLanguage:customer.preferred_language||'bn'}});
    }
    if(method==='POST'&&p==='/api/account/logout'){
      if(session.role!=='customer')return sendError(req,res,401,'CUSTOMER_LOGIN_REQUIRED');revokeSession(db,session.tokenHash);const fresh=createSession(db,ip,ua);setNewCookie(res,fresh.token,null);return sendJson(req,res,200,{ok:true,csrfToken:fresh.csrfToken});
    }
    if(method==='PATCH'&&p==='/api/account/profile'){
      if(session.role!=='customer'||!session.user)return sendError(req,res,401,'CUSTOMER_LOGIN_REQUIRED');
      const body=await readJson(req,16*1024);const name=validateText(body.name,100,{required:true,min:2});const email=String(body.email||'').trim().toLowerCase();
      const alternatePhoneRaw=String(body.alternatePhone||'').trim();const alternatePhone=alternatePhoneRaw?normalizePhone(alternatePhoneRaw):'';
      const district=validateText(body.district||'',80),upazila=validateText(body.upazila||'',80),address=validateText(body.address||'',500),postalCode=validateText(body.postalCode||'',20),preferredLanguage=body.preferredLanguage==='en'?'en':'bn';
      const phoneRaw=String(body.phone||'').trim();const phone=phoneRaw?normalizePhone(phoneRaw):null;
      if(name===null||email.length>200||(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))||(phoneRaw&&!phone)||(alternatePhoneRaw&&!alternatePhone)||[district,upazila,address,postalCode].some(v=>v===null))return sendError(req,res,400,'INVALID_PROFILE');
      const current=db.prepare('SELECT phone FROM customer_accounts WHERE id=?').get(session.user.id);const nextPhone=phone||current?.phone||'';
      try{db.prepare('UPDATE customer_accounts SET full_name=?,phone=?,email=?,alternate_phone=?,district=?,upazila=?,address=?,postal_code=?,preferred_language=? WHERE id=?').run(name,nextPhone,email||null,alternatePhone||'',district,upazila,address,postalCode,preferredLanguage,session.user.id);}catch(err){if(String(err.message).includes('UNIQUE'))return sendError(req,res,409,String(err.message).includes('phone')?'PHONE_ALREADY_IN_USE':'EMAIL_ALREADY_IN_USE');throw err;}
      return sendJson(req,res,200,{ok:true,user:{id:session.user.id,name,phone:String(nextPhone).startsWith('SOCIAL-')?'':nextPhone,email,alternatePhone:alternatePhone||'',district,upazila,address,postalCode,preferredLanguage}});
    }
    if(method==='GET'&&p==='/api/account/orders'){
      if(session.role!=='customer'||!session.user)return sendError(req,res,401,'CUSTOMER_LOGIN_REQUIRED');const orders=db.prepare('SELECT * FROM orders WHERE customer_account_id=? ORDER BY created_at DESC LIMIT 100').all(session.user.id).map(rowOrder);return sendJson(req,res,200,{orders});
    }
    if(method==='POST'&&p==='/api/orders'){
      if(!rateLimit(ip,'order-create-ip',10,60*60_000))return sendError(req,res,429,'ORDER_RATE_LIMITED');
      if(!rateLimit(ip,`order-create-session-${session.id}`,5,60*60_000))return sendError(req,res,429,'ORDER_RATE_LIMITED');
      if(session.role==='customer'&&session.user&&!rateLimit(ip,`order-create-customer-${session.user.id}`,5,60*60_000))return sendError(req,res,429,'ORDER_RATE_LIMITED');
      const body=await readJson(req,64*1024);const {customer,items}=validateCheckout(body);let result;
      try {
        db.exec('BEGIN IMMEDIATE');let subtotal=0;const finalItems=[];
        for(const row of items){const product=db.prepare('SELECT * FROM products WHERE id=? AND active=1').get(row.productId);if(!product||product.stock<row.quantity)throw new Error('OUT_OF_STOCK');const colors=safeJsonArray(product.colors_json),sizes=safeJsonArray(product.sizes_json);if((colors.length?!colors.includes(row.color):Boolean(row.color))||(sizes.length?!sizes.includes(row.size):Boolean(row.size)))throw new Error('INVALID_PRODUCT_VARIANT');finalItems.push({productId:product.id,sku:product.sku,name:product.name,nameEn:product.name_en,unitPrice:product.price,quantity:row.quantity,imageUrl:product.image_url,color:row.color||'',size:row.size||''});subtotal+=product.price*row.quantity;if(!Number.isSafeInteger(subtotal)||subtotal>100000000)throw new Error('ORDER_TOTAL_INVALID');}
        for(const it of finalItems){const updated=db.prepare('UPDATE products SET stock=stock-?,updated_at=? WHERE id=? AND stock>=?').run(it.quantity,nowIso(),it.productId,it.quantity);if(updated.changes!==1)throw new Error('OUT_OF_STOCK');}
        const shippingFee=Number(setting(db,'shippingFee',80));const total=subtotal+shippingFee;const orderNumber=makeOrderNumber();const now=nowIso();
        const ins=db.prepare(`INSERT INTO orders(order_number,customer_name,phone,district,upazila,address,notes,items_json,subtotal,shipping_fee,total,status,stock_reserved,ip,user_agent,referrer,session_id,customer_account_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
        const accountId=session.role==='customer'?session.user.id:null;
        const ret=ins.run(orderNumber,customer.customerName,customer.phone,customer.district,customer.upazila,customer.address,customer.notes,JSON.stringify(finalItems),subtotal,shippingFee,total,'pending',1,ip,ua,safeReferrer(req),session.id,accountId,now,now);
        result={id:Number(ret.lastInsertRowid),orderNumber,subtotal,shippingFee,total,status:'pending',createdAt:now};db.exec('COMMIT');
      } catch(err) {try{db.exec('ROLLBACK');}catch{} if(err.message==='OUT_OF_STOCK')return sendError(req,res,409,'OUT_OF_STOCK');throw err;}
      logActivity(db,{event:'order_placed',sessionId:session.id,ip,userAgent:ua,pathName:'/checkout',referrer:safeReferrer(req),orderId:result.id,detail:`${result.orderNumber}; total=${result.total}`});
      return sendJson(req,res,201,{ok:true,order:result});
    }
    if(method==='POST'&&p==='/api/auth/setup'){
      const body=await readJson(req,32*1024);if(hasAdmin(db))return sendError(req,res,409,'SETUP_ALREADY_COMPLETE');
      const expected=getSetupToken();if(!safeEqual(String(body.setupToken||''),expected)){recordSecurity('setup_failed',ip,ua);return sendError(req,res,403,'SETUP_TOKEN_INVALID');}
      const email=validateText(body.email,200,{required:true,min:5});const password=String(body.password||'');
      if(email===null||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return sendError(req,res,400,'INVALID_EMAIL');
      if(password.length<8||password.length>200)return sendError(req,res,400,'PASSWORD_POLICY: use at least 8 characters');
      const tokenHash=session.tokenHash;const ins=db.prepare('INSERT INTO admins(email,password_hash,created_at,active) VALUES(?,?,?,1)').run(email.toLowerCase(),hashPassword(password),nowIso());const admin={id:Number(ins.lastInsertRowid),email:email.toLowerCase(),role:'admin',permissions:[]};revokeSession(db,tokenHash);const fresh=createSession(db,ip,ua,admin);setNewCookie(res,fresh.token,admin);recordSecurity('setup_complete',ip,ua,`adminId=${admin.id}`);
      try{if(fs.existsSync(setupTokenFile))fs.rmSync(setupTokenFile,{force:true});}catch{}
      return sendJson(req,res,201,{ok:true,csrfToken:fresh.csrfToken,user:admin});
    }
    if(method==='POST'&&p==='/api/auth/login'){
      const body=await readJson(req,32*1024);const email=String(body.email||'').trim().toLowerCase();const emailHash=sha256(email);const since=new Date(Date.now()-LOGIN_WINDOW_MS).toISOString();const recent=db.prepare('SELECT COUNT(*) AS n FROM login_attempts WHERE ip=? AND email_hash=? AND success=0 AND created_at>?').get(ip,emailHash,since).n;const recentIp=db.prepare('SELECT COUNT(*) AS n FROM login_attempts WHERE ip=? AND success=0 AND created_at>?').get(ip,since).n;
      if(recent>=LOGIN_MAX_FAILURES||recentIp>=20){recordSecurity('rate_limited',ip,ua,'admin login');return sendError(req,res,429,'LOGIN_RATE_LIMIT');}
      const admin=db.prepare('SELECT * FROM admins WHERE email=? COLLATE NOCASE AND active=1').get(email);const password=String(body.password||'');
      if(!admin)performDummyPasswordCheck(password);
      if(!admin||password.length>200||!verifyPassword(password,admin.password_hash)) {db.prepare('INSERT INTO login_attempts(ip,email_hash,success,created_at) VALUES(?,?,0,?)').run(ip,emailHash,nowIso());recordSecurity('login_failed',ip,ua,`emailHash=${emailHash.slice(0,12)}`);return sendError(req,res,401,'INVALID_CREDENTIALS');}
      db.prepare('INSERT INTO login_attempts(ip,email_hash,success,created_at) VALUES(?,?,1,?)').run(ip,emailHash,nowIso());db.prepare('DELETE FROM login_attempts WHERE ip=? AND email_hash=? AND success=0').run(ip,emailHash);db.prepare('UPDATE admins SET last_login_at=? WHERE id=?').run(nowIso(),admin.id);
      const tokenHash=session.tokenHash;revokeSession(db,tokenHash);let staffPermissions=[];try{staffPermissions=JSON.parse(admin.permissions_json||'[]')}catch{}const staff={id:admin.id,email:admin.email,role:admin.role||'admin',permissions:staffPermissions};const fresh=createSession(db,ip,ua,staff);setNewCookie(res,fresh.token,staff);recordSecurity('login_success',ip,ua,`adminId=${admin.id}; role=${staff.role}`);return sendJson(req,res,200,{ok:true,csrfToken:fresh.csrfToken,user:{id:admin.id,email:admin.email,role:staff.role,permissions:staffPermissions}});
    }
    if(method==='POST'&&p==='/api/auth/logout'){
      if(!checkCsrf(req,session))return sendError(req,res,403,'CSRF_VALIDATION_FAILED');revokeSession(db,session.tokenHash);const fresh=createSession(db,ip,ua);setNewCookie(res,fresh.token,null);return sendJson(req,res,200,{ok:true});
    }
    // Static files: only fixed public paths / upload filenames are served.
    if(method==='GET'&&p.startsWith('/css/'))return serveStatic(req,res,p,'css');
    if(method==='GET'&&p.startsWith('/js/'))return serveStatic(req,res,p,'js');
    if(method==='GET'&&p.startsWith('/assets/'))return serveStatic(req,res,p,'assets');
    if(method==='GET'&&p.startsWith('/uploads/'))return serveUploaded(req,res,p,uploadDir);

    if(p.startsWith('/api/admin/') && !requireAdmin(req,res,session)) return;
    const imageUploadRoute=p==='/api/admin/uploads/image'||/^\/api\/admin\/uploads\/image\//.test(p);
    if(p.startsWith('/api/admin/') && imageUploadRoute && !hasPermission(session,'products') && !hasPermission(session,'customization')) return sendError(req,res,403,'PERMISSION_DENIED','Missing permission: products or customization');
    if(p.startsWith('/api/admin/') && !imageUploadRoute && !requirePermission(req,res,session,adminRoutePermission(p,method))) return;
    if(p.startsWith('/api/admin/') && csrfNeeded && !checkCsrf(req,session))return sendError(req,res,403,'CSRF_VALIDATION_FAILED');
    if(method==='POST'&&p==='/api/admin/uploads/image'){
      const contentType=String(req.headers['content-type']||'').split(';')[0].trim().toLowerCase();
      const bytes=await readBuffer(req,MAX_UPLOAD_BYTES);const imageUrl=saveImageBuffer(bytes,contentType,uploadDir);
      logActivity(db,{event:'image_uploaded',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`type=${contentType}; bytes=${bytes.length}`});
      return sendJson(req,res,201,{ok:true,imageUrl,size:bytes.length,contentType});
    }
    const uploadedImageMatch=p.match(/^\/api\/admin\/uploads\/image\/([a-f0-9]{32}\.(?:jpg|png|webp))$/);
    if(uploadedImageMatch&&method==='DELETE'){
      const imageUrl='/uploads/'+uploadedImageMatch[1];
      const productUse=db.prepare('SELECT COUNT(*) AS n FROM products WHERE image_url=? OR images_json LIKE ?').get(imageUrl,`%${uploadedImageMatch[1]}%`).n;
      const logoUse=settingsObject(db).logoUrl===imageUrl;
      const customSectionUse=(settingsObject(db).customSections||[]).some(section=>section.imageUrl===imageUrl);
      const orderUse=db.prepare('SELECT items_json FROM orders').all().some(row=>{try{return JSON.parse(row.items_json||'[]').some(item=>item?.imageUrl===imageUrl);}catch{return false;}});
      if(productUse||logoUse||customSectionUse||orderUse)return sendError(req,res,409,'IMAGE_IN_USE');
      const full=path.join(uploadDir,uploadedImageMatch[1]);if(!fs.existsSync(full))return sendError(req,res,404,'IMAGE_NOT_FOUND');
      fs.rmSync(full,{force:true});return sendJson(req,res,200,{ok:true});
    }
    if(p.startsWith('/api/admin/staff')){
      if(!isOwner(session))return sendError(req,res,403,'OWNER_ONLY');
      if(method==='GET'&&p==='/api/admin/staff'){
        const rows=db.prepare('SELECT id,email,role,permissions_json,active,created_at,last_login_at FROM admins ORDER BY id ASC').all();
        return sendJson(req,res,200,{staff:rows.map(a=>({id:a.id,email:a.email,role:a.role||'admin',permissions:safeJsonArray(a.permissions_json),active:!!a.active,createdAt:a.created_at,lastLoginAt:a.last_login_at,online:!!db.prepare("SELECT 1 FROM sessions WHERE user_id=? AND role IN ('admin','moderator','parent') AND revoked_at IS NULL AND expires_at>? AND last_seen_at>? LIMIT 1").get(a.id,nowIso(),new Date(Date.now()-3*60_000).toISOString())}))});
      }
      if(method==='POST'&&p==='/api/admin/staff'){
        const body=await readJson(req,32*1024);const email=validateText(body.email,200,{required:true,min:5});const password=String(body.password||'');const role=String(body.role||'moderator');const permissions=Array.isArray(body.permissions)?[...new Set(body.permissions.filter(x=>STAFF_PERMISSIONS.has(x)&&x!=='staff'))]:[];
        if(email===null||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||password.length<8||password.length>200||!['moderator','parent'].includes(role))return sendError(req,res,400,'INVALID_STAFF_INPUT');
        try{const now=nowIso();const ret=db.prepare('INSERT INTO admins(email,password_hash,created_at,active,role,permissions_json,created_by) VALUES(?,?,?,1,?,?,?)').run(email.toLowerCase(),hashPassword(password),now,role,JSON.stringify(permissions),session.user.id);logActivity(db,{event:'staff_created',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`staffId=${ret.lastInsertRowid}; role=${role}`});return sendJson(req,res,201,{ok:true,id:Number(ret.lastInsertRowid)});}catch(err){if(String(err.message).includes('UNIQUE'))return sendError(req,res,409,'EMAIL_ALREADY_IN_USE');throw err;}
      }
      const staffMatch=p.match(/^\/api\/admin\/staff\/(\d+)$/);
      if(staffMatch&&method==='PATCH'){
        const id=Number(staffMatch[1]);const target=db.prepare('SELECT * FROM admins WHERE id=?').get(id);if(!target)return sendError(req,res,404,'STAFF_NOT_FOUND');if((target.role||'admin')==='admin')return sendError(req,res,403,'OWNER_ACCOUNT_PROTECTED');
        const body=await readJson(req,32*1024);const updates=[];const values=[];
        if(typeof body.active==='boolean'){updates.push('active=?');values.push(body.active?1:0);}
        if(body.role!==undefined){const role=String(body.role);if(!['moderator','parent'].includes(role))return sendError(req,res,400,'INVALID_STAFF_ROLE');updates.push('role=?');values.push(role);}
        if(body.permissions!==undefined){if(!Array.isArray(body.permissions))return sendError(req,res,400,'INVALID_STAFF_PERMISSIONS');const perms=[...new Set(body.permissions.filter(x=>STAFF_PERMISSIONS.has(x)&&x!=='staff'))];updates.push('permissions_json=?');values.push(JSON.stringify(perms));}
        if(body.password!==undefined){const password=String(body.password||'');if(password.length<8||password.length>200)return sendError(req,res,400,'PASSWORD_POLICY');updates.push('password_hash=?');values.push(hashPassword(password));}
        if(!updates.length)return sendError(req,res,400,'NO_CHANGES');values.push(id);db.prepare(`UPDATE admins SET ${updates.join(',')} WHERE id=?`).run(...values);db.prepare('UPDATE sessions SET revoked_at=? WHERE user_id=?').run(nowIso(),id);logActivity(db,{event:'staff_updated',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`staffId=${id}`});return sendJson(req,res,200,{ok:true});
      }
      if(staffMatch&&method==='DELETE'){
        const id=Number(staffMatch[1]);const target=db.prepare('SELECT id,role FROM admins WHERE id=?').get(id);if(!target)return sendError(req,res,404,'STAFF_NOT_FOUND');if(id===session.user.id||(target.role||'admin')==='admin')return sendError(req,res,403,'STAFF_DELETE_NOT_ALLOWED');
        db.prepare('UPDATE admins SET active=0 WHERE id=?').run(id);db.prepare('UPDATE sessions SET revoked_at=? WHERE user_id=?').run(nowIso(),id);logActivity(db,{event:'staff_deactivated',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`staffId=${id}`});return sendJson(req,res,200,{ok:true});
      }
      return sendError(req,res,405,'METHOD_NOT_ALLOWED');
    }
    if(method==='GET'&&p==='/api/admin/customers'){
      const rows=db.prepare(`SELECT c.id,c.full_name,c.phone,c.email,c.created_at,c.last_login_at,
        COUNT(o.id) order_count,COALESCE(SUM(CASE WHEN o.status NOT IN ('cancelled','returned') THEN o.total ELSE 0 END),0) total_spent,
        MAX(o.created_at) last_order_at FROM customer_accounts c LEFT JOIN orders o ON o.customer_account_id=c.id
        GROUP BY c.id ORDER BY c.created_at DESC LIMIT 1000`).all();
      return sendJson(req,res,200,{customers:rows.map(c=>({id:c.id,name:c.full_name,phone:c.phone,email:c.email||'',createdAt:c.created_at,lastLoginAt:c.last_login_at,orderCount:c.order_count,totalSpent:c.total_spent,lastOrderAt:c.last_order_at}))});
    }
    if(p==='/api/admin/chat/threads'&&method==='GET'){
      const rows=db.prepare(`SELECT t.*, (SELECT body FROM chat_messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) last_message,
        (SELECT sender_role FROM chat_messages m WHERE m.thread_id=t.id ORDER BY m.id DESC LIMIT 1) last_sender,
        (SELECT COUNT(*) FROM chat_messages m WHERE m.thread_id=t.id AND m.sender_role='customer' AND m.read_at IS NULL) unread
        FROM chat_threads t ORDER BY t.last_message_at DESC LIMIT 200`).all();
      return sendJson(req,res,200,{staffOnline:staffOnline(db),threads:rows.map(t=>({id:t.id,name:t.guest_name,phone:t.guest_phone,status:t.status,lastMessage:t.last_message||'',lastSender:t.last_sender||'',unread:t.unread||0,updatedAt:t.last_message_at,customerId:t.customer_id||null}))});
    }
    const adminChatMatch=p.match(/^\/api\/admin\/chat\/threads\/(\d+)$/);
    if(adminChatMatch){
      const threadId=Number(adminChatMatch[1]);const thread=db.prepare('SELECT * FROM chat_threads WHERE id=?').get(threadId);if(!thread)return sendError(req,res,404,'CHAT_THREAD_NOT_FOUND');
      if(method==='GET')return sendJson(req,res,200,{thread:{id:thread.id,name:thread.guest_name,phone:thread.guest_phone,status:thread.status,customerId:thread.customer_id||null},messages:chatMessages(db,threadId,{markRead:true}),staffOnline:staffOnline(db)});
      if(method==='POST'){
        const body=await readJson(req,16*1024);const message=validateText(body.message,2000,{required:true,min:1});if(message===null)return sendError(req,res,400,'INVALID_CHAT_MESSAGE');const now=nowIso();db.prepare("INSERT INTO chat_messages(thread_id,sender_role,sender_id,body,created_at) VALUES(?,'admin',?,?,?)").run(threadId,session.user.id,message,now);db.prepare("UPDATE chat_threads SET status='open',updated_at=?,last_message_at=? WHERE id=?").run(now,now,threadId);logActivity(db,{event:'chat_staff_reply',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`threadId=${threadId}`});return sendJson(req,res,201,{ok:true,messages:chatMessages(db,threadId)});
      }
      if(method==='PATCH'){
        const body=await readJson(req,8*1024);const status=String(body.status||'');if(!['open','waiting','resolved'].includes(status))return sendError(req,res,400,'INVALID_CHAT_STATUS');db.prepare('UPDATE chat_threads SET status=?,updated_at=? WHERE id=?').run(status,nowIso(),threadId);return sendJson(req,res,200,{ok:true});
      }
      return sendError(req,res,405,'METHOD_NOT_ALLOWED');
    }
    if(method==='GET'&&p==='/api/admin/overview'){
      const productCount=db.prepare('SELECT COUNT(*) n FROM products').get().n;const orderCount=db.prepare('SELECT COUNT(*) n FROM orders').get().n;const pendingCount=db.prepare("SELECT COUNT(*) n FROM orders WHERE status IN ('pending','confirmed','processing')").get().n;const orderValue=db.prepare("SELECT COALESCE(SUM(total),0) n FROM orders WHERE status NOT IN ('cancelled','returned')").get().n;
      const recentOrders=db.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 8').all().map(rowOrder);const recentActivity=db.prepare('SELECT * FROM activity_events ORDER BY created_at DESC LIMIT 8').all().map(a=>rowActivity(a,db));
      return sendJson(req,res,200,{productCount,orderCount,pendingCount,orderValue,recentOrders,recentActivity});
    }
    if(method==='GET'&&p==='/api/admin/products')return sendJson(req,res,200,{products:db.prepare('SELECT * FROM products ORDER BY id DESC').all().map(rowProduct)});
    if(method==='POST'&&p==='/api/admin/products'){
      const body=await readJson(req,32*1024*1024);const product=productFromInput(db,body,null,uploadDir);const now=nowIso();const sku=`SKU-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
      const ret=db.prepare('INSERT INTO products(sku,name,name_en,category,category_en,description,description_en,price,compare_at,stock,image_url,images_json,colors_json,sizes_json,active,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').run(sku,product.name,product.nameEn,product.category,product.categoryEn,product.description,product.descriptionEn,product.price,product.compareAt,product.stock,product.imageUrl,JSON.stringify(product.imageUrls),JSON.stringify(product.colors),JSON.stringify(product.sizes),product.active?1:0,now,now);
      logActivity(db,{event:'product_created',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`productId=${ret.lastInsertRowid}`});return sendJson(req,res,201,{ok:true,product:rowProduct(db.prepare('SELECT * FROM products WHERE id=?').get(Number(ret.lastInsertRowid)))});
    }
    const productMatch=p.match(/^\/api\/admin\/products\/(\d+)$/);
    if(productMatch){const id=Number(productMatch[1]);const old=db.prepare('SELECT * FROM products WHERE id=?').get(id);if(!old)return sendError(req,res,404,'PRODUCT_NOT_FOUND');
      if(method==='PUT') {const body=await readJson(req,32*1024*1024);const product=productFromInput(db,body,old,uploadDir);const oldImageFiles=[...uploadedFilenames(old.image_url),...uploadedFilenames(safeJsonArray(old.images_json))];db.prepare('UPDATE products SET name=?,name_en=?,category=?,category_en=?,description=?,description_en=?,price=?,compare_at=?,stock=?,image_url=?,images_json=?,colors_json=?,sizes_json=?,active=?,updated_at=? WHERE id=?').run(product.name,product.nameEn,product.category,product.categoryEn,product.description,product.descriptionEn,product.price,product.compareAt,product.stock,product.imageUrl,JSON.stringify(product.imageUrls),JSON.stringify(product.colors),JSON.stringify(product.sizes),product.active?1:0,nowIso(),id);deleteUnusedUploadedFiles(db,uploadDir,oldImageFiles);logActivity(db,{event:'product_updated',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`productId=${id}`});return sendJson(req,res,200,{ok:true,product:rowProduct(db.prepare('SELECT * FROM products WHERE id=?').get(id))});}
      if(method==='DELETE'){const oldImageFiles=[...uploadedFilenames(old.image_url),...uploadedFilenames(safeJsonArray(old.images_json))];db.prepare('DELETE FROM products WHERE id=?').run(id);deleteUnusedUploadedFiles(db,uploadDir,oldImageFiles);logActivity(db,{event:'product_deleted',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`productId=${id}`});return sendJson(req,res,200,{ok:true});}
    }
    if(method==='GET'&&p==='/api/admin/orders')return sendJson(req,res,200,{orders:db.prepare('SELECT * FROM orders ORDER BY created_at DESC LIMIT 1000').all().map(rowOrder)});
    if(method==='GET'&&p==='/api/admin/reviews'){
      const rows=db.prepare('SELECT r.*,p.name AS product_name,o.order_number FROM product_reviews r JOIN products p ON p.id=r.product_id JOIN orders o ON o.id=r.order_id ORDER BY r.created_at DESC LIMIT 500').all();
      return sendJson(req,res,200,{reviews:rows.map(r=>({id:r.id,productId:r.product_id,productName:r.product_name,orderNumber:r.order_number,customerName:r.customer_name,rating:r.rating,title:r.title,body:r.body,approved:!!r.approved,createdAt:r.created_at}))});
    }
    const reviewAdminMatch=p.match(/^\/api\/admin\/reviews\/(\d+)$/);
    if(reviewAdminMatch&&method==='PATCH'){
      const body=await readJson(req,8*1024); if(typeof body.approved!=='boolean')return sendError(req,res,400,'INVALID_REVIEW_STATUS');
      const changed=db.prepare('UPDATE product_reviews SET approved=? WHERE id=?').run(body.approved?1:0,Number(reviewAdminMatch[1])); if(!changed.changes)return sendError(req,res,404,'REVIEW_NOT_FOUND');
      logActivity(db,{event:'review_moderated',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`reviewId=${reviewAdminMatch[1]} approved=${body.approved}`});return sendJson(req,res,200,{ok:true});
    }
    const shipmentMatch=p.match(/^\/api\/admin\/orders\/(\d+)\/shipment(?:\/(refresh|dispatch))?$/);
    if(shipmentMatch){
      const orderId=Number(shipmentMatch[1]);const order=db.prepare('SELECT * FROM orders WHERE id=?').get(orderId);if(!order)return sendError(req,res,404,'ORDER_NOT_FOUND');
      if(method==='GET'&&!shipmentMatch[2])return sendJson(req,res,200,{shipment:rowShipment(db.prepare('SELECT * FROM courier_shipments WHERE order_id=?').get(orderId)),configured:{steadfast:!!(process.env.STEADFAST_API_KEY&&process.env.STEADFAST_SECRET_KEY)}});
      if(method==='PUT'&&!shipmentMatch[2]){
        const body=await readJson(req,16*1024);const provider=String(body.provider||'manual');if(!['manual','pathao','redx','steadfast','paperfly','sundarban','other'].includes(provider))return sendError(req,res,400,'INVALID_COURIER');
        const trackingNumber=validateText(body.trackingNumber||'',120),consignmentId=validateText(body.consignmentId||'',120),status=validateText(body.status||'booked',60,{required:true,min:2}),trackingUrl=validateText(body.trackingUrl||'',500),note=validateText(body.note||'',500);
        if([trackingNumber,consignmentId,status,trackingUrl,note].some(v=>v===null)||!VALID_SHIPMENT_STATUSES.has(status))return sendError(req,res,400,'INVALID_SHIPMENT');
        if(trackingUrl&&!/^https:\/\//i.test(trackingUrl))return sendError(req,res,400,'INVALID_TRACKING_URL');const now=nowIso();
        db.prepare(`INSERT INTO courier_shipments(order_id,provider,tracking_number,consignment_id,status,tracking_url,note,raw_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(order_id) DO UPDATE SET provider=excluded.provider,tracking_number=excluded.tracking_number,consignment_id=excluded.consignment_id,status=excluded.status,tracking_url=excluded.tracking_url,note=excluded.note,updated_at=excluded.updated_at`).run(orderId,provider,trackingNumber,consignmentId,status,trackingUrl,note,'',now,now);
        if(['booked','picked_up','in_transit','out_for_delivery'].includes(status)&&['pending','confirmed','processing'].includes(order.status))db.prepare("UPDATE orders SET status='shipped',updated_at=? WHERE id=?").run(now,orderId);else if(status==='delivered'&&order.status!=='delivered')db.prepare("UPDATE orders SET status='delivered',updated_at=? WHERE id=?").run(now,orderId);
        logActivity(db,{event:'courier_shipment_updated',sessionId:session.id,ip,userAgent:ua,pathName:p,orderId,detail:`provider=${provider}; status=${status}`});return sendJson(req,res,200,{ok:true,shipment:rowShipment(db.prepare('SELECT * FROM courier_shipments WHERE order_id=?').get(orderId))});
      }
      if(method==='POST'&&shipmentMatch[2]==='dispatch'){
        if(!process.env.STEADFAST_API_KEY||!process.env.STEADFAST_SECRET_KEY)return sendError(req,res,503,'STEADFAST_CREDENTIALS_NOT_CONFIGURED');
        const existing=db.prepare('SELECT * FROM courier_shipments WHERE order_id=?').get(orderId);if(existing?.consignment_id)return sendError(req,res,409,'SHIPMENT_ALREADY_DISPATCHED');
        let items=[];try{items=JSON.parse(order.items_json)}catch{};const apiUrl='https://portal.packzy.com/api/v1/create_order';
        const payload={invoice:order.order_number,recipient_name:order.customer_name,recipient_phone:order.phone,recipient_address:[order.address,order.upazila,order.district].filter(Boolean).join(', ').slice(0,250),cod_amount:Math.max(0,order.total),note:String(order.notes||'Clothing order').slice(0,200)};
        let response,data;try{response=await fetch(apiUrl,{method:'POST',headers:{'Api-Key':process.env.STEADFAST_API_KEY,'Secret-Key':process.env.STEADFAST_SECRET_KEY,'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(12000)});data=await response.json();}catch{return sendError(req,res,502,'COURIER_API_UNAVAILABLE');}
        if(!response.ok||data.status===400||data.status===422||data.consignment?.consignment_id===undefined&&data.consignment_id===undefined)return sendJson(req,res,502,{error:'COURIER_DISPATCH_FAILED',providerMessage:String(data.message||data.error||'Provider rejected request').slice(0,180)});
        const consignment=String(data.consignment?.consignment_id||data.consignment_id||data.consignment?.tracking_code||'');const tracking=String(data.consignment?.tracking_code||data.tracking_code||'');const status=String(data.consignment?.status||'in_review');const now=nowIso();
        db.prepare(`INSERT INTO courier_shipments(order_id,provider,tracking_number,consignment_id,status,tracking_url,note,raw_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?) ON CONFLICT(order_id) DO UPDATE SET provider=excluded.provider,tracking_number=excluded.tracking_number,consignment_id=excluded.consignment_id,status=excluded.status,tracking_url=excluded.tracking_url,note=excluded.note,raw_status=excluded.raw_status,updated_at=excluded.updated_at`).run(orderId,'steadfast',tracking,consignment,status,tracking?'https://steadfast.com.bd/':'' ,'Automatically booked from order',JSON.stringify({status:data.status||null}),now,now);
        db.prepare("UPDATE orders SET status='shipped',updated_at=? WHERE id=? AND status IN ('pending','confirmed','processing')").run(now,orderId);logActivity(db,{event:'courier_dispatched',sessionId:session.id,ip,userAgent:ua,pathName:p,orderId,detail:'Steadfast shipment created'});return sendJson(req,res,201,{ok:true,shipment:rowShipment(db.prepare('SELECT * FROM courier_shipments WHERE order_id=?').get(orderId))});
      }
      if(method==='POST'&&shipmentMatch[2]==='refresh'){
        const shipment=db.prepare('SELECT * FROM courier_shipments WHERE order_id=?').get(orderId);if(!shipment)return sendError(req,res,404,'SHIPMENT_NOT_FOUND');
        if(shipment.provider!=='steadfast')return sendError(req,res,409,'LIVE_TRACKING_NOT_SUPPORTED_FOR_PROVIDER');if(!shipment.consignment_id&&!shipment.tracking_number)return sendError(req,res,400,'TRACKING_ID_REQUIRED');if(!process.env.STEADFAST_API_KEY||!process.env.STEADFAST_SECRET_KEY)return sendError(req,res,503,'STEADFAST_CREDENTIALS_NOT_CONFIGURED');
        const id=encodeURIComponent(shipment.consignment_id||shipment.tracking_number);let response,data;try{response=await fetch(`https://portal.packzy.com/api/v1/status_by_cid/${id}`,{headers:{'Api-Key':process.env.STEADFAST_API_KEY,'Secret-Key':process.env.STEADFAST_SECRET_KEY,'Accept':'application/json'},signal:AbortSignal.timeout(10000)});data=await response.json();}catch{return sendError(req,res,502,'COURIER_API_UNAVAILABLE');}
        if(!response.ok)return sendError(req,res,502,'COURIER_STATUS_FAILED');const raw=String(data.delivery_status||data.status||'unknown').slice(0,80);const now=nowIso();db.prepare('UPDATE courier_shipments SET status=?,raw_status=?,updated_at=? WHERE order_id=?').run(raw,JSON.stringify(data).slice(0,2000),now,orderId);
        const mapped=raw==='delivered'?'delivered':raw==='pending'?'shipped':null;if(mapped&&!['cancelled','returned'].includes(order.status))db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run(mapped,now,orderId);
        return sendJson(req,res,200,{ok:true,shipment:rowShipment(db.prepare('SELECT * FROM courier_shipments WHERE order_id=?').get(orderId))});
      }
      return sendError(req,res,405,'METHOD_NOT_ALLOWED');
    }
    const orderMatch=p.match(/^\/api\/admin\/orders\/(\d+)$/);
    if(orderMatch&&method==='PATCH'){
      const id=Number(orderMatch[1]);const body=await readJson(req);const status=String(body.status||'');if(!VALID_STATUSES.has(status))return sendError(req,res,400,'INVALID_ORDER_STATUS');
      const old=db.prepare('SELECT * FROM orders WHERE id=?').get(id);if(!old)return sendError(req,res,404,'ORDER_NOT_FOUND');if(status===old.status)return sendJson(req,res,200,{ok:true,order:rowOrder(old)});
      try{db.exec('BEGIN IMMEDIATE');
        const items=JSON.parse(old.items_json);
        const terminalStatuses=new Set(['cancelled','returned']);
        if(terminalStatuses.has(status)&&old.stock_reserved){for(const it of items)db.prepare('UPDATE products SET stock=stock+?,updated_at=? WHERE id=?').run(it.quantity,nowIso(),it.productId);db.prepare('UPDATE orders SET stock_reserved=0 WHERE id=?').run(id);}
        else if(!terminalStatuses.has(status)&&terminalStatuses.has(old.status)&&!old.stock_reserved){for(const it of items){const changed=db.prepare('UPDATE products SET stock=stock-?,updated_at=? WHERE id=? AND active=1 AND stock>=?').run(it.quantity,nowIso(),it.productId,it.quantity);if(changed.changes!==1)throw new Error('OUT_OF_STOCK');}db.prepare('UPDATE orders SET stock_reserved=1 WHERE id=?').run(id);}
        db.prepare('UPDATE orders SET status=?,updated_at=? WHERE id=?').run(status,nowIso(),id);db.exec('COMMIT');
      }catch(err){try{db.exec('ROLLBACK');}catch{}if(err.message==='OUT_OF_STOCK')return sendError(req,res,409,'OUT_OF_STOCK');throw err;}
      logActivity(db,{event:'order_status_changed',sessionId:session.id,ip,userAgent:ua,pathName:p,orderId:id,detail:`${old.status} -> ${status}`});return sendJson(req,res,200,{ok:true,order:rowOrder(db.prepare('SELECT * FROM orders WHERE id=?').get(id))});
    }
    if(method==='GET'&&p==='/api/admin/activity'){
      const event=url.searchParams.get('event')||'';const ipFilter=url.searchParams.get('ip')||'';const where=[];const params=[];const allowed=new Set([...VALID_EVENTS,'login_success','login_failed','customer_registered','customer_login','chat_message','chat_staff_reply','staff_created','staff_updated','staff_deactivated','ip_blocked','ip_unblocked','blocked_ip_request','rate_limited','setup_complete','setup_failed','product_created','product_updated','product_deleted','order_status_changed','settings_updated']);
      if(event&&allowed.has(event)){where.push('event=?');params.push(event);}if(ipFilter){where.push('ip LIKE ?');params.push('%'+ipFilter.slice(0,64)+'%');}
      const query=`SELECT * FROM activity_events ${where.length?'WHERE '+where.join(' AND '):''} ORDER BY created_at DESC LIMIT 1000`;const events=db.prepare(query).all(...params).map(a=>rowActivity(a,db));const since=new Date(Date.now()-86400000).toISOString();
      const pageViews24h=db.prepare("SELECT COUNT(*) n FROM activity_events WHERE event='page_view' AND created_at>=?").get(since).n;const sessions24h=db.prepare("SELECT COUNT(DISTINCT session_id) n FROM activity_events WHERE created_at>=?").get(since).n;const cartEvents24h=db.prepare("SELECT COUNT(*) n FROM activity_events WHERE event='add_to_cart' AND created_at>=?").get(since).n;const orderEvents24h=db.prepare("SELECT COUNT(*) n FROM activity_events WHERE event='order_placed' AND created_at>=?").get(since).n;
      const securityEvents=db.prepare("SELECT * FROM activity_events WHERE event IN ('login_success','login_failed','ip_blocked','ip_unblocked','blocked_ip_request','rate_limited','setup_complete','setup_failed') ORDER BY created_at DESC LIMIT 40").all().map(a=>rowActivity(a,db));
      return sendJson(req,res,200,{events,metrics:{pageViews24h,sessions24h,cartEvents24h,orderEvents24h},securityEvents});
    }
    if(method==='GET'&&p==='/api/admin/blocked-ips')return sendJson(req,res,200,{blocked:db.prepare('SELECT id,ip,reason,created_at,blocked_by FROM blocked_ips ORDER BY created_at DESC').all().map(x=>({id:x.id,ip:x.ip,reason:x.reason,createdAt:x.created_at,blockedBy:x.blocked_by}))});
    if(method==='POST'&&p==='/api/admin/blocked-ips'){
      const body=await readJson(req,16*1024);const address=ipValid(body.ip);const reason=validateText(body.reason,200);if(!address||reason===null)return sendError(req,res,400,'INVALID_IP_OR_REASON');if(address===ip)return sendError(req,res,409,'CANNOT_BLOCK_CURRENT_IP');
      try{const ret=db.prepare('INSERT INTO blocked_ips(ip,reason,blocked_by,created_at) VALUES(?,?,?,?)').run(address,reason,session.user.id,nowIso());logActivity(db,{event:'ip_blocked',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`target=${address}; id=${ret.lastInsertRowid}`});return sendJson(req,res,201,{ok:true,id:Number(ret.lastInsertRowid)});}catch(err){if(String(err.message).includes('UNIQUE'))return sendError(req,res,409,'IP_ALREADY_BLOCKED');throw err;}
    }
    const blockMatch=p.match(/^\/api\/admin\/blocked-ips\/(\d+)$/);if(blockMatch&&method==='DELETE'){
      const id=Number(blockMatch[1]);const row=db.prepare('SELECT * FROM blocked_ips WHERE id=?').get(id);if(!row)return sendError(req,res,404,'BLOCK_NOT_FOUND');db.prepare('DELETE FROM blocked_ips WHERE id=?').run(id);logActivity(db,{event:'ip_unblocked',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`target=${row.ip}`});return sendJson(req,res,200,{ok:true});
    }
    if(method==='GET'&&p==='/api/admin/settings')return sendJson(req,res,200,{settings:settingsObject(db),aiProviderConfigured:Boolean(process.env.OPENAI_API_KEY),model:process.env.OPENAI_MODEL||''});
    if(method==='PUT'&&p==='/api/admin/settings'){
      const body=await readJson(req,1024*1024);const current=settingsObject(db);const oldSettingImages=[...uploadedFilenames(current.logoUrl),...(Array.isArray(current.customSections)?current.customSections.flatMap(section=>uploadedFilenames(section?.imageUrl)):[])];
      const storeName=validateText(body.storeName,80,{required:true,min:2});const contact=validateText(body.contact,160);const fee=Number(body.shippingFee);
      if(storeName===null||contact===null||!Number.isSafeInteger(fee)||fee<0||fee>5000)return sendError(req,res,400,'INVALID_SETTINGS');
      let logoUrl=Object.prototype.hasOwnProperty.call(body,'logoUrl')?String(body.logoUrl||'').trim():(current.logoUrl||'');if(logoUrl){logoUrl=validateImageUrl(logoUrl);if(logoUrl===null)return sendError(req,res,400,'INVALID_LOGO_URL');}
      const out={storeName,logoUrl,contact,shippingFee:fee};
      const textSpecs={themePrimary:[7,/^#[0-9a-fA-F]{6}$/],themeAccent:[7,/^#[0-9a-fA-F]{6}$/],pageBackground:[7,/^#[0-9a-fA-F]{6}$/],announcement:[240],heroTitle:[240],heroText:[600],heroButton:[80],footerText:[500],welcomeMessage:[240]};
      for(const [key,spec] of Object.entries(textSpecs))if(body[key]!==undefined){const value=validateText(body[key],spec[0]);if(value===null||(spec[1]&&!spec[1].test(value)))return sendError(req,res,400,'INVALID_CUSTOMIZATION');out[key]=value;}
      if(body.fontFamily!==undefined){const font=String(body.fontFamily);if(!['system','arial','georgia','poppins','noto-serif-bengali','inter'].includes(font))return sendError(req,res,400,'INVALID_FONT');out.fontFamily=font;}
      if(body.textScale!==undefined){const scale=String(body.textScale);if(!['small','normal','large'].includes(scale))return sendError(req,res,400,'INVALID_TEXT_SCALE');out.textScale=scale;}
      if(body.buttonStyle!==undefined){const style=String(body.buttonStyle);if(!['rounded','soft','square'].includes(style))return sendError(req,res,400,'INVALID_BUTTON_STYLE');out.buttonStyle=style;}
      if(body.chatWhatsApp!==undefined){const raw=String(body.chatWhatsApp||'').replace(/[\s()-]/g,'');if(raw&&!/^\+?[0-9]{8,16}$/.test(raw))return sendError(req,res,400,'INVALID_WHATSAPP_NUMBER');out.chatWhatsApp=raw.replace(/^\+/,'');}
      if(body.messengerUrl!==undefined){const raw=String(body.messengerUrl||'').trim();if(raw){let u;try{u=new URL(raw)}catch{return sendError(req,res,400,'INVALID_MESSENGER_URL');}if(u.protocol!=='https:'||!['m.me','www.facebook.com','facebook.com'].includes(u.hostname.toLowerCase()))return sendError(req,res,400,'INVALID_MESSENGER_URL');out.messengerUrl=u.toString();}else out.messengerUrl='';}
      if(body.aiChatEnabled!==undefined)out.aiChatEnabled=Boolean(body.aiChatEnabled);
      if(body.sectionVisibility!==undefined){const vis=body.sectionVisibility;if(!vis||typeof vis!=='object'||Array.isArray(vis))return sendError(req,res,400,'INVALID_SECTION_VISIBILITY');const allowed=['hero','categories','shop','combos','trackOrder','features'];const value={...(current.sectionVisibility||{})};for(const k of allowed)if(typeof vis[k]==='boolean')value[k]=vis[k];out.sectionVisibility=value;}
      if(body.customSections!==undefined){if(!Array.isArray(body.customSections)||body.customSections.length>250)return sendError(req,res,400,'INVALID_CUSTOM_SECTIONS');const sections=[];for(let i=0;i<body.customSections.length;i++){const raw=body.customSections[i]||{};const title=validateText(raw.title,160,{required:true,min:1});const bodyText=validateText(raw.body||'',3000);const buttonLabel=validateText(raw.buttonLabel||'',80);const imageUrl=raw.imageUrl?validateImageUrl(raw.imageUrl):'';let buttonUrl=String(raw.buttonUrl||'').trim();if(buttonUrl&&!(buttonUrl.startsWith('/')&&!buttonUrl.startsWith('//'))&&!/^https:\/\//i.test(buttonUrl))return sendError(req,res,400,'INVALID_CUSTOM_SECTION_URL');if([title,bodyText,buttonLabel].some(v=>v===null)||imageUrl===null)return sendError(req,res,400,'INVALID_CUSTOM_SECTION');const backgroundColor=String(raw.backgroundColor||'#f8f0e8'),textColor=String(raw.textColor||'#66564d');if(!/^#[0-9a-fA-F]{6}$/.test(backgroundColor)||!/^#[0-9a-fA-F]{6}$/.test(textColor))return sendError(req,res,400,'INVALID_CUSTOM_SECTION_COLOUR');const titleSize=raw.titleSize===undefined?36:Number(raw.titleSize),bodySize=raw.bodySize===undefined?16:Number(raw.bodySize);if(!Number.isInteger(titleSize)||titleSize<20||titleSize>64||!Number.isInteger(bodySize)||bodySize<12||bodySize>24)return sendError(req,res,400,'INVALID_CUSTOM_SECTION_FONT_SIZE');const fontFamily=String(raw.fontFamily||'system');if(!['system','arial','georgia','noto-serif-bengali','inter'].includes(fontFamily))return sendError(req,res,400,'INVALID_CUSTOM_SECTION_FONT');sections.push({id:String(raw.id||crypto.randomUUID()).slice(0,80),title,body:bodyText,imageUrl:imageUrl||'',buttonLabel,buttonUrl,visible:raw.visible!==false,layout:['image-left','image-right','text'].includes(raw.layout)?raw.layout:'image-left',backgroundColor,textColor,titleSize,bodySize,fontFamily,textAlign:raw.textAlign==='center'?'center':'left'});}out.customSections=sections;}
      for(const [k,v] of Object.entries(out))setSetting(db,k,v);deleteUnusedUploadedFiles(db,uploadDir,oldSettingImages);logActivity(db,{event:'settings_updated',sessionId:session.id,ip,userAgent:ua,pathName:p,detail:`store settings; customSections=${Array.isArray(out.customSections)?out.customSections.length:(current.customSections||[]).length}`});return sendJson(req,res,200,{ok:true,settings:settingsObject(db)});
    }
    if(method==='GET'&&p==='/api/admin/backup'){
      if(!isOwner(session))return sendError(req,res,403,'OWNER_ONLY');
      return sendJson(req,res,200,{formatVersion:1,exportedAt:nowIso(),note:'Contains customer personal information. Store this file securely.',products:db.prepare('SELECT * FROM products ORDER BY id').all().map(rowProduct),orders:db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all().map(rowOrder),settings:settingsObject(db),activity:db.prepare('SELECT * FROM activity_events ORDER BY created_at DESC LIMIT 5000').all().map(a=>rowActivity(a,db)),blockedIps:db.prepare('SELECT ip,reason,created_at FROM blocked_ips').all(),shipments:db.prepare('SELECT * FROM courier_shipments ORDER BY updated_at DESC').all(),reviews:db.prepare('SELECT * FROM product_reviews ORDER BY created_at DESC').all()},{'Content-Disposition':'attachment; filename="clothing-store-backup.json"','Cache-Control':'no-store'});
    }
    return sendError(req,res,404,'NOT_FOUND');
  }
  function cleanPath(fallback, raw) { let pth=String(raw||fallback||'/').split('?')[0].slice(0,500);if(!pth.startsWith('/'))pth='/';return pth.replace(/[\r\n]/g,''); }
  function rowActivity(a, db=null) {
  let customerLabel=a.session_id?`Visitor #${a.session_id}`:'Guest';
  if(db&&a.session_id){try{const row=db.prepare('SELECT c.full_name,c.phone FROM sessions s LEFT JOIN customer_accounts c ON c.id=s.customer_id WHERE s.id=?').get(a.session_id);if(row?.full_name)customerLabel=`${row.full_name}${row.phone?' · '+row.phone:''}`;}catch{}}
  if(db&&a.order_id){try{const row=db.prepare('SELECT customer_name,phone FROM orders WHERE id=?').get(a.order_id);if(row?.customer_name)customerLabel=`${row.customer_name}${row.phone?' · '+row.phone:''}`;}catch{}}
  return {id:a.id,event:a.event,sessionId:a.session_id,sessionKey:a.session_id?`visitor-${a.session_id}`:'guest',customerLabel,ip:a.ip,userAgent:a.user_agent,path:a.path,referrer:a.referrer,productId:a.product_id,orderId:a.order_id,detail:a.detail,createdAt:a.created_at};
}
  function serveStatic(req,res,pathname,folder) {
    const rel=pathname.replace(new RegExp('^/'+folder+'/'),'');const allow=folder==='css'?new Set(['styles.css']):folder==='js'?new Set(['store.js','admin.js','login.js','customer.js','chat.js']):new Set(['saree.svg','threepiece.svg','combo.svg','hero-saree.svg','brand-mark.svg']);
    if(!allow.has(rel))return sendError(req,res,404,'NOT_FOUND');const full=path.join(PUBLIC_DIR,folder,rel);if(!fs.existsSync(full))return sendError(req,res,404,'NOT_FOUND');return send(req,res,200,fs.readFileSync(full),MIME[path.extname(full)]||'application/octet-stream');
  }
  function serveUploaded(req,res,pathname,uploadDir=UPLOAD_DIR) { const filename=pathname.slice('/uploads/'.length);if(!/^[a-f0-9]{32}\.(jpg|png|webp)$/.test(filename))return sendError(req,res,404,'NOT_FOUND');const full=path.join(uploadDir,filename);if(!fs.existsSync(full))return sendError(req,res,404,'NOT_FOUND');return send(req,res,200,fs.readFileSync(full),MIME[path.extname(full)]||'application/octet-stream',{'Cache-Control':'public, max-age=86400','Content-Disposition':'inline'}); }
  const server=http.createServer((req,res)=>{
    // Attach a request timeout and avoid Node exposing verbose errors to clients.
    req.setTimeout(15000,()=>{if(!res.headersSent)sendError(req,res,408,'REQUEST_TIMEOUT');else res.destroy();});
    handler(req,res);
  });
  server.on('close',()=>{try{db.close();}catch{}});
  server._storeDb=db;
  return server;
}
if(require.main===module){
  const server=createServer();const host=process.env.HOST||'127.0.0.1';const port=Number(process.env.PORT||3000);
  server.listen(port,host,()=>{const addr=server.address();console.log(`Clothing Store listening at http://${host}:${addr.port}`);console.log(`Public storefront: http://127.0.0.1:${addr.port}/`);console.log(`Protected Admin path: http://127.0.0.1:${addr.port}/admin (no public-store link)`);console.log(`Health check: http://127.0.0.1:${addr.port}/healthz`);console.log('SQLite database: '+(process.env.STORE_DB_PATH||DEFAULT_DB));});
  const stop=()=>server.close(()=>process.exit(0));process.on('SIGINT',stop);process.on('SIGTERM',stop);
}
module.exports={createServer,hashPassword,verifyPassword,validateCheckout,validateImageUrl,normalizeIp:normIp};
