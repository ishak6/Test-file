# ফিচার লিস্ট — Clothing Store Secure Starter

## Premium upgrade v1.5.3 — লোকাল full-stack build

- বাংলা ও English storefront; ভাষা বদলানো যায়।
- Premium boutique styling: refined spacing, responsive product cards, hover states, and accessible quick-view product details.
- Product details modal-এ এক পণ্যের সর্বোচ্চ ১০টি ছবি; thumbnail দিয়ে ছবি বদলানো, description, price, stock, Cash on Delivery, Add to Cart, সরাসরি Order Now ও wishlist.
- Public order tracking: order number + checkout phone verification; exposes only status, total, date and item count, not customer identity/address. Rate-limited to 8 attempts per IP per 15 minutes.
- নমুনা পোশাক/কম্বো পণ্য; category ও search.
- আলাদা `/admin/login` ও protected `/admin`; storefront-এ Admin link নেই। সরাসরি `/admin` খুললেও login ছাড়া dashboard পাওয়া যাবে না।
- প্রথম Admin তৈরির one-time setup token; কমপক্ষে ৮ অক্ষরের password; scrypt password hash.
- Admin থেকে পণ্য add/edit/delete, বাংলা-ইংরেজি নাম/বিবরণ, category, SKU, price, stock, visibility, color/size এবং সর্বোচ্চ ১০টি ছবি কম্পিউটার থেকে সরাসরি multiple upload; preview/remove এবং persistent gallery, URL টাইপ করা লাগে না। Store logo-ও Admin থেকে ফাইল হিসেবে upload করা যায়।
- Cart; Bangladesh mobile validation; COD checkout.
- Customer wishlist / saved products with local-device persistence and a saved-items filter.
- Order details/status, cancel করলে stock ফেরত ও পুনরায় confirm করলে stock পুনরায় reserve.
- Dashboard sales/orders summary, customer order details, low stock, export/backup.
- IP block/unblock (exact IPv4/IPv6), reason, security events এবং failed-login rate limit.
- Activity log: opt-in analytics-এর পরে page view, product view, search query length (search text নয়), add-to-cart, checkout start ও language change; order/security events প্রয়োজনীয় কাজের জন্য।
- Customer-এর নাম/ফোন/জেলা/উপজেলা/ঠিকানা order পরিচালনায় সেভ হয়। IP ও browser User-Agent security/order audit-এর জন্য রাখা হয়। Password, keystroke, payment credential capture করা হয় না।
- Session, CSRF, origin check, secure headers/CSP, body-size limits, parameterized SQL, upload signature/size checks, transaction-ভিত্তিক stock.
- 90 দিনের activity log retention; JSON backup; health check.

## v1.5.3 UI ও security polish

- Nokshi Atelier demo branding, local bundled saree hero illustration ও custom favicon।
- Refined responsive storefront/Admin styling: spacing, cards, focus states, hover feedback, reduced-motion support।
- Keyboard accessibility-এর জন্য skip-to-content link।
- Hero/favicon static routes safe allowlist-এ; OAuth base URL public request-এর untrusted Host header থেকে নেওয়া হয় না।
- Updated automated regression coverage এবং fresh-server HTTP smoke checks। Browser-driven click-through এই managed environment-এ সম্পন্ন হয়নি; QA report-এ সীমাবদ্ধতা উল্লেখ আছে।

## নতুন 1.4.3 আপগ্রেড

- Product gallery database migration (`images_json`) পুরোনো single-image product-কে না ভেঙে চালু হয়; পুরোনো ছবি প্রথম photo হিসেবে দেখা যায়।
- Product detail ও home product card—দুই জায়গাতেই Order Now; variants থাকলে আগে রং/সাইজ বেছে, তারপর নির্বাচিত পণ্যটি checkout-এ নেয়।
- Admin image uploader-এ একসঙ্গে একাধিক ফাইল, preview, ছবি বাদ দেওয়া, ১০টির সীমা এবং সরাসরি binary upload signature/size validation; Store logo file upload।
- Cart-এ একই পণ্যের ভিন্ন রং/সাইজ আলাদা line item হিসেবে দেখানো ও পরিবর্তন করা যায়।

## নতুন 1.1.0 আপগ্রেড

- পণ্যের কার্ডে হার্ট বাটনে চাপ দিয়ে পছন্দের পণ্য সেভ/আনসেভ করা যায়। Saved items তালিকা ও কাউন্ট আছে। একই ব্রাউজার/ডিভাইসে refresh-এর পর তালিকা থাকে; অন্য ডিভাইসে sync হয় না।

## Real online launch-এর আগে যোগ/সেটআপ করতে হবে

- Node-capable hosting-এ server deploy, HTTPS এবং persistent disk.
- backup automation, restore drill, domain (এখনই দরকার নেই), contact/return/refund/privacy policy.
- Production edge/WAF/DDoS/rate limiting এবং monitored logs.
- প্রয়োজন অনুযায়ী MFA, admin recovery, staff roles, product image object storage.
- bKash/Nagad/কার্ড payment API (server-side verification/webhook), courier API/status updates.
- বেশি traffic/multi-instance হলে PostgreSQL ও object storage-এ migration.

## সীমাবদ্ধতা — খোলাখুলি

- এটি production-minded starter, কোনো formal penetration test বা security certification নয়; 100% security বা “বিশ্বের সেরা” নিশ্চয়তা নেই।
- অনলাইনে deployed হয়নি, তাই কোনো public live URL দেওয়া হয়নি। লোকাল সার্ভারে run ও API integration test করা হয়েছে।
- এই execution environment Chromium থেকে localhost খুলতে `ERR_BLOCKED_BY_ADMINISTRATOR` ফিরিয়েছে; তাই browser-ভিত্তিক UI screenshot/visual assertion এখানে সম্পন্ন হয়নি। নিজের PC-তে গাইড অনুযায়ী Chrome দিয়ে পরীক্ষা করো।
- Database SQLite; single persistent server-এর জন্য। Serverless/ephemeral filesystem ও multiple server instance-এর জন্য সরাসরি উপযুক্ত নয়।
- IP block exact address-এ কাজ করে; shared Wi-Fi/carrier/NAT-এ অনেক user একই public IP ভাগ করে নিতে পারে। IP থেকে নির্দিষ্ট ব্যক্তির পরিচয়/বাসার ঠিকানা জানা যায় না। CIDR ranges/IP geography lookup নেই।
- Customer activity analytics ঐচ্ছিক consent চায়; শুধু site খোলার কারণে sensitive keystroke tracking হয় না।


## Premium v1.4 additions
- Product colour/size options stored in SQLite and validated on checkout.
- Verified-purchase reviews require matching order number and phone; reviews need Admin approval.
- Courier shipment record with provider, tracking/consignment ID, status, note, tracking URL; exposed to the order owner via order-number + phone lookup.
- Steadfast server-side create-order and status refresh when merchant API credentials are configured in private `.env`.
- Other courier providers can be recorded manually with their tracking links; their live API integrations are not implemented in this build.


## Premium 1.5.0 — customer & customization
- Customer account register/login/profile/order history.
- Floating web chat with Admin inbox/replies; offline staff fallback via built-in Bangla FAQ or optional server-side AI key.
- Moderator/parent staff roles with server-enforced permissions.
- Customer directory and enriched activity reports. Optional browsing analytics are consent-based.
- Page design controls for theme colors, fonts, size scale, button style, hero/announcement/footer, section visibility and individually styled custom sections (up to 250).


## Premium 1.5.1 — account, OAuth, cookies and checkout
- Customer account profile: primary/alternate phone, email, district, upazila, detailed saved address, postal code and preferred language; login makes the stored delivery address available to checkout.
- CSRF rotation recovery: a rejected mutation refreshes the current CSRF token from bootstrap and retries once before showing an error.
- Optional “remember me” customer session cookie: 30 days when checked; default login is 12 hours. Auth cookie remains HttpOnly and server-side sessions are revocable.
- Google and Facebook OAuth authorization-code flows with random state, state cookie, server-side code exchange and identity table. Real sign-in requires credentials in private `.env` and provider-side redirect-URI configuration.
- Privacy preference stored in `store_analytics_consent` cookie and localStorage; cart and wishlist still persist in browser storage.
