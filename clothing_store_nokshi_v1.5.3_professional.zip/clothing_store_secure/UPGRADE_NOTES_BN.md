# Upgrade Notes — v1.5.3

## v1.5.3 storefront/Admin polish

- Storefront-এর abstract hero fabric blocks বদলে local bundled editorial saree illustration যোগ করা হয়েছে; asset allowlist ও MIME serving regression test-এ যাচাই হয়।
- Default demo branding `Nokshi Atelier`; নতুন database-এ matching store name, Bangla/English hero copy এবং updated page title ব্যবহার হয়। পুরোনো installation-এর existing store name/data overwrite করা হয় না।
- Homepage, header, hero, trust strip, product cards, shopping controls, combo banner, footer, modal ও Admin dashboard-এর spacing, focus states, hover behavior, shadow/border rhythm ও mobile presentation polish করা হয়েছে।
- Keyboard users-এর জন্য skip-to-content link; reduced-motion setting থাকলে নতুন transitions বন্ধ থাকে।
- Static asset route-এ hero image ও favicon allowlist-এ যোগ করা হয়েছে; OAuth callback URL-এ untrusted Host header-এর ওপর নির্ভর করা বন্ধ করা হয়েছে।
- `node --check`, `npm test`, fresh-server smoke checks চালানো হয়েছে। Chromium-এর environment policy localhost/file navigation ব্লক করায় live click-through browser QA সম্পন্ন করা যায়নি।

## v1.5.2 security and order logic patch

- Admin backup is now owner-only; moderators cannot download all customer/order data through the backup route.
- Checkout no longer overwrites the signed-in customer's saved name, phone, or address. An order can use a delivery phone that belongs to another account without changing the current account profile.
- Server-side checkout requires configured colour/size values to be present and valid; `null` cart entries are handled as a 400 validation error.
- Product-photo uploads accept either the `products` or `customization` permission. Product changes/deletions and replaced settings images clean up unused uploaded files while preserving files still referenced by products, settings, or order history.
- Order tracking normalizes Bangladesh phone formats including `+8801...` and `8801...`.
- Verified-purchase reviews are accepted only for delivered orders and products actually included in that order.
- Chat availability counts only staff with the chat permission (admins still count); human-agent intent takes precedence over common order FAQ keywords.
- Cancelled and returned orders restore reserved stock. Reopening a terminal order re-reserves stock after checking availability.
- Added layered order-creation limits (per IP, session and customer), password-check timing equalization for unknown accounts, null-safe CSRF handling, and trusted proxy CIDR support.
- Social login will not auto-link to an existing account by email alone. Configure `OAUTH_BASE_URL` explicitly in production; HTTPS is required there. This mitigates account pre-hijacking, but it does not replace a full email-verification workflow.
- `.env.example` now matches the code's default AI model name (`gpt-4.1-mini`).

## Notes / remaining requirements

- Automated test suite: `npm test` — 6 test files/cases passed in the bundled Node test runner on Node.js 22.16.0 at build time.
- JavaScript syntax checks passed for the server, storefront, Admin, customer and chat scripts.
- Live browser click-through and live Google/Facebook OAuth were not performed. OAuth was regression-tested with mocked Google responses.
- Full email verification and forgot-password recovery still need a configured email delivery provider and secure expiring verification/reset token flow; no unsafe unauthenticated password reset was added.
- The order rate limits are in-memory and reset on server restart. For multi-instance production deployments, move rate limiting to a shared store and consider a CAPTCHA provider.


## Changed in v1.4.2
- Product details modal-এ Order Now সরাসরি নির্বাচিত রং/সাইজসহ ওই পণ্যটি checkout-এ আনে।
- Product photo gallery: Admin থেকে সর্বোচ্চ ১০টি ছবি একসঙ্গে upload, একাধিক HTTPS URL যোগ, preview, ছবি বাদ দেওয়া; storefront thumbnail দিয়ে ছবির মধ্যে বদলানো যায়।
- SQLite additive `images_json` migration—আগের `image_url` products primary photo হিসেবে অক্ষত থাকে।
- Cart line item-এ variant-aware quantity/remove handling; ভিন্ন রং/সাইজ একই product হলেও আলাদা item।
- Added automated integration coverage for multi-photo create/update and the 10-image cap; JavaScript/server syntax checks pass.

## Changed in v1.4.1
- Simplified first Admin password setup: minimum 8 characters, no mandatory uppercase/lowercase/number/symbol combination. Passwords are still stored as salted scrypt hashes, failed login attempts are throttled, and the one-time setup token remains required.

## Added
- Product colour and size options, stored in SQLite and validated server-side at checkout.
- Verified-purchase reviews matched against order number, customer phone and purchased product; pending reviews require Admin approval.
- Admin review moderation tab.
- Courier shipment records with provider, tracking number, consignment ID, status, note, tracking URL and update time.
- Customer tracking view now displays courier tracking metadata without exposing customer name/address.
- Server-side Steadfast create-order and live status refresh, configured only with private merchant API credentials.
- Manual tracking metadata for Pathao, RedX, Paperfly, Sundarban and other providers.
- Additive SQLite migration, `.env` loading, security checks and tests for new workflows.

## Important
- Back up `data/store.sqlite` and `public/uploads/` before replacing an existing install.
- Configure Steadfast in `.env` only if you have an active merchant account and are ready for real bookings. Dispatch requires confirmation and may create a real shipment.
- Other courier providers are not live API-integrated in this release; they use manual tracking details and external tracking links.
- Full browser interaction QA remains outstanding in this environment; the headless browser was blocked by the environment browser policy. Credential-backed live courier API QA also remains outstanding.

## Research references
- Pathao official courier tracking explanation: https://pathao.com/blog/courier-tracking-is-here/
- Steadfast API endpoint shape used as implementation reference (public community documentation; confirm current request/response contract with Steadfast before production): https://github.com/Mahdi-hasan-shuvo/steadfast/blob/main/steadfast-courier-api-docs.md

## Changed in v1.4.3
- Home page-এর প্রতিটি product card-এ `Order Now` বাটন যোগ করা হয়েছে। Variant না থাকলে এটি সরাসরি checkout form খোলে; color/size থাকলে আগে নির্বাচন করতে Product Details খোলে।
- Admin-এর product photo upload এখন URL/base64 request body-এর বদলে authenticated direct binary file upload endpoint ব্যবহার করে; একসঙ্গে একাধিক ছবি, 5 MB size check, server signature check ও upload cleanup আছে।
- Settings-এ ব্র্যান্ড লোগোর সরাসরি file upload ও preview যোগ হয়েছে; URL টাইপ করা লাগে না।
- এক অর্ডারে একই পণ্যের ভিন্ন রং/সাইজ আলাদা line item হিসেবে নেওয়া যায়।
- Order checkout error message আরও নির্দিষ্ট করা হয়েছে।
- Added automated tests for direct image upload, CSRF guard, upload deletion, brand logo persistence and same-product multi-variant ordering.


## Changed in v1.5.1
- Fixed customer checkout failures caused by a stale/rotated CSRF token: storefront fetches a fresh bootstrap token and retries the rejected mutation once.
- Expanded customer account profile with saved delivery details and prefill on login/reload.
- Added optional 30-day “remember me” session persistence; normal customer login stays at 12 hours. Session cookie remains HttpOnly; logout revokes server session.
- Added persistent analytics-consent cookie.
- Added server-side Google/Facebook OAuth code-flow and identity table; it is ready to configure, but provider credentials and provider-dashboard redirect URI setup are required to use real social sign-in.
- Added additive customer-profile/OAuth migrations and regression tests for profile persistence, remembered session, social redirect/status and CSRF retry contract.
