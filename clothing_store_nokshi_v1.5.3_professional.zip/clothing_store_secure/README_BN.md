# Clothing Store — Premium Secure Full-stack v1.5.3

এটি আগের এক-ফাইল HTML demo-এর বদলে Node.js server + SQLite database-সহ একটি পূর্ণাঙ্গ local full-stack starter। লোকাল সার্ভার চালু থাকলে একই সার্ভারের সঙ্গে যুক্ত একাধিক browser/ফোন একই পণ্য ও অর্ডার দেখতে পারে। ডেটা `data/store.sqlite`-এ এবং upload করা ছবি `public/uploads/`-এ থাকে।

> নিরাপত্তার বিষয়ে সতর্কতা: কোনো অ্যাপকে “বিশ্বের সেরা” বা শতভাগ নিরাপদ বলা যায় না। এই প্রজেক্টে সাধারণ ঝুঁকি কমানোর কয়েকটি স্তর রয়েছে, কিন্তু লাইভ ব্যবসায় নেওয়ার আগে HTTPS, ডেটাবেস/হোস্টিং, ব্যাকআপ, গোপনীয়তা নোটিশ ও পরীক্ষার ব্যবস্থা ঠিক করতে হবে।

## কী কী আছে

- ডিফল্ট ডেমো ব্র্যান্ড **Nokshi Atelier**—Admin → Settings থেকে নিজের স্টোরের নামে বদলে নাও।
- Premium editorial hero illustration, polished product cards, keyboard skip link ও mobile-first visual refinements।

- Premium boutique-style বাংলা / English storefront ও পণ্যের নাম/বিবরণের bilingual field
- Product details modal-এ একাধিক product photo gallery, thumbnail দিয়ে ছবি বদলানো, রং/সাইজ নির্বাচন, Add to Cart ও Order Now (এক পণ্য সরাসরি checkout-এ নেয়)
- Order number + checkout phone দিয়ে private order-status lookup (limited fields, rate limited)
- শাড়ি, থ্রি-পিস, কম্বো ও অন্যান্য পোশাকের demo catalog
- Admin থেকে product add / edit / delete; এক পণ্যে সর্বোচ্চ ১০টি JPG/PNG/WebP ছবি কম্পিউটার থেকে সরাসরি upload, preview দেখা ও ছবি বাদ দেওয়া যায়—URL টাইপ করতে হয় না। প্রথম ছবিটি primary photo। ব্র্যান্ড লোগোও Admin থেকে ফাইল হিসেবে upload করা যায়।
- Cart, delivery form, server-side price/stock validation এবং Cash on Delivery order
- order management, status change, cancel করলে stock restore, CSV exports ও JSON backup
- storefront-এ Admin link নেই; `/admin` protected login-এর পরেই dashboard দেখায়
- first-run one-time setup token, scrypt password hashing, server-side session token, HttpOnly cookie, SameSite=Strict, CSRF token, login throttling
- security headers, strict Content Security Policy, request body limit, input validation, rate limiting
- IP block / unblock, admin activity log, consent-ভিত্তিক customer journey analytics
- browser/device User-Agent, IP, page path, page/product/cart/order events দেখা; **কী-স্ট্রোক, পাসওয়ার্ড বা প্রতিটি ফর্ম অক্ষর রেকর্ড করা হয় না**
- product photos ও database স্থানীয় ডিস্কে থাকে, restart হলেও থাকে
- automated Node.js integration/security tests (`npm test`)

## Admin থেকে এক পণ্যে একাধিক ছবি যোগ

1. Admin → Products → Add Product অথবা Edit খোলো।
2. `কম্পিউটার থেকে একসঙ্গে একাধিক ছবি আপলোড` বক্সে ক্লিক করে একসঙ্গে একাধিক ছবি নির্বাচন করো (Windows-এ Ctrl চেপে একাধিক ফাইল বাছা যায়)। প্রতিটি মূল ফাইল সর্বোচ্চ 5 MB।
3. ছবিগুলো সরাসরি upload হয়ে preview-তে আসবে। ভুল ছবি `ছবি বাদ দিন` চাপ দিয়ে সরিয়ে `পণ্য সেভ করো` চাপো। সর্বোচ্চ ১০টি ছবি রাখা যাবে।
4. Storefront-এ প্রোডাক্ট কার্ডের `এখনই অর্ডার করুন` বাটন চাপলে সরাসরি checkout খুলবে; রং/সাইজ থাকলে আগে পণ্য details থেকে বেছে নিতে হবে। `বিস্তারিত দেখুন` খুললে thumbnail-এ ক্লিক করে ছবি বদলানো যায়; direct order বর্তমান কার্টের বদলে শুধু নির্বাচিত পণ্যটি checkout-এ নেয়।

## Windows-এ লোকাল চালানোর নিয়ম

### ১. Node.js ইনস্টল করো

Node.js-এর **24 LTS** সংস্করণ সুপারিশ করা হচ্ছে: https://nodejs.org/en/download/ । এই প্রজেক্ট Node.js 22.13+ চায়, কারণ built-in `node:sqlite` ব্যবহার করা হয়েছে; Node.js 22-এ এই API এখনও experimental, তাই নতুন 24 LTS ব্যবহার করা ভালো।

ইনস্টল শেষে Windows Command Prompt/PowerShell খুলে চালাও:

```bat
node --version
npm --version
```

`v24...` দেখা গেলে ভালো।

### ২. ZIP Extract করো

ZIP-টিকে `C:\clothing_store_secure`-এর মতো ফোল্ডারে Extract করো। `server.js`, `package.json`, `public`, `tests` একই root ফোল্ডারে থাকতে হবে।

### ৩. সার্ভার চালাও

সবচেয়ে সহজ উপায়: `RUN_WINDOWS.bat`-এ ডাবল-ক্লিক করো। অথবা ফোল্ডারে terminal খুলে চালাও:

```bat
node server.js
```

টার্মিনালে এই ধরনের তথ্য আসবে:

- Storefront: `http://127.0.0.1:3000/`
- Admin: `http://127.0.0.1:3000/admin/login`
- first-run one-time setup token: টার্মিনালে একবারের জন্য দেখানো হবে

টার্মিনাল বন্ধ কোরো না—সার্ভার চালু রাখার জন্য এটি খোলা থাকতে হবে।

### ৪. প্রথম Admin বানাও

1. `http://127.0.0.1:3000/admin/login` খোলো।
2. টার্মিনালে দেখানো one-time setup token বসাও। এই token শুধু প্রথম Admin তৈরির জন্য; তৈরি হলে token file মুছে যায়।
3. Admin email দাও এবং কমপক্ষে ৮ অক্ষরের একটি আলাদা password দাও। বড় হাতের অক্ষর, ছোট হাতের অক্ষর বা symbol বাধ্যতামূলক নয়; তবে সহজে অনুমান করা যায় এমন password ব্যবহার কোরো না।
4. `Create Admin` চাপো। এরপর `/admin`-এ dashboard খুলবে। Token, password বা SQLite database অন্যের সঙ্গে শেয়ার কোরো না।

### ৫. কীভাবে পরীক্ষা করবে

- Customer: `http://127.0.0.1:3000/`
- Admin: `http://127.0.0.1:3000/admin` (login ছাড়া dashboard পাওয়া যাবে না)
- Health check: `http://127.0.0.1:3000/healthz`
- Privacy notice: `http://127.0.0.1:3000/privacy`

Admin → Products → Add Product থেকে পণ্যের নাম, বাংলা/ইংরেজি নাম, category, দাম, stock এবং কম্পিউটার থেকে এক বা একাধিক ছবি upload দাও—photo URL লিখতে হবে না। তারপর নতুন tab/অন্য browser-এ storefront খুলে দেখো নতুন পণ্যটি একই local server থেকে আসছে কি না। Cart থেকে demo COD order দাও; Admin → Orders-এ সেটি দেখা উচিত।

### ৬. Automated test চালাও

সার্ভার চালু থাকা অবস্থায় একই project folder থেকে আলাদা terminal-এ:

```bat
npm test
```

Test suite নিজস্ব temporary database ব্যবহার করে; তোমার মূল `data/store.sqlite` বদলানোর উদ্দেশ্য নয়। Test পাস করলে `# pass 6` (বা suite বাড়লে তার বর্তমান সংখ্যা) দেখা যাবে।

## ডেটা কোথায় থাকে

- `data/store.sqlite` — product, admin, setting, order, security event, IP block ইত্যাদি
- `public/uploads/` — Admin দিয়ে upload করা ছবি
- `.setup_token` — প্রথম Admin না হওয়া পর্যন্ত তৈরি হওয়া private setup token; Admin তৈরি হলে স্বয়ংক্রিয়ভাবে মুছে যায়

Backup তৈরি করার সময় Admin → Settings → Download JSON Backup ব্যবহার করা যায়। এতে কাস্টমারের নাম, ফোন, ঠিকানা ও activity থাকতে পারে; নিরাপদ জায়গায় রাখো। ডেটাবেস backup-এর জন্য সার্ভার বন্ধ করে `data/store.sqlite`, `data/store.sqlite-wal`, `data/store.sqlite-shm` থাকলে সবগুলো এবং `public/uploads/` কপি করো। একই সময়ে চলমান database ফাইলের অসম্পূর্ণ কপি নেওয়া এড়িয়ে চলো।

## Real website বানানোর আগে

এই একই Node server online-এ চালাতে হলে **Node-capable long-running host, persistent disk, HTTPS reverse proxy এবং private backups** দরকার। শুধু Cloudflare Pages-এ static HTML হিসেবে আপলোড করলে এই backend চলবে না। SQLite database file ও `public/uploads`-কে persistent storage-এ রাখতে হবে; ephemeral filesystem বা বহু server instance-এ সরাসরি deploy কোরো না। বড়/একাধিক instance-এর জন্য PostgreSQL এবং object storage-এ migrate করা উচিত; এই starter-এর default backend SQLite—PostgreSQL migration এখানে অন্তর্ভুক্ত নয়।

সব ফিচারের অবস্থা `FEATURE_LIST_BN.md`-এ আছে। Live deploy-এর আগে `REAL_DEPLOYMENT_BN.md` ও `SECURITY_CHECKLIST_BN.md` পড়ো। bKash/Nagad ও courier API এই build-এ নেই; payment secret কখনো browser-এ রাখা যাবে না।


## নতুন Premium v1.4 ফিচার

- Admin product editor-এ রং ও সাইজ comma-separated তালিকা হিসেবে যোগ করা যায়; customer Quick View-তে variant বেছে কার্টে যোগ করতে পারে। Checkout-এ server-side variant validation হয়।
- Verified-purchase review: customer order number + একই order-এর mobile number দিয়ে শুধু কেনা পণ্যের review দিতে পারে। Review আগে pending থাকে; Admin → Reviews থেকে approve করলে storefront-এ দেখায়।
- Admin → Orders → Details-এ courier provider, tracking/consignment ID, HTTPS tracking URL, delivery status ও note সংরক্ষণ করা যায়। Customer order tracking পেজে courier status/ID এবং external tracking link দেখা যায়।
- Steadfast live integration: `.env` ফাইলে `STEADFAST_API_KEY` ও `STEADFAST_SECRET_KEY` দিলে Order Details থেকে Auto-book via Steadfast ব্যবহার করা যায় এবং Refresh live status দিয়ে API status sync করা যায়। এই কাজ করলে বাস্তব courier booking তৈরি হয়—প্রথমে test/sandbox account থাকলে সেটি ব্যবহার করো।
- Pathao/RedX/Paperfly/Sundarban-এ manual shipment metadata ও tracking link রাখা যায়। এই providers-এর live API status sync এই build-এ implement করা হয়নি; তাদের নিজস্ব merchant API credentials এবং verified API setup লাগবে।

### Steadfast setup

1. `.env.example`-কে `.env` নামে কপি করো (এটি `.gitignore`-এ বাদ আছে)।
2. নিজের Steadfast merchant dashboard-এর API key ও secret `.env`-এ বসাও।
3. সার্ভার restart করো; Admin → Orders → Details থেকে Auto-book via Steadfast করো।
4. Refresh live status দিয়ে provider-এর বর্তমান status আনো। API unavailable/credential missing হলে UI error দেখাবে; কোনো fake live status দেখায় না।
5. Customer tracking-এর জন্য order number এবং checkout-এ দেওয়া একই phone number দরকার।

**সীমা:** Browser-driven screenshot/visual test এই execution environment-এ করা যায়নি। Live courier API-তে প্রকৃত credentials ছাড়া end-to-end booking/status verification করা সম্ভব নয়।


## Premium v1.5.0 — customer, chat, customization ও staff roles

- কাস্টমার register/login, profile, account থেকে order history এবং লগইন করা কাস্টমারের অর্ডার account-এর সঙ্গে যুক্ত করার ব্যবস্থা।
- ডান-নিচের live-support widget; chat thread ও reply Admin → Customer chat থেকে দেখা/পাঠানো যায়। স্টাফ অনলাইনে না থাকলে built-in Bangla FAQ fallback কাজ করে; সার্ভারে `OPENAI_API_KEY` সেট করলে optional external AI response ব্যবহার করা যায়। Messenger/WhatsApp লিংক Admin settings থেকে কনফিগার করতে হবে।
- Admin-only staff account management; moderator এবং parent role-এ permissions নির্দিষ্ট করে দেওয়া যায়। Permission প্রতিটি protected API-তেও যাচাই হয়।
- Customer activity/customer directory/order activity রিপোর্ট উন্নত করা হয়েছে। ঐচ্ছিক page-view/product-view analytics কেবল ভিজিটর analytics consent দিলে রেকর্ড হয়।
- Page Design controls: theme colors, global font/text scale, button radius, announcement, hero/footer copy, built-in section show/hide, custom section-এর background/text colour, heading/body size, font family, alignment, image, layout ও button। সর্বোচ্চ ২৫০টি custom section যোগ করা যায়।
- Existing SQLite database additive migration দিয়ে রাখা হয়। আপগ্রেডের আগে database, uploads এবং `.env` backup নিন।

`OPENAI_API_KEY` optional এবং শুধু server environment-এ রাখবেন; browser-side JavaScript-এ কখনো API key দেবেন না। WhatsApp/Messenger controls external service link খোলে; official platform messaging API integration আলাদা business credentials ও webhook setup চায়।


## Premium v1.5.1 — CSRF checkout fix, customer profile, social login ও cookies

- Customer login-এর পর CSRF token rotate হয়ে পুরোনো token থেকে অর্ডার ব্যর্থ হলে storefront বর্তমান session-এর CSRF token refresh করে নিরাপদে একবার request retry করে। Error check হয় order transaction শুরু হওয়ার আগেই; stock/order duplicate হওয়ার ঝুঁকি না বাড়িয়ে retry করা হয়।
- Customer account-এ mobile, alternate mobile, email, district, upazila, saved delivery address, postal code এবং preferred language সেভ হয়। লগইন অবস্থায় checkout form saved address auto-fill করে এবং নতুন order থেকে default delivery address update হয়।
- Login form-এ “এই ডিভাইসে ৩০ দিন মনে রাখো” option আছে। এটি checked হলে server-side session ও HttpOnly cookie সর্বোচ্চ ৩০ দিনের জন্য রাখা হয়; unchecked হলে ১২ ঘণ্টা। Logout session revoke করে।
- Privacy preference (`store_analytics_consent`) এক বছরের SameSite=Lax cookie-তেও সংরক্ষিত হয়; cart/wishlist/language একই browser-এ localStorage-এ থাকে। Necessary server login cookie HttpOnly; sensitive auth token JavaScript-এ প্রকাশ পায় না।
- Google ও Facebook social-login buttons-এর সঙ্গে server-side OAuth 2.0 authorization-code/callback flow যোগ করা হয়েছে; provider ID, code exchange, email/profile lookup ও random single-use state validate হয়. Account-কে provider identity-র সঙ্গে link করে রাখা হয়।

### Google/Facebook login চালু করার প্রয়োজনীয় সেটআপ

1. `.env.example`-কে `.env` হিসেবে কপি করো।
2. Google Cloud Console-এ OAuth Client ID/Secret তৈরি করে Authorized redirect URI হিসেবে `https://YOUR-DOMAIN/auth/google/callback` যোগ করো। Meta Developers-এর Facebook Login settings-এ `https://YOUR-DOMAIN/auth/facebook/callback` যোগ করো।
3. `.env`-এ `OAUTH_BASE_URL=https://YOUR-DOMAIN`, `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `FACEBOOK_APP_ID`, `FACEBOOK_APP_SECRET` বসাও। `FACEBOOK_GRAPH_VERSION` default `v26.0`; provider-এর dashboard/docs অনুযায়ী live deployment-এর সময় version ও permissions confirm করো।
4. Server restart করে account modal থেকে Google এবং Facebook login test করো। OAuth redirect URI scheme/host/path-এ mismatch হলে provider login প্রত্যাখ্যান করবে। Real provider sign-in এই QA run-এ সম্পন্ন হয়নি, কারণ তোমার OAuth credentials নেই।
5. `.env`-এর secret কখনো screenshot/public repository/client-side JavaScript-এ দিও না। Production-এ HTTPS বাধ্যতামূলক।

**CSRF note:** পুরোনো tab-এ login/logout করলে token rotate হয়। Client এখন stale-token error হলে bootstrap থেকে fresh token নিয়ে একবার retry করে; refresh/retry-ও fail হলে order message-এ error দেখাবে—তখন page reload করে চেষ্টা করো।
